import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';
import { browserDb } from './lib/db/browserDb';

const rootElement = document.getElementById('root')!;

async function initializeApp() {
  try {
    console.log('Initializing application...');
    // Initialize browser database
    await browserDb.initialize?.();
    
    createRoot(rootElement).render(
      <StrictMode>
        <App />
      </StrictMode>
    );
  } catch (error: any) {
    console.error('Failed to start application:', error.message);
    rootElement.innerHTML = `
      <div style="color: red; padding: 20px; text-align: center; font-family: system-ui;">
        <h2>Application Error</h2>
        <p>Failed to initialize database. Please try again later.</p>
        <pre style="color: #666; font-size: 14px; margin-top: 10px; text-align: left; padding: 10px; background: #f5f5f5; border-radius: 4px;">${error.message}</pre>
      </div>
    `;
  }
}

initializeApp().catch(console.error);