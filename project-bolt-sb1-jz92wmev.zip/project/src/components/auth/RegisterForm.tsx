import React, { useState } from 'react';
import { Mail, Lock, User, Building } from 'lucide-react';
import { Button } from '../ui/Button';
import { FormField } from '../ui/FormField';
import { useFormValidation } from '../../hooks/useFormValidation';
import { registerSchema } from '../../lib/validation/forms';
import { browserDb } from '../../lib/db/browserDb';
import { useUser } from '../../contexts/UserContext';

interface FormData {
  email: string;
  password: string;
  confirmPassword: string;
  firstName: string;
  lastName: string;
  company: string;
}

const initialFormData: FormData = {
  email: '',
  password: '',
  confirmPassword: '',
  firstName: '',
  lastName: '',
  company: ''
};

export function RegisterForm() {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { setUser } = useUser();
  const { validationState, validateForm } = useFormValidation(registerSchema);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!validateForm(formData)) {
      return;
    }

    setLoading(true);
    try {
      const result = await browserDb.register({
        email: formData.email,
        password: formData.password,
        first_name: formData.firstName,
        last_name: formData.lastName,
        company: formData.company
      });

      if (result) {
        // Log the user in automatically after registration
        const loginResult = await browserDb.login(formData.email, formData.password);
        if (loginResult) {
          localStorage.setItem('auth_token', loginResult.token);
          setUser(loginResult.user);
          window.location.hash = loginResult.user.role === 'admin' ? '#admin-dashboard' : '#dashboard';
        }
      } else {
        setError('Registration failed. Please try again.');
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred during registration');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setError(null);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
          {error}
        </div>
      )}

      <div className="grid grid-cols-2 gap-4">
        <FormField
          label="First Name"
          name="firstName"
          value={formData.firstName}
          onChange={handleChange}
          error={validationState.firstName?.error}
          icon={User}
          required
          disabled={loading}
        />

        <FormField
          label="Last Name"
          name="lastName"
          value={formData.lastName}
          onChange={handleChange}
          error={validationState.lastName?.error}
          icon={User}
          required
          disabled={loading}
        />
      </div>

      <FormField
        label="Company Name"
        name="company"
        value={formData.company}
        onChange={handleChange}
        error={validationState.company?.error}
        icon={Building}
        required
        disabled={loading}
      />

      <FormField
        label="Email Address"
        name="email"
        type="email"
        value={formData.email}
        onChange={handleChange}
        error={validationState.email?.error}
        icon={Mail}
        required
        disabled={loading}
      />

      <FormField
        label="Password"
        name="password"
        type="password"
        value={formData.password}
        onChange={handleChange}
        error={validationState.password?.error}
        icon={Lock}
        required
        disabled={loading}
      />

      <FormField
        label="Confirm Password"
        name="confirmPassword"
        type="password"
        value={formData.confirmPassword}
        onChange={handleChange}
        error={validationState.confirmPassword?.error}
        icon={Lock}
        required
        disabled={loading}
      />

      <Button
        variant="primary"
        className="w-full mt-6"
        type="submit"
        disabled={loading}
      >
        {loading ? 'Creating Account...' : 'Create Account'}
      </Button>
    </form>
  );
}