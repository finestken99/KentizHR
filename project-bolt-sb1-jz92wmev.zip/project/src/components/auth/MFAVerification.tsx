import React, { useState } from 'react';
import { Shield } from 'lucide-react';
import { Button } from '../ui/Button';

export function MFAVerification() {
  const [code, setCode] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle MFA verification
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-center">
        <div className="p-2 bg-blue-100 rounded-full">
          <Shield className="h-8 w-8 text-blue-600" />
        </div>
      </div>
      
      <div className="text-center">
        <h2 className="text-xl font-semibold text-gray-900">Two-factor Authentication</h2>
        <p className="mt-2 text-sm text-gray-600">
          Enter the code sent to your device to verify your identity
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="code" className="sr-only">
            Verification Code
          </label>
          <input
            id="code"
            type="text"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="block w-full px-3 py-2 border border-gray-300 rounded-md text-center text-2xl tracking-widest shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            placeholder="000000"
            maxLength={6}
            required
          />
        </div>

        <Button variant="primary" className="w-full">
          Verify
        </Button>
      </form>

      <p className="text-center text-sm">
        <a href="#resend" className="text-blue-600 hover:text-blue-500">
          Didn't receive a code? Resend
        </a>
      </p>
    </div>
  );
}