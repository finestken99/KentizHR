import React from 'react';
import { MessageSquare, Clock, CheckCircle, AlertCircle } from 'lucide-react';

const queries = [
  {
    id: 1,
    title: 'Benefits Package Inquiry',
    category: 'HR',
    status: 'resolved',
    priority: 'medium',
    lastUpdate: '2 hours ago',
    response: 'Your benefits package includes comprehensive health insurance...'
  },
  {
    id: 2,
    title: 'IT Access Request',
    category: 'IT',
    status: 'in_progress',
    priority: 'high',
    lastUpdate: '1 hour ago',
    response: 'Your access request is being processed by the IT department...'
  },
  {
    id: 3,
    title: 'Training Program Access',
    category: 'Training',
    status: 'pending',
    priority: 'low',
    lastUpdate: '30 minutes ago',
    response: 'Awaiting department approval for training program access...'
  }
];

const statusConfig = {
  resolved: { icon: CheckCircle, className: 'text-green-500' },
  in_progress: { icon: Clock, className: 'text-yellow-500' },
  pending: { icon: AlertCircle, className: 'text-blue-500' }
};

const priorityStyles = {
  high: 'bg-red-100 text-red-800',
  medium: 'bg-yellow-100 text-yellow-800',
  low: 'bg-green-100 text-green-800'
};

export function QueryHistory() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900">Recent Queries</h3>
        <p className="text-sm text-gray-500">Track your support requests</p>
      </div>

      <div className="divide-y divide-gray-200">
        {queries.map((query) => {
          const StatusIcon = statusConfig[query.status].icon;
          return (
            <div key={query.id} className="p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3">
                  <MessageSquare className="h-5 w-5 text-gray-400 mt-1" />
                  <div>
                    <h4 className="text-sm font-medium text-gray-900">{query.title}</h4>
                    <p className="text-sm text-gray-500 mt-1">{query.response}</p>
                    <div className="flex items-center space-x-4 mt-2">
                      <span className="text-xs text-gray-500">{query.category}</span>
                      <span className="text-xs text-gray-500">{query.lastUpdate}</span>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col items-end space-y-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    priorityStyles[query.priority]
                  }`}>
                    {query.priority}
                  </span>
                  <StatusIcon className={`h-5 w-5 ${statusConfig[query.status].className}`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}