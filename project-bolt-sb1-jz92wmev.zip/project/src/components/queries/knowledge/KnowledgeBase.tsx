import React from 'react';
import { Book, Search, Brain } from 'lucide-react';

const articles = [
  {
    title: 'Benefits Overview',
    category: 'HR',
    views: 245,
    aiRecommended: true,
    summary: 'Complete guide to employee benefits and packages'
  },
  {
    title: 'IT Access Guide',
    category: 'IT',
    views: 189,
    aiRecommended: true,
    summary: 'Step-by-step guide for system access requests'
  },
  {
    title: 'Training Programs',
    category: 'Learning',
    views: 156,
    aiRecommended: false,
    summary: 'Available training and development opportunities'
  }
];

export function KnowledgeBase() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900">Knowledge Base</h3>
        <p className="text-sm text-gray-500">AI-curated help articles</p>
      </div>

      <div className="p-4">
        <div className="relative mb-4">
          <input
            type="text"
            placeholder="Search articles..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
          <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>

        <div className="space-y-4">
          {articles.map((article, index) => (
            <div
              key={index}
              className="p-4 border border-gray-200 rounded-lg hover:border-blue-200 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <Book className="h-5 w-5 text-gray-400" />
                  <div>
                    <h4 className="text-sm font-medium text-gray-900">{article.title}</h4>
                    <p className="text-xs text-gray-500 mt-1">
                      {article.category} • {article.views} views
                    </p>
                    <p className="text-sm text-gray-600 mt-2">{article.summary}</p>
                  </div>
                </div>
                {article.aiRecommended && (
                  <Brain className="h-5 w-5 text-blue-500" />
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}