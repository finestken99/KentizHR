import React from 'react';
import { Bot, User } from 'lucide-react';
import { MessageBubbleProps } from './types';

export function MessageBubble({ message }: MessageBubbleProps) {
  const isBot = message.sender === 'bot';
  
  return (
    <div className={`flex ${isBot ? 'justify-start' : 'justify-end'} mb-4`}>
      <div className={`flex items-start space-x-2 max-w-[80%] ${isBot ? 'flex-row' : 'flex-row-reverse space-x-reverse'}`}>
        <div className={`p-2 rounded-full ${isBot ? 'bg-blue-100' : 'bg-gray-100'}`}>
          {isBot ? (
            <Bot className="h-5 w-5 text-blue-600" />
          ) : (
            <User className="h-5 w-5 text-gray-600" />
          )}
        </div>
        <div
          className={`p-3 rounded-lg ${
            isBot
              ? 'bg-gray-100 text-gray-800'
              : 'bg-blue-600 text-white'
          }`}
        >
          {message.text}
        </div>
      </div>
    </div>
  );
}