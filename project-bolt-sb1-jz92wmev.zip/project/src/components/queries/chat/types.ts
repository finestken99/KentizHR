export interface Message {
  id: number;
  text: string;
  sender: 'bot' | 'user';
}

export interface MessageBubbleProps {
  message: Message;
}

export interface ChatHeaderProps {
  onClose: () => void;
}

export interface ChatInputProps {
  input: string;
  isLoading: boolean;
  onInputChange: (value: string) => void;
  onSendMessage: () => void;
}

export interface ChatState {
  messages: Message[];
  input: string;
  isLoading: boolean;
  isOpen: boolean;
}

export interface AIResponse {
  text: string;
  category?: string;
  confidence?: number;
}