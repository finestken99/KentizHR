import { AIResponse } from './types';
import { AI_RESPONSE_DELAY } from './constants';

const responses: Record<string, string> = {
  'leave': "I can help you with leave requests. You can check your balance or submit a new request through the Leave Management section. Would you like me to guide you through the process?",
  'salary': "Your salary information, including payslips and tax documents, is available in the Payroll section. For specific queries about compensation, please contact your HR representative.",
  'benefits': "We offer comprehensive benefits including health insurance, dental coverage, vision care, and a 401(k) plan with company matching. Would you like more details about any specific benefit?",
  'training': "Our learning platform offers various professional development opportunities including technical courses, soft skills training, and leadership programs. I can help you find relevant courses for your role.",
  'default': "I'm here to help with any HR-related questions. You can ask about leave, benefits, payroll, training, or any other HR matters."
};

export const generateAIResponse = async (message: string): Promise<string> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, AI_RESPONSE_DELAY));

  const keywords = Object.keys(responses);
  const matchedKeyword = keywords.find(keyword => 
    message.toLowerCase().includes(keyword)
  );

  return responses[matchedKeyword || 'default'];
};