import type { Message } from '../types';

export function createMessage(text: string, sender: Message['sender']): Message {
  return {
    id: Date.now(),
    text: text.trim(),
    sender
  };
}

export function createErrorMessage(): Message {
  return createMessage(
    'Sorry, I encountered an error. Please try again.',
    'bot'
  );
}

export function createLoadingMessage(): Message {
  return createMessage('...', 'bot');
}