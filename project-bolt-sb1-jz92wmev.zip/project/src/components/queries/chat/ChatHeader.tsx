import React from 'react';
import { Bot, X } from 'lucide-react';
import { ChatHeaderProps } from './types';

export function ChatHeader({ onClose }: ChatHeaderProps) {
  return (
    <div className="bg-blue-600 text-white p-4 flex justify-between items-center rounded-t-xl">
      <div className="flex items-center space-x-2">
        <Bot className="h-5 w-5" />
        <span>HR AI Assistant</span>
      </div>
      <button 
        onClick={onClose}
        className="hover:bg-blue-700 rounded-full p-1 transition-colors"
      >
        <X className="h-5 w-5" />
      </button>
    </div>
  );
}