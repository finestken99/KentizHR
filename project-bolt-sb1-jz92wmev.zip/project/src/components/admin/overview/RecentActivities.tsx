import React from 'react';
import { 
  UserPlus, 
  FileText, 
  Calendar, 
  MessageSquare,
  Clock
} from 'lucide-react';

const activities = [
  {
    id: 1,
    type: 'new_hire',
    description: 'Sarah Johnson joined Engineering team',
    timestamp: '2 hours ago',
    icon: UserPlus,
    color: 'text-green-500',
    bgColor: 'bg-green-100'
  },
  {
    id: 2,
    type: 'document',
    description: 'Annual compliance documents updated',
    timestamp: '4 hours ago',
    icon: FileText,
    color: 'text-blue-500',
    bgColor: 'bg-blue-100'
  },
  {
    id: 3,
    type: 'leave',
    description: 'Mike Chen requested annual leave',
    timestamp: '5 hours ago',
    icon: Calendar,
    color: 'text-purple-500',
    bgColor: 'bg-purple-100'
  },
  {
    id: 4,
    type: 'query',
    description: 'New benefits inquiry from Marketing team',
    timestamp: '1 day ago',
    icon: MessageSquare,
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-100'
  }
];

export function RecentActivities() {
  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-medium text-gray-900">Recent Activities</h3>
          <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
            View All
          </button>
        </div>

        <div className="space-y-6">
          {activities.map((activity) => {
            const Icon = activity.icon;
            return (
              <div key={activity.id} className="flex items-start space-x-4">
                <div className={`${activity.bgColor} p-2 rounded-lg`}>
                  <Icon className={`h-5 w-5 ${activity.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900">
                    {activity.description}
                  </p>
                  <div className="flex items-center mt-1 text-sm text-gray-500">
                    <Clock className="h-4 w-4 mr-1" />
                    {activity.timestamp}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 text-center">
          <button className="text-sm text-gray-500 hover:text-gray-700">
            Load more activities...
          </button>
        </div>
      </div>
    </div>
  );
}