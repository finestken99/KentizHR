import React from 'react';
import { Users, Clock, FileText, AlertCircle } from 'lucide-react';

const stats = [
  {
    label: 'Total Employees',
    value: '248',
    icon: Users,
    change: '+12%',
    changeType: 'increase'
  },
  {
    label: 'Leave Requests',
    value: '18',
    icon: Clock,
    change: '+5',
    changeType: 'increase'
  },
  {
    label: 'Documents Pending',
    value: '24',
    icon: FileText,
    change: '-3',
    changeType: 'decrease'
  },
  {
    label: 'Urgent Tasks',
    value: '7',
    icon: AlertCircle,
    change: '+2',
    changeType: 'increase'
  }
];

export function AdminOverview() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Dashboard Overview</h2>
        <p className="mt-1 text-sm text-gray-500">
          Welcome back! Here's what's happening in your organization today.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map(({ label, value, icon: Icon, change, changeType }) => (
          <div
            key={label}
            className="bg-white overflow-hidden shadow rounded-lg"
          >
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Icon className="h-6 w-6 text-gray-400" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">
                      {label}
                    </dt>
                    <dd className="flex items-baseline">
                      <div className="text-2xl font-semibold text-gray-900">
                        {value}
                      </div>
                      <div className={`ml-2 flex items-baseline text-sm font-semibold ${
                        changeType === 'increase' ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {change}
                      </div>
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}