import React from 'react';
import { ComplianceOverview } from './ComplianceOverview';
import { ComplianceTable } from './ComplianceTable';
import { ComplianceFilters } from './ComplianceFilters';

export function ComplianceTracking() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Compliance Management</h2>
        <p className="mt-1 text-sm text-gray-500">
          Track and manage regulatory compliance across your organization
        </p>
      </div>

      <ComplianceOverview />
      
      <div className="bg-white rounded-lg shadow">
        <div className="p-6">
          <ComplianceFilters />
          <ComplianceTable />
        </div>
      </div>
    </div>
  );
}