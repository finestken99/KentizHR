import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Users } from 'lucide-react';

const data = [
  { department: 'Engineering', engagement: 88, benchmark: 85 },
  { department: 'Sales', engagement: 92, benchmark: 85 },
  { department: 'Marketing', engagement: 85, benchmark: 85 },
  { department: 'HR', engagement: 90, benchmark: 85 },
  { department: 'Finance', engagement: 86, benchmark: 85 }
];

export function DepartmentEngagement() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Department Analysis</h3>
          <p className="text-sm text-gray-500">Engagement by department</p>
        </div>
        <Users className="h-6 w-6 text-blue-500" />
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="department" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="engagement" fill="#3B82F6" name="Engagement" />
            <Bar dataKey="benchmark" fill="#10B981" name="Benchmark" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}