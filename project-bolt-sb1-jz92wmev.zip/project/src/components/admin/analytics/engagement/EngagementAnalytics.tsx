import React from 'react';
import { Container } from '../../../ui/Container';
import { EngagementMetrics } from './EngagementMetrics';
import { EngagementTrends } from './EngagementTrends';
import { EngagementInsights } from './EngagementInsights';
import { DepartmentEngagement } from './DepartmentEngagement';

export function EngagementAnalytics() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Employee Engagement</h2>
          <p className="mt-2 text-gray-600">
            AI-powered engagement analytics and insights
          </p>
        </div>

        <div className="space-y-8">
          <EngagementMetrics />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <EngagementTrends />
            <DepartmentEngagement />
          </div>

          <EngagementInsights />
        </div>
      </Container>
    </div>
  );
}