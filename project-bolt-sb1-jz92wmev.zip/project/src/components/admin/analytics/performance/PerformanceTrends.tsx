import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, Brain } from 'lucide-react';

const data = [
  { month: 'Jan', performance: 85, average: 80, target: 90 },
  { month: 'Feb', performance: 88, average: 82, target: 90 },
  { month: 'Mar', performance: 92, average: 83, target: 90 },
  { month: 'Apr', performance: 90, average: 85, target: 90 },
  { month: 'May', performance: 95, average: 86, target: 90 },
  { month: 'Jun', performance: 97, average: 88, target: 90 }
];

export function PerformanceTrends() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Performance Trends</h3>
          <p className="text-sm text-gray-500">Employee performance analytics</p>
        </div>
        <TrendingUp className="h-6 w-6 text-blue-500" />
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <Line 
              type="monotone" 
              dataKey="performance" 
              stroke="#3B82F6" 
              strokeWidth={2}
              name="Performance"
            />
            <Line 
              type="monotone" 
              dataKey="average" 
              stroke="#10B981" 
              strokeWidth={2}
              name="Team Average"
            />
            <Line 
              type="monotone" 
              dataKey="target" 
              stroke="#EF4444" 
              strokeWidth={2}
              strokeDasharray="5 5"
              name="Target"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <Brain className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">AI Insight</h4>
            <p className="text-sm text-gray-600 mt-1">
              Performance is trending 15% above team average and consistently exceeding targets. Consider setting more challenging goals to maintain growth momentum.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}