import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Brain } from 'lucide-react';

const data = [
  { name: 'Engineering', value: 35, color: '#3B82F6' },
  { name: 'Sales', value: 25, color: '#10B981' },
  { name: 'Marketing', value: 15, color: '#6366F1' },
  { name: 'Operations', value: 12, color: '#F59E0B' },
  { name: 'HR', value: 8, color: '#EC4899' },
  { name: 'Finance', value: 5, color: '#8B5CF6' }
];

export function WorkforceComposition() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Workforce Composition</h3>
          <p className="text-sm text-gray-500">Department distribution analysis</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={80}
              paddingAngle={2}
              dataKey="value"
            >
              {data.map((entry) => (
                <Cell key={entry.name} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <Brain className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">AI Insight</h4>
            <p className="text-sm text-gray-600 mt-1">
              Engineering and Sales departments show the highest growth potential. Consider balanced expansion across support functions.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}