import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Brain } from 'lucide-react';

const data = [
  { month: 'Jan', hiring: 85, retention: 92, engagement: 88 },
  { month: 'Feb', hiring: 88, retention: 94, engagement: 85 },
  { month: 'Mar', hiring: 92, retention: 91, engagement: 89 },
  { month: 'Apr', hiring: 90, retention: 93, engagement: 92 },
  { month: 'May', hiring: 95, retention: 95, engagement: 94 },
  { month: 'Jun', hiring: 97, retention: 96, engagement: 95 }
];

export function TalentMetrics() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Talent Metrics</h3>
          <p className="text-sm text-gray-500">Hiring, retention, and engagement trends</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <Line 
              type="monotone" 
              dataKey="hiring" 
              stroke="#3B82F6" 
              strokeWidth={2}
              name="Hiring Success"
            />
            <Line 
              type="monotone" 
              dataKey="retention" 
              stroke="#10B981" 
              strokeWidth={2}
              name="Retention Rate"
            />
            <Line 
              type="monotone" 
              dataKey="engagement" 
              stroke="#6366F1" 
              strokeWidth={2}
              name="Engagement"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <Brain className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">AI Insight</h4>
            <p className="text-sm text-gray-600 mt-1">
              All talent metrics show positive trends. Focus on maintaining high engagement levels to support continued growth.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}