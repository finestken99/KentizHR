import React from 'react';
import { AnalyticsSummary } from './AnalyticsSummary';
import { EmployeeMetrics } from './EmployeeMetrics';
import { TurnoverChart } from './TurnoverChart';
import { RecruitmentMetrics } from './RecruitmentMetrics';

export function AnalyticsReporting() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Analytics & Reporting</h2>
        <p className="mt-1 text-sm text-gray-500">
          Track key HR metrics and make data-driven decisions
        </p>
      </div>

      <AnalyticsSummary />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <EmployeeMetrics />
        <TurnoverChart />
      </div>

      <RecruitmentMetrics />
    </div>
  );
}