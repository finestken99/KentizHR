import React from 'react';
import { Users, TrendingUp, Brain, Target, Zap, LineChart } from 'lucide-react';

const metrics = [
  {
    label: 'Total Workforce',
    value: '1,248',
    change: '+12%',
    icon: Users,
    color: 'text-blue-500',
    bgColor: 'bg-blue-100'
  },
  {
    label: 'Engagement Score',
    value: '85%',
    change: '+5%',
    icon: TrendingUp,
    color: 'text-green-500',
    bgColor: 'bg-green-100'
  },
  {
    label: 'Talent Retention',
    value: '94%',
    change: '+2%',
    icon: Brain,
    color: 'text-purple-500',
    bgColor: 'bg-purple-100'
  },
  {
    label: 'Performance Index',
    value: '4.2',
    change: '+0.3',
    icon: Target,
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-100'
  },
  {
    label: 'Productivity Score',
    value: '92%',
    change: '+8%',
    icon: Zap,
    color: 'text-indigo-500',
    bgColor: 'bg-indigo-100'
  },
  {
    label: 'Growth Trajectory',
    value: '+15%',
    change: '+3%',
    icon: LineChart,
    color: 'text-pink-500',
    bgColor: 'bg-pink-100'
  }
];

export function AnalyticsOverview() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {metrics.map(({ label, value, change, icon: Icon, color, bgColor }) => (
        <div key={label} className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center space-x-4">
            <div className={`${bgColor} p-3 rounded-lg`}>
              <Icon className={`h-6 w-6 ${color}`} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">{label}</p>
              <div className="flex items-baseline">
                <p className="text-2xl font-semibold text-gray-900">{value}</p>
                <span className={`ml-2 text-sm ${
                  change.startsWith('+') ? 'text-green-500' : 'text-red-500'
                }`}>
                  {change}
                </span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}