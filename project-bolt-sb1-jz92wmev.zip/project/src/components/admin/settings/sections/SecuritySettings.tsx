import React from 'react';
import { Shield, Key, Lock } from 'lucide-react';
import { Button } from '../../../ui/Button';

export function SecuritySettings() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">Security Settings</h3>
      
      <div className="space-y-6">
        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center space-x-3">
            <Shield className="h-6 w-6 text-blue-500" />
            <div>
              <h4 className="text-sm font-medium text-gray-900">Two-Factor Authentication</h4>
              <p className="text-sm text-gray-500">Require 2FA for all admin accounts</p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input type="checkbox" className="sr-only peer" defaultChecked />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
          </label>
        </div>

        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center space-x-3">
            <Key className="h-6 w-6 text-blue-500" />
            <div>
              <h4 className="text-sm font-medium text-gray-900">Password Policy</h4>
              <p className="text-sm text-gray-500">Enforce strong password requirements</p>
            </div>
          </div>
          <Button variant="secondary">Configure</Button>
        </div>

        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center space-x-3">
            <Lock className="h-6 w-6 text-blue-500" />
            <div>
              <h4 className="text-sm font-medium text-gray-900">Session Management</h4>
              <p className="text-sm text-gray-500">Set session timeout and concurrent login limits</p>
            </div>
          </div>
          <Button variant="secondary">Manage</Button>
        </div>
      </div>
    </div>
  );
}