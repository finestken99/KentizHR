import React from 'react';
import { Clock, Search, User, Settings } from 'lucide-react';

const auditLogs = [
  {
    id: 1,
    action: 'Settings Updated',
    user: 'Admin User',
    timestamp: '2024-03-15 14:30:00',
    details: 'Security settings modified'
  },
  {
    id: 2,
    action: 'Integration Added',
    user: 'System',
    timestamp: '2024-03-15 13:45:00',
    details: 'New Slack integration configured'
  },
  {
    id: 3,
    action: 'Compliance Check',
    user: 'System',
    timestamp: '2024-03-15 12:00:00',
    details: 'Automated compliance verification completed'
  }
];

export function AuditLogs() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-gray-900">Audit Logs</h3>
        <div className="relative">
          <input
            type="text"
            placeholder="Search logs..."
            className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          />
          <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>
      </div>
      
      <div className="space-y-4">
        {auditLogs.map((log) => (
          <div
            key={log.id}
            className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg"
          >
            <div className="p-2 bg-blue-100 rounded-lg">
              {log.action.includes('Settings') ? (
                <Settings className="h-5 w-5 text-blue-600" />
              ) : log.user === 'System' ? (
                <Clock className="h-5 w-5 text-blue-600" />
              ) : (
                <User className="h-5 w-5 text-blue-600" />
              )}
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium text-gray-900">{log.action}</h4>
                <span className="text-xs text-gray-500">{log.timestamp}</span>
              </div>
              <p className="text-sm text-gray-600 mt-1">{log.details}</p>
              <p className="text-xs text-gray-500 mt-1">By: {log.user}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}