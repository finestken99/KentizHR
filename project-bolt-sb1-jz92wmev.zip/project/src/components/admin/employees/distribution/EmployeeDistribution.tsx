import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { Users, Brain } from 'lucide-react';

const data = [
  { department: 'Engineering', count: 85, color: '#3B82F6' },
  { department: 'Sales', count: 45, color: '#10B981' },
  { department: 'Marketing', count: 30, color: '#8B5CF6' },
  { department: 'HR', count: 15, color: '#F59E0B' },
  { department: 'Finance', count: 25, color: '#EC4899' },
  { department: 'Operations', count: 48, color: '#6366F1' }
];

export function EmployeeDistribution() {
  const total = data.reduce((sum, item) => sum + item.count, 0);

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Workforce Distribution</h3>
          <p className="text-sm text-gray-500">Department-wise employee breakdown</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center text-blue-600">
            <Users className="h-5 w-5 mr-1" />
            <span className="text-sm font-medium">{total} Total</span>
          </div>
          <Brain className="h-6 w-6 text-blue-500" />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={2}
                dataKey="count"
              >
                {data.map((entry) => (
                  <Cell key={entry.department} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                formatter={(value, name, props) => [
                  `${value} employees (${((value / total) * 100).toFixed(1)}%)`,
                  props.payload.department
                ]}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {data.map((item) => (
            <div
              key={item.department}
              className="p-4 rounded-lg border border-gray-200 hover:border-blue-200 transition-colors"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-900">{item.department}</span>
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: item.color }}
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-2xl font-semibold text-gray-900">{item.count}</span>
                <span className="text-sm text-gray-500">
                  {((item.count / total) * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <Brain className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">Distribution Insight</h4>
            <p className="text-sm text-gray-600 mt-1">
              Engineering and Operations departments show the highest headcount, suggesting a strong technical focus. Consider balanced growth across support functions.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}