import { useState, useEffect } from 'react';
import { Employee } from '../types';

const mockEmployees: Employee[] = [
  {
    id: 1,
    name: 'Sarah Johnson',
    email: 'sarah.j@company.com',
    department: 'Engineering',
    position: 'Senior Developer',
    performance: 95,
    status: 'active'
  },
  {
    id: 2,
    name: 'Michael Chen',
    email: 'michael.c@company.com',
    department: 'Sales',
    position: 'Account Executive',
    performance: 88,
    status: 'active'
  },
  {
    id: 3,
    name: 'Emily Rodriguez',
    email: 'emily.r@company.com',
    department: 'Marketing',
    position: 'Marketing Manager',
    performance: 92,
    status: 'active'
  }
];

export function useEmployees() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call
    const fetchEmployees = async () => {
      try {
        // In a real app, this would be an API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        setEmployees(mockEmployees);
      } catch (error) {
        console.error('Error fetching employees:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchEmployees();
  }, []);

  return { employees, loading };
}