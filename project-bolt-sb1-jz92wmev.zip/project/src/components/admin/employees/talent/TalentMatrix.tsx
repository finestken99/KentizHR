import React from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Target } from 'lucide-react';

const data = [
  { name: 'John D.', performance: 85, potential: 90, department: 'Engineering' },
  { name: 'Sarah M.', performance: 92, potential: 88, department: 'Sales' },
  { name: 'Mike R.', performance: 78, potential: 95, department: 'Marketing' },
  { name: 'Emily L.', performance: 88, potential: 82, department: 'HR' },
  { name: 'David K.', performance: 95, potential: 85, department: 'Engineering' }
].map(item => ({
  ...item,
  radius: 8
}));

export function TalentMatrix() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Talent Matrix</h3>
          <p className="text-sm text-gray-500">Performance vs. Potential Analysis</p>
        </div>
        <Target className="h-6 w-6 text-blue-500" />
      </div>

      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              type="number" 
              dataKey="performance" 
              name="Performance" 
              domain={[60, 100]}
              label={{ value: 'Performance', position: 'bottom' }}
            />
            <YAxis 
              type="number" 
              dataKey="potential" 
              name="Potential" 
              domain={[60, 100]}
              label={{ value: 'Potential', angle: -90, position: 'left' }}
            />
            <Tooltip 
              cursor={{ strokeDasharray: '3 3' }}
              content={({ payload }) => {
                if (!payload?.length) return null;
                const data = payload[0].payload;
                return (
                  <div className="bg-white p-2 shadow rounded border">
                    <p className="font-medium">{data.name}</p>
                    <p className="text-sm text-gray-600">{data.department}</p>
                    <p className="text-sm">Performance: {data.performance}%</p>
                    <p className="text-sm">Potential: {data.potential}%</p>
                  </div>
                );
              }}
            />
            <Scatter 
              data={data} 
              fill="#3B82F6"
            />
          </ScatterChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}