import React from 'react';
import { Brain, Star, Award } from 'lucide-react';

const skills = [
  {
    category: 'Technical',
    skills: [
      { name: 'React', level: 90, growth: '+15%' },
      { name: 'Node.js', level: 85, growth: '+10%' },
      { name: 'TypeScript', level: 80, growth: '+20%' }
    ]
  },
  {
    category: 'Soft Skills',
    skills: [
      { name: 'Communication', level: 88, growth: '+8%' },
      { name: 'Leadership', level: 82, growth: '+12%' },
      { name: 'Problem Solving', level: 85, growth: '+15%' }
    ]
  }
];

export function EmployeeSkills() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Skills Analysis</h3>
          <p className="text-sm text-gray-500">AI-powered skill assessment</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-6">
        {skills.map((category) => (
          <div key={category.category}>
            <h4 className="text-sm font-medium text-gray-900 mb-4">
              {category.category}
            </h4>
            <div className="space-y-4">
              {category.skills.map((skill) => (
                <div key={skill.name} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Star className="h-4 w-4 text-yellow-400" />
                      <span className="text-sm font-medium text-gray-900">
                        {skill.name}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Award className="h-4 w-4 text-blue-500" />
                      <span className="text-sm text-green-600">{skill.growth}</span>
                    </div>
                  </div>
                  <div className="relative pt-1">
                    <div className="flex mb-2 items-center justify-between">
                      <div>
                        <span className="text-xs font-semibold inline-block text-blue-600">
                          {skill.level}%
                        </span>
                      </div>
                    </div>
                    <div className="overflow-hidden h-2 text-xs flex rounded bg-blue-100">
                      <div
                        style={{ width: `${skill.level}%` }}
                        className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <Brain className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">AI Insight</h4>
            <p className="text-sm text-gray-600 mt-1">
              Based on current growth trends, technical skills are developing faster than soft skills. Consider focusing on leadership development.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}