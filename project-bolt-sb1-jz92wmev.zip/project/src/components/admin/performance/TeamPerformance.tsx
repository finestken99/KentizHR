import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { rating: '5', count: 15, label: 'Exceptional' },
  { rating: '4', count: 28, label: 'Exceeds Expectations' },
  { rating: '3', count: 18, label: 'Meets Expectations' },
  { rating: '2', count: 8, label: 'Needs Improvement' },
  { rating: '1', count: 3, label: 'Unsatisfactory' }
];

export function TeamPerformance() {
  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">
        Performance Distribution
      </h3>
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="rating" 
              label={{ 
                value: 'Performance Rating', 
                position: 'bottom', 
                offset: 0 
              }} 
            />
            <YAxis 
              label={{ 
                value: 'Number of Employees', 
                angle: -90, 
                position: 'insideLeft',
                offset: 10
              }} 
            />
            <Tooltip 
              formatter={(value, name, props) => [
                `${value} employees`,
                props.payload.label
              ]}
            />
            <Bar 
              dataKey="count" 
              fill="#3B82F6" 
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
        <div>
          <span className="text-gray-500">Average Rating:</span>
          <span className="ml-2 font-medium text-gray-900">3.8</span>
        </div>
        <div>
          <span className="text-gray-500">Total Reviews:</span>
          <span className="ml-2 font-medium text-gray-900">72</span>
        </div>
      </div>
    </div>
  );
}