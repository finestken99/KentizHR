import React from 'react';
import { Calendar, Clock, Users } from 'lucide-react';

const leaveTypes = [
  {
    type: 'Annual Leave',
    used: 12,
    total: 25,
    icon: Calendar,
    color: 'text-blue-500',
    bgColor: 'bg-blue-100'
  },
  {
    type: 'Sick Leave',
    used: 3,
    total: 10,
    icon: Clock,
    color: 'text-green-500',
    bgColor: 'bg-green-100'
  },
  {
    type: 'Personal Leave',
    used: 2,
    total: 5,
    icon: Users,
    color: 'text-purple-500',
    bgColor: 'bg-purple-100'
  }
];

export function LeaveBalance() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">Leave Balance</h3>
      <div className="space-y-6">
        {leaveTypes.map(({ type, used, total, icon: Icon, color, bgColor }) => (
          <div key={type} className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`${bgColor} p-2 rounded-lg`}>
                  <Icon className={`h-5 w-5 ${color}`} />
                </div>
                <span className="text-sm font-medium text-gray-900">{type}</span>
              </div>
              <span className="text-sm text-gray-500">
                {used} / {total} days
              </span>
            </div>
            <div className="h-2 bg-gray-200 rounded-full">
              <div
                className="h-2 bg-blue-500 rounded-full"
                style={{ width: `${(used / total) * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}