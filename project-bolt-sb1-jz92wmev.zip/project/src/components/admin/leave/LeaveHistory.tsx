import React from 'react';
import { Calendar, CheckCircle, XCircle, Clock } from 'lucide-react';

interface LeaveRecord {
  id: number;
  type: string;
  startDate: string;
  endDate: string;
  status: 'approved' | 'rejected' | 'pending';
  reason: string;
  approver?: string;
  comments?: string;
}

const leaveHistory: LeaveRecord[] = [
  {
    id: 1,
    type: 'Annual Leave',
    startDate: '2024-02-15',
    endDate: '2024-02-18',
    status: 'approved',
    reason: 'Family vacation',
    approver: 'Jane Cooper',
    comments: 'Approved as requested'
  },
  {
    id: 2,
    type: 'Sick Leave',
    startDate: '2024-03-01',
    endDate: '2024-03-02',
    status: 'approved',
    reason: 'Medical appointment',
    approver: 'Robert Fox'
  },
  {
    id: 3,
    type: 'Personal Leave',
    startDate: '2024-03-20',
    endDate: '2024-03-21',
    status: 'pending',
    reason: 'Personal matters',
  }
];

const statusConfig = {
  approved: { icon: CheckCircle, className: 'text-green-500', label: 'Approved' },
  rejected: { icon: XCircle, className: 'text-red-500', label: 'Rejected' },
  pending: { icon: Clock, className: 'text-yellow-500', label: 'Pending' }
};

export function LeaveHistory() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Leave History</h3>
          <p className="text-sm text-gray-500">Past and pending leave requests</p>
        </div>
        <Calendar className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {leaveHistory.map((record) => {
          const StatusIcon = statusConfig[record.status].icon;
          return (
            <div
              key={record.id}
              className="border border-gray-200 rounded-lg p-4 hover:border-gray-300 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-900">{record.type}</span>
                    <span className="text-sm text-gray-500">•</span>
                    <div className="flex items-center">
                      <StatusIcon className={`h-4 w-4 ${statusConfig[record.status].className} mr-1`} />
                      <span className="text-sm text-gray-600">
                        {statusConfig[record.status].label}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">
                    {new Date(record.startDate).toLocaleDateString()} - {new Date(record.endDate).toLocaleDateString()}
                  </p>
                  <p className="text-sm text-gray-500 mt-2">{record.reason}</p>
                </div>
                {record.status === 'approved' && record.approver && (
                  <div className="text-right">
                    <span className="text-xs text-gray-500">Approved by</span>
                    <p className="text-sm font-medium text-gray-900">{record.approver}</p>
                  </div>
                )}
              </div>
              {record.comments && (
                <div className="mt-3 pt-3 border-t border-gray-100">
                  <p className="text-sm text-gray-600">{record.comments}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-4 text-center">
        <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
          View All History
        </button>
      </div>
    </div>
  );
}