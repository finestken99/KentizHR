import React from 'react';
import { CalendarCell } from './CalendarCell';

interface CalendarGridProps {
  currentMonth: Date;
  events: {
    date: string;
    events: Array<{
      name: string;
      type: string;
    }>;
  }[];
}

export function CalendarGrid({ currentMonth, events }: CalendarGridProps) {
  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();
    
    return { daysInMonth, startingDay };
  };

  const { daysInMonth, startingDay } = getDaysInMonth(currentMonth);
  const days = [];
  const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  // Add empty cells for days before the first of the month
  for (let i = 0; i < startingDay; i++) {
    days.push(<div key={`empty-${i}`} className="bg-gray-50" />);
  }

  // Add cells for each day of the month
  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(
      currentMonth.getFullYear(),
      currentMonth.getMonth(),
      day
    );
    const dateStr = date.toISOString().split('T')[0];
    const dayEvents = events.find(e => e.date === dateStr)?.events || [];

    days.push(
      <CalendarCell
        key={dateStr}
        date={date}
        events={dayEvents}
      />
    );
  }

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="grid grid-cols-7 gap-px border-b">
        {weekdays.map(day => (
          <div
            key={day}
            className="py-2 text-sm font-medium text-gray-900 text-center bg-gray-50"
          >
            {day}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-px">
        {days}
      </div>
    </div>
  );
}