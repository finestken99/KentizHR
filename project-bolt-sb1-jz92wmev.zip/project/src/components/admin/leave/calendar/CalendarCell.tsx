import React from 'react';
import { User } from 'lucide-react';

interface CalendarCellProps {
  date: Date;
  events: {
    name: string;
    type: string;
  }[];
}

export function CalendarCell({ date, events }: CalendarCellProps) {
  const isToday = new Date().toDateString() === date.toDateString();

  return (
    <div className={`min-h-[100px] p-2 border border-gray-200 ${
      isToday ? 'bg-blue-50' : 'bg-white'
    }`}>
      <div className="font-medium text-sm text-gray-900 mb-1">
        {date.getDate()}
      </div>
      <div className="space-y-1">
        {events.map((event, index) => (
          <div
            key={index}
            className="flex items-center text-xs p-1 rounded-md bg-blue-50"
          >
            <User className="h-3 w-3 text-blue-500 mr-1" />
            <span className="text-blue-700 truncate">{event.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
}