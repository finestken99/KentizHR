import React from 'react';
import { Container } from '../../ui/Container';
import { LeaveOverview } from './overview/LeaveOverview';
import { LeaveRequest } from './LeaveRequest';
import { LeaveCalendar } from './LeaveCalendar';
import { LeaveHistory } from './LeaveHistory';
import { LeaveAnalytics } from './analytics/LeaveAnalytics';
import { LeaveRecommendations } from './LeaveRecommendations';

export function LeaveManagement() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Leave Management</h2>
          <p className="mt-2 text-gray-600">
            AI-powered leave planning and management system
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <LeaveOverview />
            <LeaveRequest />
            <LeaveCalendar />
          </div>
          <div className="space-y-8">
            <LeaveAnalytics />
            <LeaveRecommendations />
            <LeaveHistory />
          </div>
        </div>
      </Container>
    </div>
  );
}