import React from 'react';
import { Shield, CheckCircle, AlertTriangle } from 'lucide-react';

const complianceItems = [
  {
    policy: 'Annual Leave Policy',
    status: 'compliant',
    lastChecked: '2024-03-15',
    details: 'All allocations within policy limits'
  },
  {
    policy: 'Sick Leave Tracking',
    status: 'warning',
    lastChecked: '2024-03-14',
    details: 'Some documentation pending review'
  },
  {
    policy: 'Holiday Calendar',
    status: 'compliant',
    lastChecked: '2024-03-13',
    details: 'All regional variations verified'
  }
];

export function LeaveCompliance() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Compliance Monitor</h3>
          <p className="text-sm text-gray-500">Policy adherence tracking</p>
        </div>
        <Shield className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {complianceItems.map((item, index) => (
          <div
            key={index}
            className="p-4 bg-gray-50 rounded-lg"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                {item.status === 'compliant' ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : (
                  <AlertTriangle className="h-5 w-5 text-yellow-500" />
                )}
                <span className="font-medium text-gray-900">{item.policy}</span>
              </div>
              <span className="text-sm text-gray-500">
                Last checked: {item.lastChecked}
              </span>
            </div>
            <p className="text-sm text-gray-600 ml-7">{item.details}</p>
          </div>
        ))}
      </div>
    </div>
  );
}