import React from 'react';
import { FileText, CheckCircle, AlertTriangle, Clock } from 'lucide-react';

const stats = [
  {
    label: 'Total Documents',
    value: '1,248',
    change: '+12%',
    icon: FileText,
    color: 'text-blue-500',
    bgColor: 'bg-blue-100'
  },
  {
    label: 'Compliant',
    value: '94%',
    change: '+2%',
    icon: CheckCircle,
    color: 'text-green-500',
    bgColor: 'bg-green-100'
  },
  {
    label: 'Pending Review',
    value: '28',
    change: '-5',
    icon: Clock,
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-100'
  },
  {
    label: 'Compliance Risks',
    value: '3',
    change: '-2',
    icon: AlertTriangle,
    color: 'text-red-500',
    bgColor: 'bg-red-100'
  }
];

export function DocumentStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map(({ label, value, change, icon: Icon, color, bgColor }) => (
        <div key={label} className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center space-x-4">
            <div className={`${bgColor} p-3 rounded-lg`}>
              <Icon className={`h-6 w-6 ${color}`} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">{label}</p>
              <div className="flex items-baseline">
                <p className="text-2xl font-semibold text-gray-900">{value}</p>
                <span className={`ml-2 text-sm ${
                  change.startsWith('+') ? 'text-green-500' : 'text-red-500'
                }`}>
                  {change}
                </span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}