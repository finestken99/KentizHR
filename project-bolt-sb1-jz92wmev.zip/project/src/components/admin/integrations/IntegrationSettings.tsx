import React from 'react';
import { IntegrationsOverview } from './IntegrationsOverview';
import { IntegrationsList } from './IntegrationsList';
import { IntegrationLogs } from './IntegrationLogs';

export function IntegrationSettings() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Integration Settings</h2>
        <p className="mt-1 text-sm text-gray-500">
          Manage and monitor your system integrations
        </p>
      </div>

      <IntegrationsOverview />
      <IntegrationsList />
      <IntegrationLogs />
    </div>
  );
}