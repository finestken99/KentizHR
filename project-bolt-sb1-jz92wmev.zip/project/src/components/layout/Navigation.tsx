import React from 'react';

const navItems = [
  { label: 'Products', href: '#products' },
  { label: 'Solutions', href: '#solutions' },
  { label: 'Technical', href: '#technical' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Resources', href: '#resources' }
];

export function Navigation() {
  return (
    <nav className="hidden md:flex space-x-8">
      {navItems.map(item => (
        <a
          key={item.label}
          href={item.href}
          className="text-gray-600 hover:text-blue-600 transition-colors"
        >
          {item.label}
        </a>
      ))}
    </nav>
  );
}