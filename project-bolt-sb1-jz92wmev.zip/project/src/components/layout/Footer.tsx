import React from 'react';
import { Facebook, Twitter, Linkedin as LinkedIn, Instagram } from 'lucide-react';
import { Container } from '../ui/Container';

const footerSections = [
  {
    title: 'Company',
    links: [
      { label: 'About', href: '#about' },
      { label: 'Careers', href: '#careers' },
      { label: 'Press', href: '#press' }
    ]
  },
  {
    title: 'Resources',
    links: [
      { label: 'Blog', href: '#blog' },
      { label: 'Guides', href: '#guides' },
      { label: 'Webinars', href: '#webinars' }
    ]
  },
  {
    title: 'Legal',
    links: [
      { label: 'Privacy', href: '#privacy' },
      { label: 'Terms', href: '#terms' },
      { label: 'Security', href: '#security' }
    ]
  }
];

const socialLinks = [
  { icon: Facebook, href: '#facebook' },
  { icon: Twitter, href: '#twitter' },
  { icon: LinkedIn, href: '#linkedin' },
  { icon: Instagram, href: '#instagram' }
];

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <Container className="py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {footerSections.map((section) => (
            <div key={section.title}>
              <h3 className="text-lg font-semibold mb-4">{section.title}</h3>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.label}>
                    <a href={link.href} className="text-gray-400 hover:text-white">
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
          <div>
            <h3 className="text-lg font-semibold mb-4">Connect</h3>
            <div className="flex space-x-4">
              {socialLinks.map(({ icon: Icon, href }) => (
                <a key={href} href={href} className="text-gray-400 hover:text-white">
                  <Icon className="h-6 w-6" />
                </a>
              ))}
            </div>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-800 text-center text-gray-400">
          <p>© 2024 KENTIZ. All rights reserved.</p>
        </div>
      </Container>
    </footer>
  );
}