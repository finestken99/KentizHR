import React from 'react';
import { LucideIcon } from 'lucide-react';

interface SolutionCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  industries: string[];
}

export function SolutionCard({ title, description, icon: Icon, industries }: SolutionCardProps) {
  return (
    <div className="p-8 border border-gray-200 rounded-xl hover:shadow-lg transition-shadow">
      <Icon className="h-12 w-12 text-blue-600 mb-4" />
      <h3 className="text-2xl font-semibold text-gray-900 mb-3">{title}</h3>
      <p className="text-gray-600 mb-6">{description}</p>
      <div className="flex flex-wrap gap-2">
        {industries.map((industry) => (
          <span
            key={industry}
            className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-sm"
          >
            {industry}
          </span>
        ))}
      </div>
    </div>
  );
}