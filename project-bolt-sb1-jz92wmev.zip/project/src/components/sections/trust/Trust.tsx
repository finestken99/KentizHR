import React from 'react';
import { 
  Shield, 
  Lock, 
  UserCheck, 
  RefreshCw,
  CheckCircle,
  FileCheck,
  ShieldCheck,
  Users
} from 'lucide-react';
import { Container } from '../../ui/Container';
import { SecurityFeature } from './SecurityFeature';
import { ComplianceBadge } from './ComplianceBadge';

const securityFeatures = [
  {
    title: 'SOC 2 Compliance',
    description: 'Independently audited and certified for the highest security standards in data handling and processing.',
    icon: Shield
  },
  {
    title: 'GDPR Adherence',
    description: 'Full compliance with EU data protection regulations, ensuring proper handling of personal information.',
    icon: Lock
  },
  {
    title: 'Role-Based Access Control',
    description: 'Granular permission settings ensure users only access appropriate data and features.',
    icon: UserCheck
  },
  {
    title: 'Regular Security Audits',
    description: 'Continuous monitoring and periodic third-party security assessments to maintain robust protection.',
    icon: RefreshCw
  }
];

const complianceBadges = [
  {
    title: 'SOC 2 Type II',
    icon: ShieldCheck,
    status: 'Certified'
  },
  {
    title: 'GDPR',
    icon: FileCheck,
    status: 'Compliant'
  },
  {
    title: 'ISO 27001',
    icon: CheckCircle,
    status: 'Certified'
  },
  {
    title: 'CCPA',
    icon: Users,
    status: 'Compliant'
  }
];

export function Trust() {
  return (
    <div className="py-16 bg-white">
      <Container>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Enterprise-Grade Security & Compliance
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Your data security is our top priority. We maintain the highest standards of security and compliance.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 mb-12">
          {securityFeatures.map((feature) => (
            <SecurityFeature
              key={feature.title}
              {...feature}
            />
          ))}
        </div>

        <div className="bg-gray-50 rounded-2xl p-8">
          <h3 className="text-xl font-semibold text-gray-900 mb-6 text-center">
            Compliance & Certifications
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {complianceBadges.map((badge) => (
              <ComplianceBadge
                key={badge.title}
                {...badge}
              />
            ))}
          </div>
        </div>
      </Container>
    </div>
  );
}