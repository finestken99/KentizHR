import React from 'react';

interface IntegrationLogoProps {
  name: string;
  icon: React.ComponentType<{ className?: string }>;
}

export function IntegrationLogo({ name, icon: Icon }: IntegrationLogoProps) {
  return (
    <div className="flex flex-col items-center p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
      <Icon className="h-12 w-12 text-gray-600" />
      <span className="mt-3 text-sm font-medium text-gray-900">{name}</span>
    </div>
  );
}