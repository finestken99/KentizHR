import React from 'react';
import { Brain, Target, Award } from 'lucide-react';

const competencies = [
  {
    skill: 'Technical Leadership',
    current: 75,
    required: 90,
    gap: 'Leadership in technical decisions',
    recommendation: 'Join architecture review board'
  },
  {
    skill: 'System Architecture',
    current: 60,
    required: 85,
    gap: 'Advanced system design patterns',
    recommendation: 'Complete system design course'
  },
  {
    skill: 'Team Collaboration',
    current: 80,
    required: 95,
    gap: 'Cross-team project coordination',
    recommendation: 'Lead inter-team initiatives'
  }
];

export function CompetencyGap() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Competency Gap</h3>
          <p className="text-sm text-gray-500">AI-identified skill gaps</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-6">
        {competencies.map((comp, index) => (
          <div key={index} className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Target className="h-5 w-5 text-gray-400" />
                <span className="text-sm font-medium text-gray-900">{comp.skill}</span>
              </div>
              <Award className="h-5 w-5 text-yellow-500" />
            </div>

            <div className="relative pt-1">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-gray-600">Current: {comp.current}%</span>
                <span className="text-gray-600">Required: {comp.required}%</span>
              </div>
              <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                <div
                  className="bg-blue-500"
                  style={{ width: `${comp.current}%` }}
                />
                <div
                  className="flex items-center justify-center absolute h-2 border-l-2 border-red-500"
                  style={{ left: `${comp.required}%` }}
                />
              </div>
            </div>

            <div className="mt-2 p-3 bg-blue-50 rounded-lg">
              <div className="flex items-start space-x-2">
                <Brain className="h-4 w-4 text-blue-500 mt-0.5" />
                <div>
                  <p className="text-sm text-gray-900 font-medium">Gap Analysis</p>
                  <p className="text-sm text-gray-600">{comp.gap}</p>
                  <p className="text-sm text-blue-600 mt-1">{comp.recommendation}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}