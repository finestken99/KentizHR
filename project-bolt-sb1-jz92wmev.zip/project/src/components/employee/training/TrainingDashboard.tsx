import React from 'react';
import { Container } from '../../ui/Container';
import { LearningOverview } from './LearningOverview';
import { PersonalizedPath } from './PersonalizedPath';
import { SkillTrends } from './SkillTrends';
import { TrainingNeeds } from './TrainingNeeds';
import { MicroLearning } from './MicroLearning';
import { CompetencyGap } from './CompetencyGap';

export function TrainingDashboard() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Intelligent Learning Ecosystem</h2>
          <p className="mt-2 text-gray-600">
            AI-powered personalized learning and development platform
          </p>
        </div>

        <div className="space-y-8">
          <LearningOverview />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <PersonalizedPath />
            <SkillTrends />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <TrainingNeeds />
            <MicroLearning />
            <CompetencyGap />
          </div>
        </div>
      </Container>
    </div>
  );
}