import React from 'react';
import { BookOpen, Clock, Play, Brain } from 'lucide-react';

const microContent = [
  {
    title: 'Advanced React Hooks',
    duration: '15 min',
    type: 'Video',
    relevance: 'High priority for current project',
    status: 'new'
  },
  {
    title: 'System Design Patterns',
    duration: '10 min',
    type: 'Article',
    relevance: 'Recommended for skill growth',
    status: 'in_progress'
  },
  {
    title: 'Cloud Architecture Quiz',
    duration: '5 min',
    type: 'Assessment',
    relevance: 'Test your knowledge',
    status: 'completed'
  }
];

const statusStyles = {
  new: 'bg-blue-100 text-blue-700',
  in_progress: 'bg-yellow-100 text-yellow-700',
  completed: 'bg-green-100 text-green-700'
};

export function MicroLearning() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Micro-Learning</h3>
          <p className="text-sm text-gray-500">Bite-sized learning content</p>
        </div>
        <BookOpen className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {microContent.map((content, index) => (
          <div
            key={index}
            className="border border-gray-200 rounded-lg p-4 hover:border-gray-300 transition-colors"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-3">
                <div className={`px-2 py-1 rounded-full text-xs font-medium ${statusStyles[content.status]}`}>
                  {content.status}
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <Clock className="h-4 w-4 mr-1" />
                  {content.duration}
                </div>
              </div>
            </div>

            <h4 className="text-sm font-medium text-gray-900 mb-2">{content.title}</h4>

            <div className="flex items-start space-x-2 text-sm text-gray-600 mb-4">
              <Brain className="h-4 w-4 text-blue-500 mt-0.5" />
              <span>{content.relevance}</span>
            </div>

            <button className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">
              <Play className="h-4 w-4 mr-2" />
              Start Learning
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}