import React from 'react';
import { Brain, PieChart, TrendingDown } from 'lucide-react';

const optimizations = [
  {
    category: '401(k) Contribution',
    potential: '$2,400',
    impact: 'Reduce taxable income',
    recommendation: 'Increase contribution by 5%'
  },
  {
    category: 'HSA Contribution',
    potential: '$850',
    impact: 'Pre-tax healthcare savings',
    recommendation: 'Maximize annual limit'
  },
  {
    category: 'FSA Benefits',
    potential: '$500',
    impact: 'Tax-free dependent care',
    recommendation: 'Enroll in dependent care FSA'
  }
];

export function TaxOptimization() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Tax Optimization</h3>
          <p className="text-sm text-gray-500">AI-recommended tax strategies</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {optimizations.map((opt, index) => (
          <div
            key={index}
            className="p-4 border border-blue-100 rounded-lg bg-blue-50"
          >
            <div className="flex items-start space-x-3">
              <PieChart className="h-5 w-5 text-blue-500 mt-0.5" />
              <div>
                <div className="flex items-center space-x-2">
                  <h4 className="text-sm font-medium text-gray-900">{opt.category}</h4>
                  <span className="text-sm text-green-600 flex items-center">
                    <TrendingDown className="h-4 w-4 mr-1" />
                    Save {opt.potential}
                  </span>
                </div>
                <p className="text-sm text-gray-600 mt-1">{opt.impact}</p>
                <p className="text-sm text-blue-600 mt-2">{opt.recommendation}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}