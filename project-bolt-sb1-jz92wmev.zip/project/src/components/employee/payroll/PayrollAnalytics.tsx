import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, Brain } from 'lucide-react';

const data = [
  { month: 'Jan', earnings: 5200, projected: 5200 },
  { month: 'Feb', earnings: 5400, projected: 5450 },
  { month: 'Mar', earnings: 5600, projected: 5700 },
  { month: 'Apr', earnings: 5800, projected: 5950 },
  { month: 'May', earnings: 5850, projected: 6200 },
  { month: 'Jun', earnings: null, projected: 6500 }
];

export function PayrollAnalytics() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Earnings Forecast</h3>
          <p className="text-sm text-gray-500">AI-predicted compensation trends</p>
        </div>
        <TrendingUp className="h-6 w-6 text-blue-500" />
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip formatter={(value) => `$${value}`} />
            <Line
              type="monotone"
              dataKey="earnings"
              stroke="#3B82F6"
              strokeWidth={2}
              name="Actual Earnings"
            />
            <Line
              type="monotone"
              dataKey="projected"
              stroke="#10B981"
              strokeWidth={2}
              strokeDasharray="5 5"
              name="Projected Earnings"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <Brain className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">Growth Projection</h4>
            <p className="text-sm text-gray-600 mt-1">
              Based on your performance and market trends, we project a 12% increase in total compensation by year-end.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}