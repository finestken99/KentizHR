import React from 'react';
import { Calendar, Clock, Users, Zap } from 'lucide-react';

const leaveTypes = [
  {
    type: 'Annual Leave',
    used: 12,
    total: 25,
    icon: Calendar,
    color: 'text-blue-500',
    bgColor: 'bg-blue-100'
  },
  {
    type: 'Sick Leave',
    used: 3,
    total: 10,
    icon: Clock,
    color: 'text-green-500',
    bgColor: 'bg-green-100'
  },
  {
    type: 'Personal Leave',
    used: 2,
    total: 5,
    icon: Users,
    color: 'text-purple-500',
    bgColor: 'bg-purple-100'
  },
  {
    type: 'Special Leave',
    used: 0,
    total: 5,
    icon: Zap,
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-100'
  }
];

export function LeaveOverview() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">Leave Balance Overview</h3>
      
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {leaveTypes.map(({ type, used, total, icon: Icon, color, bgColor }) => (
          <div key={type} className="p-4 rounded-lg border border-gray-100">
            <div className={`w-10 h-10 ${bgColor} rounded-lg flex items-center justify-center mb-3`}>
              <Icon className={`h-5 w-5 ${color}`} />
            </div>
            <div className="text-sm font-medium text-gray-900">{type}</div>
            <div className="mt-2">
              <div className="flex justify-between text-sm text-gray-500 mb-1">
                <span>{used} used</span>
                <span>{total - used} remaining</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full">
                <div
                  className={`h-2 rounded-full bg-blue-600`}
                  style={{ width: `${(used / total) * 100}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}