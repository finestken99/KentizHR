import React, { useState } from 'react';
import { Brain, Zap, Settings, Sliders } from 'lucide-react';

const aiSettings = [
  {
    id: 'personalization',
    title: 'AI Personalization',
    description: 'Allow AI to learn from your interactions',
    icon: Brain
  },
  {
    id: 'suggestions',
    title: 'Smart Suggestions',
    description: 'Receive AI-powered recommendations',
    icon: Zap
  },
  {
    id: 'automation',
    title: 'Workflow Automation',
    description: 'Enable AI-driven task automation',
    icon: Settings
  },
  {
    id: 'analytics',
    title: 'Performance Analytics',
    description: 'AI-powered performance insights',
    icon: Sliders
  }
];

export function AIPreferences() {
  const [preferences, setPreferences] = useState({
    personalization: true,
    suggestions: true,
    automation: true,
    analytics: true
  });

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">AI Settings</h3>

      <div className="space-y-4">
        {aiSettings.map(({ id, title, description, icon: Icon }) => (
          <div key={id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <Icon className="h-6 w-6 text-blue-500" />
              <div>
                <h4 className="text-sm font-medium text-gray-900">{title}</h4>
                <p className="text-sm text-gray-500">{description}</p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                className="sr-only peer"
                checked={preferences[id]}
                onChange={() => setPreferences(prev => ({ ...prev, [id]: !prev[id] }))}
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
        ))}
      </div>
    </div>
  );
}