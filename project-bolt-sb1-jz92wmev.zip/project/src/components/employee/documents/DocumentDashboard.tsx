import React from 'react';
import { Container } from '../../ui/Container';
import { DocumentSearch } from './DocumentSearch';
import { DocumentGrid } from './DocumentGrid';
import { DocumentStats } from './DocumentStats';
import { DocumentUpload } from './DocumentUpload';
import { DocumentActivity } from './DocumentActivity';

export function DocumentDashboard() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Document Management</h2>
          <p className="mt-2 text-gray-600">
            AI-powered document organization and insights
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <DocumentSearch />
            <DocumentGrid />
          </div>
          <div className="space-y-8">
            <DocumentStats />
            <DocumentUpload />
            <DocumentActivity />
          </div>
        </div>
      </Container>
    </div>
  );
}