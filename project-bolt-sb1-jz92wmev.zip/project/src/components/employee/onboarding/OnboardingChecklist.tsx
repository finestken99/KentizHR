import React from 'react';
import { CheckCircle, Circle, Clock } from 'lucide-react';

interface ChecklistItem {
  id: number;
  task: string;
  status: 'completed' | 'pending' | 'in_progress';
  dueDate: string;
}

const checklistItems: ChecklistItem[] = [
  {
    id: 1,
    task: 'Complete personal information form',
    status: 'completed',
    dueDate: '2024-03-20'
  },
  {
    id: 2,
    task: 'Review company policies',
    status: 'in_progress',
    dueDate: '2024-03-22'
  },
  {
    id: 3,
    task: 'Set up workstation and credentials',
    status: 'pending',
    dueDate: '2024-03-25'
  }
];

const statusIcons = {
  completed: { icon: CheckCircle, className: 'text-green-500' },
  in_progress: { icon: Clock, className: 'text-yellow-500' },
  pending: { icon: Circle, className: 'text-gray-300' }
};

export function OnboardingChecklist() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900">Your Onboarding Checklist</h3>
        <p className="text-sm text-gray-500">Track your progress through the onboarding process</p>
      </div>

      <div className="p-4">
        <div className="space-y-4">
          {checklistItems.map((item) => {
            const StatusIcon = statusIcons[item.status].icon;
            return (
              <div
                key={item.id}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
              >
                <div className="flex items-center space-x-3">
                  <StatusIcon className={`h-5 w-5 ${statusIcons[item.status].className}`} />
                  <div>
                    <p className="text-sm font-medium text-gray-900">{item.task}</p>
                    <p className="text-xs text-gray-500">Due: {item.dueDate}</p>
                  </div>
                </div>
                {item.status === 'pending' && (
                  <button className="text-sm text-blue-600 hover:text-blue-700">
                    Start
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}