import { useState, useCallback } from 'react';
import { z } from 'zod';
import { validateField } from '../lib/validation/forms';

interface ValidationState {
  [key: string]: {
    valid: boolean;
    error?: string;
  };
}

export function useFormValidation<T extends z.ZodType>(schema: T) {
  const [validationState, setValidationState] = useState<ValidationState>({});

  const validateForm = useCallback((data: unknown) => {
    try {
      schema.parse(data);
      return true;
    } catch (error) {
      return false;
    }
  }, [schema]);

  const validateSingleField = useCallback((name: string, value: unknown) => {
    const fieldSchema = (schema as any).shape?.[name];
    if (!fieldSchema) return;

    const result = validateField(fieldSchema, value);
    setValidationState(prev => ({
      ...prev,
      [name]: result
    }));
    return result;
  }, [schema]);

  const clearValidation = useCallback((name?: string) => {
    if (name) {
      setValidationState(prev => {
        const { [name]: _, ...rest } = prev;
        return rest;
      });
    } else {
      setValidationState({});
    }
  }, []);

  return {
    validationState,
    validateForm,
    validateSingleField,
    clearValidation
  };
}