import React from 'react';
import { Container } from '../components/ui/Container';
import { Technical } from '../components/sections/technical/Technical';
import { Interactive } from '../components/sections/interactive/Interactive';

export function TechnicalPage() {
  return (
    <div className="py-12">
      <Container>
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Technical Specifications
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore the powerful technology behind our HR management platform
          </p>
        </div>
      </Container>
      <Technical />
      <Interactive />
    </div>
  );
}