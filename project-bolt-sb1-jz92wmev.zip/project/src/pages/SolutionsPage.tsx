import React from 'react';
import { Container } from '../components/ui/Container';
import { Solutions } from '../components/sections/solutions/Solutions';
import { Differentiators } from '../components/sections/differentiators/Differentiators';
import { Trust } from '../components/sections/trust/Trust';

export function SolutionsPage() {
  return (
    <div className="py-12">
      <Container>
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            HR Solutions for Every Industry
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Tailored solutions to meet the unique needs of your organization
          </p>
        </div>
      </Container>
      <Solutions />
      <Differentiators />
      <Trust />
    </div>
  );
}