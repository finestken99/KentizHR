import { Router } from 'express';
import { employeeController } from '../controllers/employeeController';
import { authMiddleware } from '../middleware/auth';
import { UserRole } from '../../auth/types';

const router = Router();

router.post('/login', employeeController.login);
router.get('/profile', authMiddleware([UserRole.EMPLOYEE]), employeeController.getProfile);
router.put('/profile', authMiddleware([UserRole.EMPLOYEE]), employeeController.updateProfile);

export { router as employeeRoutes };