import { apiClient } from '../client';

export interface Query {
  id: number;
  title: string;
  description: string;
  category: string;
  status: string;
  priority: string;
  createdAt: string;
  updatedAt: string;
}

export interface QueryResponse {
  id: number;
  queryId: number;
  response: string;
  respondedBy: string;
  createdAt: string;
}

export const queriesApi = {
  submit: async (data: Omit<Query, 'id' | 'createdAt' | 'updatedAt'>): Promise<Query> => {
    return apiClient.post<Query>('queries/submit', data);
  },

  getHistory: async (employeeId: number): Promise<Query[]> => {
    return apiClient.get<Query[]>(`queries/${employeeId}/history`);
  },

  getResponses: async (queryId: number): Promise<QueryResponse[]> => {
    return apiClient.get<QueryResponse[]>(`queries/${queryId}/responses`);
  },

  updateStatus: async (queryId: number, status: string): Promise<void> => {
    return apiClient.put<void>(`queries/${queryId}/status`, { status });
  }
};