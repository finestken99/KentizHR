import { apiClient } from '../client';
import type { User } from '../../db/models/user';

export interface EmployeeStats {
  totalEmployees: number;
  activeEmployees: number;
  departmentDistribution: Record<string, number>;
  recentHires: User[];
}

export const employeeApi = {
  getStats: async (): Promise<EmployeeStats> => {
    return apiClient.get<EmployeeStats>('employees/stats');
  },

  getProfile: async (id: number): Promise<User> => {
    return apiClient.get<User>(`employees/${id}`);
  },

  updateProfile: async (id: number, data: Partial<User>): Promise<User> => {
    return apiClient.put<User>(`employees/${id}`, data);
  },

  getDepartmentEmployees: async (department: string): Promise<User[]> => {
    return apiClient.get<User[]>(`employees/department/${department}`);
  }
};