import { Request, Response } from 'express';
import { authService } from '../../services/authService';
import { tenantService } from '../../services/tenantService';
import { UserRole } from '../../auth/types';

export const landlordController = {
  async login(req: Request, res: Response) {
    try {
      const { email, password } = req.body;
      const result = await authService.login(email, password);
      
      if (!result || result.user.role !== UserRole.LANDLORD) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Login failed' });
    }
  },

  async register(req: Request, res: Response) {
    try {
      const result = await authService.register({
        ...req.body,
        role: UserRole.LANDLORD
      });
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Registration failed' });
    }
  },

  async getTenants(req: Request, res: Response) {
    try {
      const tenants = await tenantService.getTenantsByLandlord(req.user.id);
      res.json(tenants);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch tenants' });
    }
  },

  async createTenant(req: Request, res: Response) {
    try {
      const tenant = await tenantService.create({
        ...req.body,
        landlord_id: req.user.id
      });
      res.json(tenant);
    } catch (error) {
      res.status(500).json({ error: 'Failed to create tenant' });
    }
  }
};