import { securityConfig } from './config';

interface RateLimitEntry {
  count: number;
  resetTime: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();

export function rateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = rateLimitStore.get(ip);

  // Clean up expired entries
  for (const [key, value] of rateLimitStore.entries()) {
    if (now > value.resetTime) {
      rateLimitStore.delete(key);
    }
  }

  if (!entry || now > entry.resetTime) {
    // First request or reset period expired
    rateLimitStore.set(ip, {
      count: 1,
      resetTime: now + securityConfig.rateLimit.windowMs
    });
    return true;
  }

  if (entry.count >= securityConfig.rateLimit.maxRequests) {
    return false;
  }

  entry.count += 1;
  rateLimitStore.set(ip, entry);
  return true;
}