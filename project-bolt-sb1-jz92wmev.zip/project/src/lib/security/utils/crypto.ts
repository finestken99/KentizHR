import { randomBytes, scryptSync, timingSafeEqual } from 'crypto';
import { config } from '../../config/env';

export const cryptoUtils = {
  generateSalt(length: number = 32): string {
    return randomBytes(length).toString('hex');
  },

  async hashPassword(password: string): Promise<string> {
    const salt = this.generateSalt();
    const hash = scryptSync(password, salt, 64).toString('hex');
    return `${salt}:${hash}`;
  },

  async verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
    const [salt, storedHash] = hashedPassword.split(':');
    const hash = scryptSync(password, salt, 64);
    const storedHashBuffer = Buffer.from(storedHash, 'hex');
    return timingSafeEqual(hash, storedHashBuffer);
  },

  generateSecureToken(length: number = 32): string {
    return randomBytes(length).toString('hex');
  }
};