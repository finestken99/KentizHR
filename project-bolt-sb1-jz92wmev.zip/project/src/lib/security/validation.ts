import { z } from 'zod';
import { passwordSchema } from './config';

export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: passwordSchema,
  mfaToken: z.string().optional()
});

export const passwordChangeSchema = z.object({
  currentPassword: passwordSchema,
  newPassword: passwordSchema,
  confirmPassword: z.string()
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword']
});

export function validateLoginData(data: unknown) {
  try {
    return {
      success: true,
      data: loginSchema.parse(data)
    };
  } catch (error) {
    if (error instanceof z.ZodError) {
      return {
        success: false,
        errors: error.errors.reduce((acc, err) => ({
          ...acc,
          [err.path[0]]: err.message
        }), {})
      };
    }
    return {
      success: false,
      errors: { _form: 'Invalid data' }
    };
  }
}