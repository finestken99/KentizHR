import { authenticator } from 'otplib';
import { securityConfig } from './config';

export const mfaService = {
  generateSecret() {
    return authenticator.generateSecret();
  },

  generateQRCode(email: string, secret: string) {
    return authenticator.keyuri(
      email,
      securityConfig.mfa.issuer,
      secret
    );
  },

  verifyToken(token: string, secret: string) {
    return authenticator.verify({
      token,
      secret,
      window: securityConfig.mfa.window
    });
  },

  async enableMFA(userId: number, secret: string) {
    // Store MFA secret in database
    await db.users.update(userId, {
      mfa_secret: secret,
      mfa_enabled: true
    });
  },

  async disableMFA(userId: number) {
    await db.users.update(userId, {
      mfa_secret: null,
      mfa_enabled: false
    });
  }
};