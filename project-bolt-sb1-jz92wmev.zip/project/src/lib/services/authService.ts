import { userRepository } from '../db/repositories/userRepository';
import { UserRole } from '../auth/types';
import type { User } from '../db/models/types';

export const authService = {
  async register(data: Omit<User, 'id' | 'created_at' | 'updated_at'>): Promise<User> {
    const existingUser = await userRepository.findByEmail(data.email);
    if (existingUser) {
      throw new Error('Email already exists');
    }

    return userRepository.create({
      ...data,
      status: 'active'
    });
  },

  async login(email: string, password: string) {
    const user = await userRepository.findByEmail(email);
    if (!user || user.password !== password || user.status !== 'active') {
      throw new Error('Invalid credentials');
    }

    const tokenData = {
      user: {
        id: user.id,
        email: user.email,
        role: user.role
      },
      exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60)
    };

    return {
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        first_name: user.first_name,
        last_name: user.last_name
      },
      token: btoa(JSON.stringify(tokenData))
    };
  },

  async changePassword(userId: number, currentPassword: string, newPassword: string) {
    const user = await userRepository.findById(userId);
    if (!user || user.password !== currentPassword) {
      throw new Error('Invalid current password');
    }

    await userRepository.updatePassword(userId, newPassword);
  }
};