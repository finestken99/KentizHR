import { chatDb } from '../db/models/chat';
import type { ChatMessage } from '../db/models/chat';

export const chatService = {
  async saveMessage(message: Omit<ChatMessage, 'id'>) {
    try {
      const id = await chatDb.messages.add(message);
      return id;
    } catch (error) {
      console.error('Error saving message:', error);
      throw error;
    }
  },

  async getMessages(userId: number) {
    try {
      return await chatDb.messages
        .where('userId')
        .equals(userId)
        .reverse()
        .sortBy('timestamp');
    } catch (error) {
      console.error('Error fetching messages:', error);
      throw error;
    }
  },

  async clearMessages(userId: number) {
    try {
      await chatDb.messages
        .where('userId')
        .equals(userId)
        .delete();
    } catch (error) {
      console.error('Error clearing messages:', error);
      throw error;
    }
  }
};