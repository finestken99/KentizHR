export interface CreateEmployeeData {
  email: string;
  firstName: string;
  lastName: string;
  position: string;
  department: string;
}

export interface WelcomeEmailData {
  to: string;
  firstName: string;
  password: string;
  loginUrl: string;
}