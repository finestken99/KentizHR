import { Message } from '../types/chat';

interface ResponsePattern {
  keywords: string[];
  responses: string[];
  category: string;
}

const responsePatterns: ResponsePattern[] = [
  {
    keywords: ['leave', 'vacation', 'time off'],
    responses: [
      "I can help you with leave management. Would you like to check your balance or submit a request?",
      "Let me assist you with your leave inquiry. You can view your available days or start a new application."
    ],
    category: 'leave'
  },
  {
    keywords: ['salary', 'pay', 'payroll'],
    responses: [
      "I can assist with payroll inquiries. Would you like to view your latest payslip?",
      "For payroll questions, I can help you access your payment history."
    ],
    category: 'payroll'
  }
];

export function generateResponse(message: string): { content: string; category: string } {
  const lowercaseMessage = message.toLowerCase();
  
  for (const pattern of responsePatterns) {
    if (pattern.keywords.some(keyword => lowercaseMessage.includes(keyword))) {
      const randomResponse = pattern.responses[Math.floor(Math.random() * pattern.responses.length)];
      return { content: randomResponse, category: pattern.category };
    }
  }

  return {
    content: "I understand your query. How can I assist you with HR matters?",
    category: 'general'
  };
}

export function analyzeSentiment(message: string): Message['sentiment'] {
  const positiveWords = ['thanks', 'good', 'great', 'helpful'];
  const negativeWords = ['bad', 'wrong', 'unhelpful', 'issue'];
  
  const lowercaseMessage = message.toLowerCase();
  
  if (positiveWords.some(word => lowercaseMessage.includes(word))) {
    return 'positive';
  }
  if (negativeWords.some(word => lowercaseMessage.includes(word))) {
    return 'negative';
  }
  return 'neutral';
}