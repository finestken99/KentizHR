import { z } from 'zod';

export const messages = {
  required: 'This field is required',
  email: 'Please enter a valid email address',
  password: 'Password must be at least 8 characters',
  passwordMatch: 'Passwords do not match',
  minLength: (field: string, length: number) => `${field} must be at least ${length} characters`
};

export const registerSchema = z.object({
  email: z.string().email(messages.email),
  password: z.string().min(8, messages.password),
  confirmPassword: z.string(),
  firstName: z.string().min(2, messages.minLength('First name', 2)),
  lastName: z.string().min(2, messages.minLength('Last name', 2)),
  company: z.string().min(2, messages.minLength('Company name', 2))
}).refine((data) => data.password === data.confirmPassword, {
  message: messages.passwordMatch,
  path: ['confirmPassword']
});

export function validateField(schema: z.ZodType, value: unknown) {
  try {
    schema.parse(value);
    return { valid: true };
  } catch (error) {
    if (error instanceof z.ZodError) {
      return { valid: false, error: error.errors[0].message };
    }
    return { valid: false, error: 'Invalid input' };
  }
}