import { getDb } from './index';
import { USER_QUERIES } from './queries/users';
import { SESSION_QUERIES } from './queries/sessions';
import { JWT_CONFIG } from './config';
import { User, RegisterData, LoginResponse } from './models/user';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

export const userDb = {
  async register(data: RegisterData): Promise<User | null> {
    const db = await getDb();
    const passwordHash = bcrypt.hashSync(data.password, 10);
    
    try {
      db.run(USER_QUERIES.CREATE_USER, 
        [data.email, passwordHash, data.first_name, data.last_name, data.company]
      );
      
      const result = db.exec(USER_QUERIES.GET_USER_BY_EMAIL, [data.email]);
      return result[0] as User;
    } catch (error) {
      console.error('Registration error:', error);
      return null;
    }
  },

  async login(email: string, password: string): Promise<LoginResponse | null> {
    const db = await getDb();
    
    try {
      const result = db.exec(USER_QUERIES.GET_USER_BY_EMAIL, [email]);
      const user = result[0];
      
      if (!user || !bcrypt.compareSync(password, user.password_hash)) {
        return null;
      }

      const token = jwt.sign(
        { userId: user.id, role: user.role },
        JWT_CONFIG.secret,
        { expiresIn: JWT_CONFIG.expiresIn }
      );

      db.run(SESSION_QUERIES.CREATE_SESSION, [user.id, token]);

      const { password_hash, ...userWithoutPassword } = user;
      return { user: userWithoutPassword, token };
    } catch (error) {
      console.error('Login error:', error);
      return null;
    }
  }
};