import Dexie from 'dexie';
import type { User, RegisterData, LoginResponse } from './models/types';

class KentizDatabase extends Dexie {
  users!: Dexie.Table<User, number>;

  constructor() {
    super('kentiz-db');
    
    this.version(1).stores({
      users: '++id, email, role, status'
    });
  }

  async initialize() {
    try {
      // Create default landlord account
      const landlordEmail = 'landlord@kentiz.com';
      const landlordExists = await this.users.where('email').equals(landlordEmail).first();
      
      if (!landlordExists) {
        await this.users.add({
          email: landlordEmail,
          password: 'landlord123',
          first_name: 'System',
          last_name: 'Landlord',
          company_name: 'Kentiz',
          role: 'landlord',
          status: 'active',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });
        console.log('Landlord account created successfully');
      }

      // Create other default accounts if needed
      const adminEmail = 'admin@kentiz.com';
      const employeeEmail = 'employee@kentiz.com';
      
      const adminExists = await this.users.where('email').equals(adminEmail).first();
      if (!adminExists) {
        await this.users.add({
          email: adminEmail,
          password: 'admin123',
          first_name: 'Admin',
          last_name: 'User',
          company_name: 'Kentiz',
          role: 'admin',
          status: 'active',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });
      }

      const employeeExists = await this.users.where('email').equals(employeeEmail).first();
      if (!employeeExists) {
        await this.users.add({
          email: employeeEmail,
          password: 'employee123',
          first_name: 'John',
          last_name: 'Doe',
          company_name: 'Kentiz',
          role: 'employee',
          status: 'active',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });
      }
    } catch (error) {
      console.error('Error initializing database:', error);
      throw error;
    }
  }
}

const db = new KentizDatabase();

export const browserDb = {
  initialize: () => db.initialize(),

  async register(data: RegisterData): Promise<User | null> {
    try {
      const existingUser = await db.users.where('email').equals(data.email).first();
      if (existingUser) {
        throw new Error('Email already exists');
      }

      const id = await db.users.add({
        email: data.email,
        password: data.password,
        first_name: data.first_name,
        last_name: data.last_name,
        company_name: data.company,
        role: 'employee',
        status: 'active',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });

      const user = await db.users.get(id);
      if (!user) return null;

      const { password, ...userWithoutPassword } = user;
      return userWithoutPassword;
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    }
  },

  async login(email: string, password: string): Promise<LoginResponse | null> {
    try {
      const user = await db.users.where('email').equals(email).first();

      if (!user || user.password !== password || user.status !== 'active') {
        return null;
      }

      const { password: _, ...userWithoutPassword } = user;
      const tokenData = {
        user: userWithoutPassword,
        exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60)
      };

      const token = btoa(JSON.stringify(tokenData));
      return { user: userWithoutPassword, token };
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  }
};