export const SESSION_QUERIES = {
  CREATE_TABLE: `
    CREATE TABLE IF NOT EXISTS sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      token TEXT NOT NULL,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id)
    )
  `,

  CREATE_SESSION: `
    INSERT INTO sessions (user_id, token, expires_at)
    VALUES (?, ?, datetime('now', '+24 hours'))
  `
};