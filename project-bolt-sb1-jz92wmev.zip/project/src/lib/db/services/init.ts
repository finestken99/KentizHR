import bcrypt from 'bcryptjs';
import { User } from '../models';
import { config } from '../../config/env';

export async function initializeAdminUser() {
  try {
    const adminEmail = 'admin@kentiz.com';
    const adminExists = await User.findOne({ email: adminEmail });
    
    if (!adminExists) {
      const passwordHash = await bcrypt.hash('admin123', 10);
      await User.create({
        email: adminEmail,
        password_hash: passwordHash,
        first_name: 'Admin',
        last_name: 'User',
        company: 'Kentiz',
        role: 'admin'
      });
      console.log('Admin user created successfully');
    }
  } catch (error: any) {
    console.error('Admin user initialization error:', error.message);
  }
}