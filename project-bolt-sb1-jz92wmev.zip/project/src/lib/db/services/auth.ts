import bcrypt from 'bcryptjs';
import { User, Session } from '../models';
import { createToken } from '../../auth/jwt';
import { config } from '../../config/env';
import type { RegisterData, LoginResponse } from '../types';

export const authService = {
  async register(data: RegisterData) {
    try {
      const passwordHash = await bcrypt.hash(data.password, 10);
      
      const user = await User.create({
        email: data.email,
        password_hash: passwordHash,
        first_name: data.first_name,
        last_name: data.last_name,
        company: data.company,
        role: 'employee'
      });

      const { password_hash: _, ...userWithoutPassword } = user.toObject();
      return userWithoutPassword;
    } catch (error) {
      console.error('Registration error:', error);
      return null;
    }
  },

  async login(email: string, password: string): Promise<LoginResponse | null> {
    try {
      const user = await User.findOne({ email }).lean();

      if (!user || !(await bcrypt.compare(password, user.password_hash))) {
        return null;
      }

      const token = createToken(
        { userId: user._id, role: user.role },
        config.jwt.secret
      );

      await Session.create({
        user_id: user._id,
        token,
        expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000)
      });

      const { password_hash: _, ...userWithoutPassword } = user;
      return { user: userWithoutPassword, token };
    } catch (error) {
      console.error('Login error:', error);
      return null;
    }
  }
};