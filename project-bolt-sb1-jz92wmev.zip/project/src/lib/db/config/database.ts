import mongoose from 'mongoose';
import { config } from '../../config/env';
import { initializeAdminUser } from '../services/init';

const MONGODB_URI = config.mongodb.uri;

if (!MONGODB_URI) {
  throw new Error('Please define the MONGODB_URI environment variable');
}

// Define cached type for browser environment
interface CachedConnection {
  conn: typeof mongoose | null;
  promise: Promise<typeof mongoose> | null;
}

// Use window object for browser environment
declare const window: Window & {
  mongoose?: CachedConnection;
};

// Initialize cache in browser environment
const cached: CachedConnection = window.mongoose || { conn: null, promise: null };
if (typeof window !== 'undefined') {
  window.mongoose = cached;
}

export async function connectDB() {
  if (cached.conn) {
    return cached.conn;
  }

  if (!cached.promise) {
    const opts = {
      bufferCommands: false,
      dbName: 'kentiz',
      autoIndex: true
    };

    console.log('Connecting to MongoDB...');
    cached.promise = mongoose.connect(MONGODB_URI, opts).then((mongoose) => {
      console.log('MongoDB Connected Successfully');
      return mongoose;
    });
  }

  try {
    cached.conn = await cached.promise;
    
    if (config.isDevelopment) {
      await initializeAdminUser();
    }
    
    return cached.conn;
  } catch (error: any) {
    cached.promise = null;
    console.error('MongoDB connection error:', error.message);
    throw new Error(`Failed to connect to MongoDB: ${error.message}`);
  }
}

export async function disconnectDB() {
  if (cached.conn) {
    await cached.conn.disconnect();
    cached.conn = null;
    cached.promise = null;
    console.log('MongoDB Disconnected');
  }
}