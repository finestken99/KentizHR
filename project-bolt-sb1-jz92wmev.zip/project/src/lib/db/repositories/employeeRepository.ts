import { db } from '../models/database';
import { BaseRepository } from './baseRepository';
import type { Employee } from '../models/types';

export class EmployeeRepository extends BaseRepository<Employee> {
  constructor() {
    super(db.employees);
  }

  async findByTenant(tenantId: number): Promise<Employee[]> {
    return this.table.where('tenant_id').equals(tenantId).toArray();
  }

  async findByDepartment(tenantId: number, department: string): Promise<Employee[]> {
    return this.table
      .where(['tenant_id', 'department'])
      .equals([tenantId, department])
      .toArray();
  }

  async updateStatus(id: number, status: Employee['status']): Promise<void> {
    await this.update(id, { status });
  }
}

export const employeeRepository = new EmployeeRepository();