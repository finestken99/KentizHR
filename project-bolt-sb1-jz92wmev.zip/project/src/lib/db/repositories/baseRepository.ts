import { Dexie } from 'dexie';
import type { BaseModel } from '../models/types';

export class BaseRepository<T extends BaseModel> {
  protected table: Dexie.Table<T, number>;

  constructor(table: Dexie.Table<T, number>) {
    this.table = table;
  }

  async create(data: Omit<T, 'id' | 'created_at' | 'updated_at'>): Promise<T> {
    const now = new Date().toISOString();
    const id = await this.table.add({
      ...data,
      created_at: now,
      updated_at: now
    } as T);
    return this.table.get(id) as Promise<T>;
  }

  async update(id: number, data: Partial<T>): Promise<T | undefined> {
    await this.table.update(id, {
      ...data,
      updated_at: new Date().toISOString()
    });
    return this.table.get(id);
  }

  async delete(id: number): Promise<void> {
    await this.table.delete(id);
  }

  async findById(id: number): Promise<T | undefined> {
    return this.table.get(id);
  }

  async findAll(): Promise<T[]> {
    return this.table.toArray();
  }
}