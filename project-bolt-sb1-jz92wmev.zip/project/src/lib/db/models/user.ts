export interface User {
  id?: number;
  email: string;
  password?: string;
  first_name: string;
  last_name: string;
  company: string;
  role: string;
  created_at?: string;
  updated_at?: string;
}

export interface RegisterData {
  email: string;
  password: string;
  first_name: string;
  last_name: string;
  company: string;
}

export interface LoginResponse {
  user: Omit<User, 'password'>;
  token: string;
}