import { TableSchema } from '../types';

export const employeeSchema: TableSchema = {
  id: '++id',
  email: '&email',
  tenant_id: 'tenant_id',
  position: '',
  department: '',
  status: 'status',
  created_at: '',
  updated_at: ''
};