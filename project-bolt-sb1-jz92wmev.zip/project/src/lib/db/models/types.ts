export interface TableSchema {
  [key: string]: string;
}

export interface BaseModel {
  id?: number;
  created_at: string;
  updated_at: string;
}

export interface User extends BaseModel {
  email: string;
  role: 'admin' | 'landlord' | 'tenant' | 'employee';
  first_name: string;
  last_name: string;
  company_name?: string;
  password: string;
  status: 'active' | 'inactive';
}

export interface Tenant extends BaseModel {
  company_name: string;
  email: string;
  subscription_status: 'active' | 'inactive' | 'pending';
  landlord_id: number;
}

export interface Employee extends BaseModel {
  email: string;
  tenant_id: number;
  position: string;
  department: string;
  status: 'active' | 'inactive' | 'on_leave';
}