import { User } from './mongoose/user';
import { Session } from './mongoose/session';

export { User, Session };

export const models = {
  User,
  Session
};