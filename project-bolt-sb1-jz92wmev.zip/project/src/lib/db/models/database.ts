import Dexie from 'dexie';
import type { User, Tenant, Employee } from './types';

class AppDatabase extends Dexie {
  users!: Dexie.Table<User, number>;
  tenants!: Dexie.Table<Tenant, number>;
  employees!: Dexie.Table<Employee, number>;

  constructor() {
    super('kentiz-db');
    
    this.version(1)
      .stores({
        users: '++id, email, role, &[email+role]',
        tenants: '++id, &company_name, &email, subscription_status, landlord_id',
        employees: '++id, &email, tenant_id, department, status'
      });
  }

  async initialize() {
    // Create default landlord account
    const landlordEmail = 'landlord@kentiz.com';
    const landlordExists = await this.users.where('email').equals(landlordEmail).first();
    
    if (!landlordExists) {
      await this.users.add({
        email: landlordEmail,
        password: 'landlord123', // In production, this should be hashed
        first_name: 'System',
        last_name: 'Landlord',
        company_name: 'Kentiz',
        role: 'landlord',
        status: 'active',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });
      console.log('Landlord account created successfully');
    }

    // Create other default accounts
    const adminEmail = 'admin@kentiz.com';
    const employeeEmail = 'employee@kentiz.com';
    
    const adminExists = await this.users.where('email').equals(adminEmail).first();
    if (!adminExists) {
      await this.users.add({
        email: adminEmail,
        password: 'admin123',
        first_name: 'Admin',
        last_name: 'User',
        company_name: 'Kentiz',
        role: 'admin',
        status: 'active',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });
      console.log('Admin account created successfully');
    }

    const employeeExists = await this.users.where('email').equals(employeeEmail).first();
    if (!employeeExists) {
      await this.users.add({
        email: employeeEmail,
        password: 'employee123',
        first_name: 'John',
        last_name: 'Doe',
        company_name: 'Kentiz',
        role: 'employee',
        status: 'active',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });
      console.log('Employee account created successfully');
    }
  }
}

export const db = new AppDatabase();