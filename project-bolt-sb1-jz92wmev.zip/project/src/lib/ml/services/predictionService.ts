import { AttritionModel } from '../models/attritionModel';
import { PerformanceModel } from '../models/performanceModel';
import { DataPreprocessor, EmployeeData } from '../preprocessing/dataPreprocessing';

export class PredictionService {
  private attritionModel: AttritionModel;
  private performanceModel: PerformanceModel;
  private dataPreprocessor: DataPreprocessor;

  constructor() {
    this.attritionModel = new AttritionModel();
    this.performanceModel = new PerformanceModel();
    this.dataPreprocessor = new DataPreprocessor();
  }

  async initialize() {
    await Promise.all([
      this.attritionModel.initialize(),
      this.performanceModel.initialize()
    ]);

    try {
      await this.attritionModel.load('attrition-model');
    } catch (error) {
      console.log('No saved attrition model found, will train new model');
    }
  }

  async predictAttritionRisk(employee: EmployeeData): Promise<{
    risk: number;
    factors: string[];
  }> {
    const normalizedData = this.dataPreprocessor.normalizeData([employee])[0];
    const risk = await this.attritionModel.predict(normalizedData);

    const factors = this.analyzeRiskFactors(employee, risk);

    return {
      risk: parseFloat(risk.toFixed(2)),
      factors
    };
  }

  private analyzeRiskFactors(employee: EmployeeData, risk: number): string[] {
    const factors: string[] = [];

    if (employee.performanceScore < 3) {
      factors.push('Low performance score');
    }
    if (employee.overtimeHours > 200) {
      factors.push('High overtime hours');
    }
    if (employee.absenceDays > 15) {
      factors.push('High absence rate');
    }
    if (employee.trainingHours < 20) {
      factors.push('Low training participation');
    }

    return factors;
  }

  async predictPerformance(employee: EmployeeData): Promise<{
    predictedScore: number;
    recommendations: string[];
  }> {
    const normalizedData = this.dataPreprocessor.normalizeData([employee])[0];
    const predictedScore = await this.performanceModel.predict(normalizedData);

    const recommendations = this.generateRecommendations(employee, predictedScore);

    return {
      predictedScore: parseFloat(predictedScore.toFixed(2)),
      recommendations
    };
  }

  private generateRecommendations(employee: EmployeeData, predictedScore: number): string[] {
    const recommendations: string[] = [];

    if (employee.trainingHours < 40) {
      recommendations.push('Increase participation in training programs');
    }
    if (employee.projectsCompleted < 10) {
      recommendations.push('Take on more project responsibilities');
    }
    if (employee.overtimeHours > 300) {
      recommendations.push('Consider better work-life balance');
    }

    return recommendations;
  }
}