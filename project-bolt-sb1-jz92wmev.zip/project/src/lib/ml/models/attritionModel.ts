import * as tf from '@tensorflow/tfjs';

export class AttritionModel {
  private model: tf.LayersModel | null = null;

  async initialize() {
    // Create a sequential model
    this.model = tf.sequential({
      layers: [
        tf.layers.dense({ inputShape: [8], units: 16, activation: 'relu' }),
        tf.layers.dense({ units: 8, activation: 'relu' }),
        tf.layers.dense({ units: 1, activation: 'sigmoid' })
      ]
    });

    // Compile the model
    this.model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'binaryCrossentropy',
      metrics: ['accuracy']
    });
  }

  async train(data: number[][], labels: number[]) {
    if (!this.model) {
      throw new Error('Model not initialized');
    }

    const xs = tf.tensor2d(data);
    const ys = tf.tensor2d(labels, [labels.length, 1]);

    await this.model.fit(xs, ys, {
      epochs: 50,
      batchSize: 32,
      validationSplit: 0.2,
      callbacks: {
        onEpochEnd: (epoch, logs) => {
          console.log(`Epoch ${epoch}: loss = ${logs?.loss.toFixed(4)}`);
        }
      }
    });

    xs.dispose();
    ys.dispose();
  }

  async predict(input: number[]): Promise<number> {
    if (!this.model) {
      throw new Error('Model not initialized');
    }

    const inputTensor = tf.tensor2d([input]);
    const prediction = await this.model.predict(inputTensor) as tf.Tensor;
    const result = await prediction.data();
    
    inputTensor.dispose();
    prediction.dispose();

    return result[0];
  }

  async save(path: string) {
    if (!this.model) {
      throw new Error('Model not initialized');
    }
    await this.model.save(`localstorage://${path}`);
  }

  async load(path: string) {
    this.model = await tf.loadLayersModel(`localstorage://${path}`);
  }
}