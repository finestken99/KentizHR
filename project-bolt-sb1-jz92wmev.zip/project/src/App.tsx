import React from 'react';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer/Footer';
import { useHash } from './hooks/useHash';
import { UserProvider } from './contexts/UserContext';

// Pages
import { HomePage } from './pages/HomePage';
import { ProductsPage } from './pages/ProductsPage';
import { SolutionsPage } from './pages/SolutionsPage';
import { TechnicalPage } from './pages/TechnicalPage';
import { PricingPage } from './pages/PricingPage';
import { ResourcesPage } from './pages/ResourcesPage';
import { LoginPage } from './components/auth/LoginPage';
import { LandlordLoginPage } from './components/auth/LandlordLoginPage';
import { RegisterPage } from './components/auth/RegisterPage';
import { ForgotPasswordPage } from './components/auth/ForgotPasswordPage';
import { ResetPasswordPage } from './components/auth/ResetPasswordPage';
import { AdminLoginPage } from './components/admin/AdminLoginPage';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { EmployeeDashboard } from './components/employee/EmployeeDashboard';
import { TenantManagement } from './components/landlord/TenantManagement';

function App() {
  const hash = useHash();

  const renderPage = () => {
    switch (hash.split('/')[0]) {
      case '#products':
        return <ProductsPage />;
      case '#solutions':
        return <SolutionsPage />;
      case '#technical':
        return <TechnicalPage />;
      case '#pricing':
        return <PricingPage />;
      case '#resources':
        return <ResourcesPage />;
      case '#login':
        return <LoginPage />;
      case '#landlord-login':
        return <LandlordLoginPage />;
      case '#register':
        return <RegisterPage />;
      case '#forgot-password':
        return <ForgotPasswordPage />;
      case '#reset-password':
        return <ResetPasswordPage />;
      case '#admin-login':
        return <AdminLoginPage />;
      case '#admin-dashboard':
        return <AdminDashboard />;
      case '#dashboard':
        return <EmployeeDashboard />;
      case '#tenants':
        return <TenantManagement />;
      default:
        return <HomePage />;
    }
  };

  const hideHeaderFooter = hash.startsWith('#admin-') || 
                          hash.startsWith('#dashboard') || 
                          hash.startsWith('#tenants');

  return (
    <UserProvider>
      <div className="min-h-screen bg-gray-50">
        {!hideHeaderFooter && <Header />}
        <main className={!hideHeaderFooter ? 'pt-16' : ''}>
          {renderPage()}
        </main>
        {!hideHeaderFooter && <Footer />}
      </div>
    </UserProvider>
  );
}

export default App;