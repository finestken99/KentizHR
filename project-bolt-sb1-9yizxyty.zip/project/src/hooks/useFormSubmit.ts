import { useState } from 'react';
import { z } from 'zod';

interface UseFormSubmitOptions<T> {
  schema: z.ZodType<T>;
  onSubmit: (data: T) => Promise<void>;
}

export function useFormSubmit<T>({ schema, onSubmit }: UseFormSubmitOptions<T>) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (data: unknown) => {
    try {
      setError(null);
      setLoading(true);

      const validatedData = schema.parse(data);
      await onSubmit(validatedData);
    } catch (err) {
      if (err instanceof z.ZodError) {
        const firstError = err.errors[0];
        setError(firstError.message);
      } else if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred');
      }
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    handleSubmit,
    setError
  };
}