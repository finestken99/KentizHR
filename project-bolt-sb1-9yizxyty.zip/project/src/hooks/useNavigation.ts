export function useNavigation() {
  const navigate = (path: string, params?: Record<string, string>) => {
    let url = `#${path}`;
    if (params) {
      const searchParams = new URLSearchParams();
      Object.entries(params).forEach(([key, value]) => {
        searchParams.append(key, value);
      });
      url += `?${searchParams.toString()}`;
    }
    window.location.hash = url;
  };

  return { navigate };
}