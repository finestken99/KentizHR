import { useState, useEffect } from 'react';
import { verifyAuth, checkRole } from '../lib/auth/middleware';
import { UserRole, AuthUser } from '../lib/auth/types';

export function useAuth(requiredRoles: UserRole[] = []) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const token = localStorage.getItem('auth_token');
    const result = verifyAuth(token);

    if ('code' in result) {
      setError(result.message);
      if (result.code === 'TOKEN_EXPIRED') {
        localStorage.removeItem('auth_token');
        window.location.hash = '#login';
      }
    } else {
      if (requiredRoles.length && !checkRole(result, requiredRoles)) {
        setError('Unauthorized access');
        window.location.hash = '#login';
      } else {
        setUser(result);
      }
    }
    
    setLoading(false);
  }, []);

  const logout = () => {
    localStorage.removeItem('auth_token');
    setUser(null);
    window.location.hash = '#login';
  };

  return { user, loading, error, logout };
}