import { useState, useEffect } from 'react';
import { useUser } from '../contexts/UserContext';
import { subscriptionService } from '../lib/services/subscriptionService';

export function useFeatureAccess(featureName: string) {
  const { user } = useUser();
  const [hasAccess, setHasAccess] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAccess = async () => {
      if (!user?.id) {
        setHasAccess(false);
        setLoading(false);
        return;
      }

      try {
        const access = await subscriptionService.checkFeatureAccess(user.id, featureName);
        setHasAccess(access);
      } catch (error) {
        console.error('Error checking feature access:', error);
        setHasAccess(false);
      } finally {
        setLoading(false);
      }
    };

    checkAccess();
  }, [user?.id, featureName]);

  return { hasAccess, loading };
}