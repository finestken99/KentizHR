import { useState, useEffect } from 'react';
import { useUser } from '../contexts/UserContext';
import { chatService } from '../lib/services/chatService';
import type { Message } from '../lib/types/chat';

export function useChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useUser();

  useEffect(() => {
    if (user?.id) {
      loadMessages();
    }
  }, [user?.id]);

  const loadMessages = async () => {
    try {
      const savedMessages = await chatService.getMessages(user!.id!);
      setMessages(savedMessages);
    } catch (error) {
      console.error('Error loading messages:', error);
    } finally {
      setLoading(false);
    }
  };

  const addMessage = async (content: string, type: 'user' | 'bot') => {
    if (!user?.id) return;

    const newMessage = {
      userId: user.id,
      type,
      content,
      timestamp: new Date()
    };

    try {
      await chatService.saveMessage(newMessage);
      setMessages(prev => [...prev, newMessage]);
    } catch (error) {
      console.error('Error adding message:', error);
      throw error;
    }
  };

  const clearChat = async () => {
    if (!user?.id) return;

    try {
      await chatService.clearMessages(user.id);
      setMessages([]);
    } catch (error) {
      console.error('Error clearing chat:', error);
      throw error;
    }
  };

  return {
    messages,
    loading,
    addMessage,
    clearChat
  };
}