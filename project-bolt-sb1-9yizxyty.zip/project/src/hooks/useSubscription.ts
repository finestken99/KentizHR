import { useState, useEffect } from 'react';
import { useUser } from '../contexts/UserContext';
import { subscriptionService } from '../lib/services/subscriptionService';
import type { SubscriptionPlan } from '../lib/db/models/types/subscription';

export function useSubscription(featureName?: string) {
  const { user } = useUser();
  const [currentPlan, setCurrentPlan] = useState<SubscriptionPlan | null>(null);
  const [hasAccess, setHasAccess] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadSubscription = async () => {
      if (!user?.id) {
        setLoading(false);
        return;
      }

      try {
        const result = await subscriptionService.getCurrentPlan(user.id);
        if (result) {
          setCurrentPlan(result.plan);
          
          if (featureName) {
            const access = await subscriptionService.checkFeatureAccess(user.id, featureName);
            setHasAccess(access);
          }
        }
      } catch (error) {
        console.error('Error loading subscription:', error);
      } finally {
        setLoading(false);
      }
    };

    loadSubscription();
  }, [user?.id, featureName]);

  return {
    currentPlan,
    hasAccess,
    loading
  };
}