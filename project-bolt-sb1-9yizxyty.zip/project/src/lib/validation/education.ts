```typescript
import { z } from 'zod';

export const educationSchema = z.object({
  degree: z.string().min(2, 'Degree is required'),
  institution: z.string().min(2, 'Institution is required'),
  field: z.string().min(2, 'Field of study is required'),
  startDate: z.string().min(1, 'Start date is required'),
  endDate: z.string().min(1, 'End date is required'),
  gpa: z.string().optional()
}).refine((data) => {
  const start = new Date(data.startDate);
  const end = new Date(data.endDate);
  return start <= end;
}, {
  message: 'End date must be after start date',
  path: ['endDate']
});

export const certificationSchema = z.object({
  name: z.string().min(2, 'Certification name is required'),
  issuer: z.string().min(2, 'Issuing organization is required'),
  dateObtained: z.string().min(1, 'Date obtained is required'),
  expiryDate: z.string().optional(),
  credentialId: z.string().optional()
}).refine((data) => {
  if (data.expiryDate) {
    const obtained = new Date(data.dateObtained);
    const expiry = new Date(data.expiryDate);
    return obtained <= expiry;
  }
  return true;
}, {
  message: 'Expiry date must be after date obtained',
  path: ['expiryDate']
});

export type EducationData = z.infer<typeof educationSchema>;
export type CertificationData = z.infer<typeof certificationSchema>;
```