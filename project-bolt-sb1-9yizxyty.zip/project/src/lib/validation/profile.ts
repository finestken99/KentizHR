import { z } from 'zod';

export const personalInfoSchema = z.object({
  firstName: z.string().min(2, 'First name must be at least 2 characters'),
  lastName: z.string().min(2, 'Last name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  phone: z.string().min(10, 'Phone number must be at least 10 digits'),
  address: z.string().min(5, 'Address must be at least 5 characters'),
  city: z.string().min(2, 'City must be at least 2 characters'),
  state: z.string().min(2, 'State must be at least 2 characters'),
  zipCode: z.string().regex(/^\d{5}(-\d{4})?$/, 'Invalid ZIP code')
});

export const workInfoSchema = z.object({
  department: z.string().min(2, 'Department is required'),
  position: z.string().min(2, 'Position is required'),
  startDate: z.string().min(1, 'Start date is required'),
  manager: z.string().min(2, 'Manager name is required'),
  employeeId: z.string().min(1, 'Employee ID is required'),
  workLocation: z.string().min(2, 'Work location is required'),
  workEmail: z.string().email('Invalid work email address'),
  workPhone: z.string().min(10, 'Work phone must be at least 10 digits')
});

export const emergencyContactSchema = z.object({
  name: z.string().min(2, 'Contact name is required'),
  relationship: z.string().min(2, 'Relationship is required'),
  phone: z.string().min(10, 'Phone number must be at least 10 digits'),
  email: z.string().email('Invalid email address')
});

export type PersonalInfoData = z.infer<typeof personalInfoSchema>;
export type WorkInfoData = z.infer<typeof workInfoSchema>;
export type EmergencyContactData = z.infer<typeof emergencyContactSchema>;