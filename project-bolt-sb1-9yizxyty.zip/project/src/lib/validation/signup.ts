import { z } from 'zod';

export const accountSetupSchema = z.object({
  companyName: z.string()
    .min(2, 'Company name must be at least 2 characters')
    .max(100, 'Company name cannot exceed 100 characters'),
  
  adminEmail: z.string()
    .email('Please enter a valid email address')
    .min(5, 'Email must be at least 5 characters')
    .max(100, 'Email cannot exceed 100 characters'),
  
  password: z.string()
    .min(8, 'Password must be at least 8 characters')
    .max(100, 'Password cannot exceed 100 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number')
    .regex(/[^A-Za-z0-9]/, 'Password must contain at least one special character'),

  firstName: z.string()
    .min(2, 'First name must be at least 2 characters')
    .max(50, 'First name cannot exceed 50 characters'),

  lastName: z.string()
    .min(2, 'Last name must be at least 2 characters')
    .max(50, 'Last name cannot exceed 50 characters'),
  
  industry: z.string()
    .min(1, 'Please select an industry'),
  
  size: z.string()
    .min(1, 'Please select company size')
});

export const systemConfigSchema = z.object({
  departments: z.array(z.string())
    .min(1, 'Please select at least one department'),
  
  workingHours: z.object({
    start: z.string()
      .min(1, 'Please set working hours start time'),
    end: z.string()
      .min(1, 'Please set working hours end time')
  }),
  
  leaveDays: z.number()
    .min(0, 'Leave days cannot be negative')
    .max(365, 'Leave days cannot exceed 365')
});

export type AccountSetupData = z.infer<typeof accountSetupSchema>;
export type SystemConfigData = z.infer<typeof systemConfigSchema>;