import { JWT_SECRET } from '../constants';

export const API_CONFIG = {
  baseURL: '/api',
  version: 'v1',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
};

export const AUTH_CONFIG = {
  tokenKey: 'auth_token',
  tokenExpiry: '24h',
  secret: JWT_SECRET
};