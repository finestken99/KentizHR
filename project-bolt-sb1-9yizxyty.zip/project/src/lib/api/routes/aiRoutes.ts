import { Router } from 'express';
import { aiService } from '../../ml/services/aiService';
import { authMiddleware } from '../middleware/auth';
import { UserRole } from '../../auth/types';

const router = Router();

// Initialize AI service
let aiServiceInitialized = false;
const initializeAIService = async (req: any, res: any, next: any) => {
  if (!aiServiceInitialized) {
    try {
      await aiService.initialize();
      aiServiceInitialized = true;
    } catch (error) {
      console.error('Failed to initialize AI service:', error);
      return res.status(500).json({ error: 'AI service initialization failed' });
    }
  }
  next();
};

router.use(initializeAIService);

// Employee attrition prediction
router.post(
  '/predict/attrition',
  authMiddleware([UserRole.ADMIN]),
  async (req, res) => {
    try {
      const prediction = await aiService.predictEmployeeAttrition(req.body);
      res.json(prediction);
    } catch (error) {
      res.status(500).json({ error: 'Failed to predict attrition risk' });
    }
  }
);

// Performance prediction
router.post(
  '/predict/performance',
  authMiddleware([UserRole.ADMIN]),
  async (req, res) => {
    try {
      const prediction = await aiService.predictPerformance(req.body);
      res.json(prediction);
    } catch (error) {
      res.status(500).json({ error: 'Failed to predict performance' });
    }
  }
);

// Career recommendations
router.post(
  '/recommendations/career',
  authMiddleware([UserRole.ADMIN, UserRole.EMPLOYEE]),
  async (req, res) => {
    try {
      const recommendations = await aiService.generateCareerRecommendations(req.body);
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ error: 'Failed to generate career recommendations' });
    }
  }
);

// Team dynamics analysis
router.post(
  '/analyze/team',
  authMiddleware([UserRole.ADMIN]),
  async (req, res) => {
    try {
      const analysis = await aiService.analyzeTeamDynamics(req.body);
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ error: 'Failed to analyze team dynamics' });
    }
  }
);

export { router as aiRoutes };