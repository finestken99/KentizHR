import { Router } from 'express';
import { employeeController } from '../controllers/employeeController';
import { authMiddleware } from '../middleware/auth';
import { UserRole } from '../../auth/types';

const router = Router();

// Add delete endpoint with admin authorization
router.delete(
  '/:id',
  authMiddleware([UserRole.ADMIN]),
  employeeController.deleteEmployee
);

export { router as employeeRoutes };