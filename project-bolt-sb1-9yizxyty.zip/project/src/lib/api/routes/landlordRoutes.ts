import { Router } from 'express';
import { landlordController } from '../controllers/landlordController';
import { authMiddleware } from '../middleware/auth';
import { UserRole } from '../../auth/types';

const router = Router();

router.post('/login', landlordController.login);
router.post('/register', landlordController.register);
router.get('/tenants', authMiddleware([UserRole.LANDLORD]), landlordController.getTenants);
router.post('/tenant', authMiddleware([UserRole.LANDLORD]), landlordController.createTenant);

export { router as landlordRoutes };