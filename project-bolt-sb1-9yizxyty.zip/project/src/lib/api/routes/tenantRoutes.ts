import { Router } from 'express';
import { tenantController } from '../controllers/tenantController';
import { authMiddleware } from '../middleware/auth';
import { UserRole } from '../../auth/types';

const router = Router();

router.post('/login', tenantController.login);
router.get('/employees', authMiddleware([UserRole.TENANT]), tenantController.getEmployees);
router.post('/employee', authMiddleware([UserRole.TENANT]), tenantController.createEmployee);
router.get('/profile', authMiddleware([UserRole.TENANT]), tenantController.getProfile);

export { router as tenantRoutes };