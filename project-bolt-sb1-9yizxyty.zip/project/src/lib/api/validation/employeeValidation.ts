import { z } from 'zod';

const employeeSchema = z.object({
  email: z.string().email('Invalid email address'),
  firstName: z.string().min(2, 'First name must be at least 2 characters'),
  lastName: z.string().min(2, 'Last name must be at least 2 characters'),
  position: z.string().min(2, 'Position must be at least 2 characters'),
  department: z.string().min(2, 'Department must be at least 2 characters')
});

export function validateEmployeeData(data: unknown) {
  try {
    employeeSchema.parse(data);
    return { success: true, errors: null };
  } catch (error) {
    if (error instanceof z.ZodError) {
      const errors = error.errors.reduce((acc, curr) => ({
        ...acc,
        [curr.path[0]]: curr.message
      }), {});
      return { success: false, errors };
    }
    return { success: false, errors: { _form: 'Invalid data' } };
  }
}