import { apiClient } from '../client';

export interface PerformanceMetrics {
  goals: {
    completed: number;
    inProgress: number;
    total: number;
  };
  feedback: {
    score: number;
    trend: number;
    recentFeedback: Array<{
      id: number;
      type: string;
      score: number;
      comment: string;
      date: string;
    }>;
  };
  skills: {
    current: Record<string, number>;
    required: Record<string, number>;
    recommendations: string[];
  };
}

export const performanceApi = {
  getMetrics: async (employeeId: number): Promise<PerformanceMetrics> => {
    return apiClient.get<PerformanceMetrics>(`performance/${employeeId}/metrics`);
  },

  submitFeedback: async (employeeId: number, data: any): Promise<void> => {
    return apiClient.post<void>(`performance/${employeeId}/feedback`, data);
  },

  updateGoals: async (employeeId: number, data: any): Promise<void> => {
    return apiClient.put<void>(`performance/${employeeId}/goals`, data);
  },

  getSkillGaps: async (employeeId: number): Promise<any> => {
    return apiClient.get<any>(`performance/${employeeId}/skill-gaps`);
  }
};