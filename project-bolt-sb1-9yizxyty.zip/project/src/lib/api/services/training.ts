import { apiClient } from '../client';

export interface Course {
  id: number;
  title: string;
  description: string;
  duration: string;
  progress: number;
  status: string;
}

export interface TrainingMetrics {
  completedCourses: number;
  inProgress: number;
  certifications: string[];
  recommendedCourses: Course[];
}

export const trainingApi = {
  getMetrics: async (employeeId: number): Promise<TrainingMetrics> => {
    return apiClient.get<TrainingMetrics>(`training/${employeeId}/metrics`);
  },

  getCourses: async (): Promise<Course[]> => {
    return apiClient.get<Course[]>('training/courses');
  },

  enrollCourse: async (courseId: number): Promise<void> => {
    return apiClient.post<void>(`training/courses/${courseId}/enroll`, {});
  },

  updateProgress: async (courseId: number, progress: number): Promise<void> => {
    return apiClient.put<void>(`training/courses/${courseId}/progress`, { progress });
  }
};