import { apiClient } from '../client';

export interface LeaveRequest {
  id: number;
  employeeId: number;
  type: string;
  startDate: string;
  endDate: string;
  status: string;
  reason: string;
}

export interface LeaveBalance {
  type: string;
  total: number;
  used: number;
  remaining: number;
}

export const leaveApi = {
  getBalance: async (employeeId: number): Promise<LeaveBalance[]> => {
    return apiClient.get<LeaveBalance[]>(`leave/${employeeId}/balance`);
  },

  submitRequest: async (data: Omit<LeaveRequest, 'id'>): Promise<LeaveRequest> => {
    return apiClient.post<LeaveRequest>('leave/request', data);
  },

  getHistory: async (employeeId: number): Promise<LeaveRequest[]> => {
    return apiClient.get<LeaveRequest[]>(`leave/${employeeId}/history`);
  },

  cancelRequest: async (requestId: number): Promise<void> => {
    return apiClient.delete<void>(`leave/request/${requestId}`);
  }
};