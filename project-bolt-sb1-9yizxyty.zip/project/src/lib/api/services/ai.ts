import { aiService } from '../../ml/services/aiService';
import { apiClient } from '../client';

export const aiApi = {
  async predictAttrition(employeeData: any) {
    return apiClient.post<any>('ai/predict/attrition', employeeData);
  },

  async predictPerformance(employeeData: any) {
    return apiClient.post<any>('ai/predict/performance', employeeData);
  },

  async getCareerRecommendations(employeeData: any) {
    return apiClient.post<any>('ai/recommendations/career', employeeData);
  },

  async analyzeTeamDynamics(teamData: any[]) {
    return apiClient.post<any>('ai/analyze/team', teamData);
  }
};