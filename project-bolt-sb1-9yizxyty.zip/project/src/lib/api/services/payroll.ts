import { apiClient } from '../client';

export interface PayrollSummary {
  salary: number;
  deductions: Record<string, number>;
  benefits: Record<string, number>;
  netPay: number;
}

export interface PayrollHistory {
  id: number;
  date: string;
  amount: number;
  type: string;
  description: string;
}

export const payrollApi = {
  getSummary: async (employeeId: number): Promise<PayrollSummary> => {
    return apiClient.get<PayrollSummary>(`payroll/${employeeId}/summary`);
  },

  getHistory: async (employeeId: number): Promise<PayrollHistory[]> => {
    return apiClient.get<PayrollHistory[]>(`payroll/${employeeId}/history`);
  },

  getPayslip: async (payrollId: number): Promise<any> => {
    return apiClient.get<any>(`payroll/payslip/${payrollId}`);
  },

  updateBenefits: async (employeeId: number, data: any): Promise<void> => {
    return apiClient.put<void>(`payroll/${employeeId}/benefits`, data);
  }
};