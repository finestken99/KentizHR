import { apiClient } from '../client';
import type { User, LoginResponse } from '../../db/models/user';

export const authApi = {
  login: async (email: string, password: string): Promise<LoginResponse> => {
    return apiClient.post<LoginResponse>('auth/login', { email, password });
  },

  register: async (data: Omit<User, 'id'>): Promise<User> => {
    return apiClient.post<User>('auth/register', data);
  },

  logout: async (): Promise<void> => {
    return apiClient.post<void>('auth/logout', {});
  },

  verifyToken: async (): Promise<User> => {
    return apiClient.get<User>('auth/verify');
  }
};