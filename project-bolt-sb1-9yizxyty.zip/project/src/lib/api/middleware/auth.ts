import { Request, Response, NextFunction } from 'express';
import { verifyAuth } from '../../auth/middleware';
import { UserRole } from '../../auth/types';

export const authMiddleware = (allowedRoles: UserRole[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      const token = req.headers.authorization?.split(' ')[1];
      const result = verifyAuth(token);

      if ('code' in result) {
        return res.status(401).json({ error: result.message });
      }

      if (allowedRoles.length && !allowedRoles.includes(result.role)) {
        return res.status(403).json({ error: 'Unauthorized access' });
      }

      req.user = result;
      next();
    } catch (error) {
      res.status(401).json({ error: 'Authentication failed' });
    }
  };
};