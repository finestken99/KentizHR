export interface IntegrationConfig {
  type: 'oauth' | 'api_key' | 'webhook';
  provider: string;
  credentials?: {
    clientId?: string;
    clientSecret?: string;
    apiKey?: string;
    webhookUrl?: string;
  };
  settings: Record<string, any>;
}

export const supportedIntegrations = {
  slack: {
    name: 'Slack',
    type: 'oauth',
    scopes: ['chat:write', 'users:read'],
    endpoints: {
      authorize: 'https://slack.com/oauth/v2/authorize',
      token: 'https://slack.com/api/oauth.v2.access'
    }
  },
  gsuite: {
    name: 'Google Workspace',
    type: 'oauth',
    scopes: ['calendar', 'drive', 'gmail.send'],
    endpoints: {
      authorize: 'https://accounts.google.com/o/oauth2/v2/auth',
      token: 'https://oauth2.googleapis.com/token'
    }
  },
  zoom: {
    name: 'Zoom',
    type: 'oauth',
    scopes: ['meeting:write', 'user:read'],
    endpoints: {
      authorize: 'https://zoom.us/oauth/authorize',
      token: 'https://zoom.us/oauth/token'
    }
  }
};

export async function configureIntegration(
  provider: string,
  config: IntegrationConfig
): Promise<boolean> {
  try {
    // Validate provider is supported
    if (!supportedIntegrations[provider]) {
      throw new Error(`Unsupported integration provider: ${provider}`);
    }

    // Store integration configuration
    localStorage.setItem(
      `integration_${provider}`,
      JSON.stringify(config)
    );

    return true;
  } catch (error) {
    console.error('Error configuring integration:', error);
    return false;
  }
}