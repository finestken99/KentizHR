import { Request, Response } from 'express';
import { employeeService } from '../../services/employeeService';
import { validateEmployeeData } from '../validation/employeeValidation';

export const tenantController = {
  // ... other controller methods ...

  async createEmployee(req: Request, res: Response) {
    try {
      // Validate request data
      const validationResult = validateEmployeeData(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: 'Invalid employee data', 
          details: validationResult.errors 
        });
      }

      // Create employee
      const result = await employeeService.createEmployee(req.user.id, req.body);
      
      res.status(201).json({
        message: 'Employee created successfully',
        data: result
      });
    } catch (error: any) {
      if (error.message === 'Email already exists') {
        return res.status(409).json({ error: error.message });
      }
      
      console.error('Error creating employee:', error);
      res.status(500).json({ error: 'Failed to create employee' });
    }
  }
};