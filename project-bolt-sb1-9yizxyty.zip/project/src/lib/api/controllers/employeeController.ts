import { Request, Response } from 'express';
import { employeeService } from '../../services/employeeService';
import { logger } from '../../utils/logger';

export const employeeController = {
  async deleteEmployee(req: Request, res: Response) {
    try {
      const { id } = req.params;
      
      // Log deletion attempt
      logger.info(`Admin ${req.user.id} attempting to delete employee ${id}`);

      // Delete employee
      await employeeService.deleteEmployee(parseInt(id));

      // Log successful deletion
      logger.info(`Employee ${id} deleted successfully by admin ${req.user.id}`);

      res.json({ message: 'Employee deleted successfully' });
    } catch (error: any) {
      logger.error(`Error deleting employee: ${error.message}`);
      res.status(500).json({ error: 'Failed to delete employee' });
    }
  }
};