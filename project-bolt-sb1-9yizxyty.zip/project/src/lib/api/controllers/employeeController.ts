import { Request, Response } from 'express';
import { authService } from '../../services/authService';
import { UserRole } from '../../auth/types';

export const employeeController = {
  async login(req: Request, res: Response) {
    try {
      const { email, password } = req.body;
      const result = await authService.login(email, password);
      
      if (!result || result.user.role !== UserRole.EMPLOYEE) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Login failed' });
    }
  },

  async getProfile(req: Request, res: Response) {
    try {
      const profile = await authService.getProfile(req.user.id);
      res.json(profile);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch profile' });
    }
  },

  async updateProfile(req: Request, res: Response) {
    try {
      const profile = await authService.updateProfile(req.user.id, req.body);
      res.json(profile);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update profile' });
    }
  }
};