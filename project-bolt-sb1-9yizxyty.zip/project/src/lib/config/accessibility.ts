export const accessibilityConfig = {
  // WCAG 2.1 Level AA Compliance Settings
  contrast: {
    minimum: 4.5,      // Minimum contrast ratio for normal text
    enhanced: 7,       // Enhanced contrast ratio for better readability
    large: 3          // Minimum contrast ratio for large text
  },
  
  // Focus Indicators
  focus: {
    outlineWidth: '3px',
    outlineStyle: 'solid',
    outlineColor: '#2563EB',
    outlineOffset: '2px'
  },

  // Animation Settings
  animation: {
    reducedMotion: true,    // Honor user's reduced motion preferences
    defaultDuration: '200ms'
  },

  // Text Settings
  text: {
    minSize: '16px',
    lineHeight: 1.5,
    letterSpacing: '0.01em'
  },

  // Keyboard Navigation
  keyboard: {
    tabIndex: true,
    shortcuts: true,
    focusTrap: true
  },

  // ARIA Labels
  aria: {
    required: true,
    landmarks: true,
    descriptions: true
  }
};

export function applyAccessibilityConfig() {
  const root = document.documentElement;
  
  // Apply base styles for accessibility
  root.style.setProperty('--focus-ring-width', accessibilityConfig.focus.outlineWidth);
  root.style.setProperty('--focus-ring-color', accessibilityConfig.focus.outlineColor);
  
  // Add focus styles
  const style = document.createElement('style');
  style.textContent = `
    *:focus-visible {
      outline: var(--focus-ring-width) var(--focus-ring-color) solid !important;
      outline-offset: ${accessibilityConfig.focus.outlineOffset};
    }

    @media (prefers-reduced-motion: reduce) {
      * {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
        scroll-behavior: auto !important;
      }
    }

    .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      margin: -1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0;
    }
  `;
  
  document.head.appendChild(style);
}