export interface BrandingConfig {
  colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
  logo?: string;
  companyName: string;
}

export const defaultBranding: BrandingConfig = {
  colors: {
    primary: '#3B82F6',   // Blue
    secondary: '#10B981', // Green
    accent: '#8B5CF6'     // Purple
  },
  companyName: 'KENTIZ'
};

export function updateBranding(config: Partial<BrandingConfig>) {
  const root = document.documentElement;
  
  if (config.colors?.primary) {
    root.style.setProperty('--color-primary', config.colors.primary);
  }
  if (config.colors?.secondary) {
    root.style.setProperty('--color-secondary', config.colors.secondary);
  }
  if (config.colors?.accent) {
    root.style.setProperty('--color-accent', config.colors.accent);
  }
}