export interface WorkflowStep {
  id: string;
  name: string;
  type: 'approval' | 'notification' | 'task' | 'integration';
  config: Record<string, any>;
  nextSteps: string[];
}

export interface Workflow {
  id: string;
  name: string;
  description: string;
  trigger: 'manual' | 'scheduled' | 'event';
  steps: WorkflowStep[];
  active: boolean;
}

export const defaultWorkflows: Workflow[] = [
  {
    id: 'onboarding',
    name: 'Employee Onboarding',
    description: 'New employee onboarding process',
    trigger: 'manual',
    steps: [
      {
        id: 'docs',
        name: 'Document Collection',
        type: 'task',
        config: {
          requiredDocs: ['id', 'tax', 'bank']
        },
        nextSteps: ['notify_hr']
      },
      {
        id: 'notify_hr',
        name: 'HR Notification',
        type: 'notification',
        config: {
          template: 'onboarding_docs_ready'
        },
        nextSteps: ['approval']
      },
      {
        id: 'approval',
        name: 'HR Approval',
        type: 'approval',
        config: {
          approvers: ['hr_manager']
        },
        nextSteps: []
      }
    ],
    active: true
  }
];