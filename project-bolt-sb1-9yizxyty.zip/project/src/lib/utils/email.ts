import type { WelcomeEmailData } from '../services/types';

export async function sendWelcomeEmail(data: WelcomeEmailData): Promise<void> {
  // In a real application, this would integrate with an email service
  // For now, we'll just log the email data
  console.log('Sending welcome email:', {
    to: data.to,
    subject: 'Welcome to KENTIZ - Your Account Details',
    body: `
      Hi ${data.firstName},

      Your account has been created successfully. Here are your login credentials:

      Email: ${data.to}
      Password: ${data.password}

      Please login at: ${data.loginUrl}

      For security reasons, please change your password after your first login.

      Best regards,
      KENTIZ Team
    `
  });
}