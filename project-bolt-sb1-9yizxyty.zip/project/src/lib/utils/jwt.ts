import { JWT_SECRET } from '../constants';

export function createToken(payload: any, expiresIn: string = '24h'): string {
  const now = Math.floor(Date.now() / 1000);
  const exp = now + (parseInt(expiresIn) * 3600);
  
  const tokenPayload = {
    ...payload,
    exp
  };

  // In a real app, you'd use a proper JWT library
  // For this demo, we'll use a simple base64 encoding
  return btoa(JSON.stringify(tokenPayload));
}

export function verifyToken(token: string): any | null {
  try {
    const decoded = JSON.parse(atob(token));
    
    // Check expiration
    if (decoded.exp && decoded.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }

    return decoded;
  } catch (error) {
    return null;
  }
}