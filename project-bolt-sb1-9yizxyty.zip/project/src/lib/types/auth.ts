export interface RegisterData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  company: string;
}

export interface LoginData {
  email: string;
  password: string;
}

export interface AuthResponse {
  user: {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    role: string;
  };
  token: string;
}