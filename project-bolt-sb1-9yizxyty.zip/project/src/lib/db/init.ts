import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import { DB_CONFIG } from './config';

async function initializeDatabase() {
  const db = new Database(DB_CONFIG.path);

  try {
    console.log('Starting database initialization...');

    // Enable foreign keys
    db.pragma('foreign_keys = ON');

    // Create tables
    db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        company TEXT NOT NULL,
        role TEXT DEFAULT 'employee',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS password_reset_tokens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        token TEXT NOT NULL,
        expires_at DATETIME NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
      );

      CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        token TEXT NOT NULL,
        expires_at DATETIME NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
      );
    `);

    // Create admin user if it doesn't exist
    const { email, password, firstName, lastName, company, role } = DB_CONFIG.adminCredentials;
    const admin = db.prepare('SELECT * FROM users WHERE email = ?').get(email);

    if (!admin) {
      const passwordHash = bcrypt.hashSync(password, 10);
      db.prepare(`
        INSERT INTO users (email, password_hash, first_name, last_name, company, role)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(email, passwordHash, firstName, lastName, company, role);
      console.log('Admin user created successfully');
    }

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Database initialization error:', error);
    process.exit(1);
  } finally {
    db.close();
  }
}

initializeDatabase().catch(console.error);