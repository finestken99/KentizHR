import mongoose, { Schema, Document } from 'mongoose';

export interface IFeature extends Document {
  name: string;
  description: string;
  category: string;
  status: 'active' | 'inactive';
}

const featureSchema = new Schema({
  name: {
    type: String,
    required: true,
    unique: true
  },
  description: String,
  category: String,
  status: {
    type: String,
    enum: ['active', 'inactive'],
    default: 'active'
  }
}, {
  timestamps: true
});

export const Feature = mongoose.models.Feature || 
  mongoose.model<IFeature>('Feature', featureSchema);