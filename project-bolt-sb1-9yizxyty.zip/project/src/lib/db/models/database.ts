import Dexie from 'dexie';
import type { User, Tenant, Employee, SubscriptionPlan, Feature, PlanFeature, CompanySubscription } from './types';

class AppDatabase extends Dexie {
  users!: Dexie.Table<User, number>;
  tenants!: Dexie.Table<Tenant, number>;
  employees!: Dexie.Table<Employee, number>;
  subscriptionPlans!: Dexie.Table<SubscriptionPlan, number>;
  features!: Dexie.Table<Feature, number>;
  planFeatures!: Dexie.Table<PlanFeature, number>;
  companySubscriptions!: Dexie.Table<CompanySubscription, number>;

  constructor() {
    super('kentiz-db');
    
    this.version(2).stores({
      users: '++id, email, role, &[email+role]',
      tenants: '++id, &company_name, &email, subscription_status, landlord_id',
      employees: '++id, &email, tenant_id, department, status',
      subscriptionPlans: '++id, &name, status',
      features: '++id, &name, category, status',
      planFeatures: '++id, [plan_id+feature_id]',
      companySubscriptions: '++id, company_id, plan_id, status'
    });
  }

  async initialize() {
    // Initialize default subscription plans
    const plans = [
      {
        name: 'Starter',
        price: 29,
        billing_cycle: 'monthly',
        description: 'Perfect for small teams up to 25 employees',
        max_employees: 25,
        status: 'active'
      },
      {
        name: 'Growth',
        price: 79,
        billing_cycle: 'monthly',
        description: 'Ideal for growing teams up to 100 employees',
        max_employees: 100,
        status: 'active'
      },
      {
        name: 'Scale',
        price: 199,
        billing_cycle: 'monthly',
        description: 'Advanced features for teams up to 500 employees',
        max_employees: 500,
        status: 'active'
      },
      {
        name: 'Enterprise',
        price: 999,
        billing_cycle: 'monthly',
        description: 'Tailored solutions for large organizations',
        max_employees: 999999,
        status: 'active'
      }
    ];

    for (const plan of plans) {
      const exists = await this.subscriptionPlans.where('name').equals(plan.name).first();
      if (!exists) {
        await this.subscriptionPlans.add({
          ...plan,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });
      }
    }

    // Initialize other default data...
    await this.initializeDefaultAccounts();
  }

  private async initializeDefaultAccounts() {
    // Create default landlord account
    const landlordEmail = 'landlord@kentiz.com';
    const landlordExists = await this.users.where('email').equals(landlordEmail).first();
    
    if (!landlordExists) {
      await this.users.add({
        email: landlordEmail,
        password: 'landlord123',
        first_name: 'System',
        last_name: 'Landlord',
        company_name: 'Kentiz',
        role: 'landlord',
        status: 'active',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });
    }

    // Create other default accounts
    const defaultAccounts = [
      {
        email: 'admin@kentiz.com',
        password: 'admin123',
        first_name: 'Admin',
        last_name: 'User',
        role: 'admin'
      },
      {
        email: 'employee@kentiz.com',
        password: 'employee123',
        first_name: 'John',
        last_name: 'Doe',
        role: 'employee'
      }
    ];

    for (const account of defaultAccounts) {
      const exists = await this.users.where('email').equals(account.email).first();
      if (!exists) {
        await this.users.add({
          ...account,
          company_name: 'Kentiz',
          status: 'active',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });
      }
    }
  }
}

export const db = new AppDatabase();