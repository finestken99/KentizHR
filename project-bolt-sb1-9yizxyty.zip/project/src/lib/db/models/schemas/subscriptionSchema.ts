import { TableSchema } from '../types';

export const subscriptionSchema: TableSchema = {
  id: '++id',
  name: '&name',
  price: '',
  billing_cycle: '',
  description: '',
  max_employees: '',
  status: '',
  created_at: '',
  updated_at: ''
};

export const featureSchema: TableSchema = {
  id: '++id',
  name: '&name',
  description: '',
  category: '',
  status: '',
  created_at: '',
  updated_at: ''
};

export const planFeatureSchema: TableSchema = {
  id: '++id',
  plan_id: '',
  feature_id: '',
  status: '',
  created_at: '',
  updated_at: ''
};

export const companySubscriptionSchema: TableSchema = {
  id: '++id',
  company_id: '',
  plan_id: '',
  status: '',
  start_date: '',
  end_date: '',
  created_at: '',
  updated_at: ''
};