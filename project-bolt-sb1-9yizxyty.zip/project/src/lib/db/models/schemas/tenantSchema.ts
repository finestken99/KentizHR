import { TableSchema } from '../types';

export const tenantSchema: TableSchema = {
  id: '++id',
  company_name: '&company_name',
  email: '&email',
  subscription_status: 'subscription_status',
  landlord_id: 'landlord_id',
  created_at: '',
  updated_at: ''
};