import { TableSchema } from '../types';

export const userSchema: TableSchema = {
  id: '++id',
  email: 'email,&[email+role]',
  role: 'role,&[email+role]',
  first_name: '',
  last_name: '',
  company_name: '',
  password: '',
  status: '',
  created_at: '',
  updated_at: ''
};