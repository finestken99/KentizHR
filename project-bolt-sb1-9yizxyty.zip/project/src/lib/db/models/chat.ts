import { Message } from '../../types/chat';
import Dexie from 'dexie';

export interface ChatMessage extends Message {
  id?: number;
  userId: number;
  timestamp: Date;
}

class ChatDatabase extends Dexie {
  messages: Dexie.Table<ChatMessage, number>;

  constructor() {
    super('chat-db');
    
    this.version(1).stores({
      messages: '++id, userId, timestamp'
    });

    this.messages = this.table('messages');
  }
}

export const chatDb = new ChatDatabase();