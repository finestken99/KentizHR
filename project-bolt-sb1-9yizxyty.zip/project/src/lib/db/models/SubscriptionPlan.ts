import mongoose, { Schema, Document } from 'mongoose';

export interface ISubscriptionPlan extends Document {
  name: string;
  price: number;
  billingCycle: 'monthly' | 'yearly';
  description: string;
  maxEmployees: number;
  status: 'active' | 'inactive';
}

const subscriptionPlanSchema = new Schema({
  name: {
    type: String,
    required: true,
    unique: true
  },
  price: {
    type: Number,
    required: true
  },
  billingCycle: {
    type: String,
    enum: ['monthly', 'yearly'],
    default: 'monthly'
  },
  description: String,
  maxEmployees: Number,
  status: {
    type: String,
    enum: ['active', 'inactive'],
    default: 'active'
  }
}, {
  timestamps: true
});

export const SubscriptionPlan = mongoose.models.SubscriptionPlan || 
  mongoose.model<ISubscriptionPlan>('SubscriptionPlan', subscriptionPlanSchema);