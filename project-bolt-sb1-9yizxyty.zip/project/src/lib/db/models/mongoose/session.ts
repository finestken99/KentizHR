import mongoose, { Schema } from 'mongoose';
import { sessionSchema } from '../schemas/sessionSchema';
import type { Session as SessionType } from '../../types';

let Session: mongoose.Model<SessionType>;

try {
  // Try to get existing model
  Session = mongoose.model<SessionType>('Session');
} catch {
  // Model doesn't exist, create it
  Session = mongoose.model<SessionType>('Session', sessionSchema);
}

export { Session };