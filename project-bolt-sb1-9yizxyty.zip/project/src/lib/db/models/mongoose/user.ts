import mongoose, { Schema } from 'mongoose';
import { userSchema } from '../schemas/userSchema';
import type { User as UserType } from '../../types';

let User: mongoose.Model<UserType>;

try {
  // Try to get existing model
  User = mongoose.model<UserType>('User');
} catch {
  // Model doesn't exist, create it
  User = mongoose.model<UserType>('User', userSchema);
}

export { User };