import mongoose, { Schema, Document } from 'mongoose';

export interface ICompanySubscription extends Document {
  companyId: mongoose.Types.ObjectId;
  planId: mongoose.Types.ObjectId;
  status: 'active' | 'trialing' | 'canceled' | 'expired';
  startDate: Date;
  endDate: Date;
}

const companySubscriptionSchema = new Schema({
  companyId: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  planId: {
    type: Schema.Types.ObjectId,
    ref: 'SubscriptionPlan',
    required: true
  },
  status: {
    type: String,
    enum: ['active', 'trialing', 'canceled', 'expired'],
    default: 'active'
  },
  startDate: {
    type: Date,
    required: true,
    default: Date.now
  },
  endDate: {
    type: Date,
    required: true
  }
}, {
  timestamps: true
});

export const CompanySubscription = mongoose.models.CompanySubscription || 
  mongoose.model<ICompanySubscription>('CompanySubscription', companySubscriptionSchema);