export interface SubscriptionPlan {
  id?: number;
  name: string;
  price: number;
  billing_cycle: 'monthly' | 'yearly';
  description: string;
  max_employees: number;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface Feature {
  id?: number;
  name: string;
  description: string;
  category: string;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface PlanFeature {
  id?: number;
  plan_id: number;
  feature_id: number;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
}

export interface CompanySubscription {
  id?: number;
  company_id: number;
  plan_id: number;
  status: 'active' | 'trialing' | 'canceled' | 'expired';
  start_date: string;
  end_date: string;
  created_at: string;
  updated_at: string;
}