import { browserDb } from '../browserDb';
import { connectToDatabase } from './mongodb';

export const db = {
  async connect() {
    if (typeof window !== 'undefined') {
      // Browser environment - use IndexedDB
      return browserDb;
    } else {
      // Server environment - use MongoDB
      return connectToDatabase();
    }
  },

  async disconnect() {
    if (typeof window === 'undefined') {
      const mongoose = await connectToDatabase();
      await mongoose.disconnect();
    }
  }
};