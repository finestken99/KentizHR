export const DB_CONFIG = {
  name: 'kentiz-db',
  version: 1,
  defaultUsers: {
    admin: {
      email: 'admin@kentiz.com',
      password: 'admin123',
      firstName: 'Admin',
      lastName: 'User',
      company: 'Kentiz',
      role: 'admin'
    },
    employee: {
      email: 'employee@kentiz.com',
      password: 'employee123',
      firstName: 'John',
      lastName: 'Doe',
      company: 'Kentiz',
      role: 'employee'
    }
  }
};