export const USER_QUERIES = {
  CREATE_TABLE: `
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      company TEXT NOT NULL,
      role TEXT DEFAULT 'employee',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `,

  CREATE_USER: `
    INSERT INTO users (email, password_hash, first_name, last_name, company)
    VALUES (?, ?, ?, ?, ?)
  `,

  GET_USER_BY_EMAIL: `
    SELECT * FROM users WHERE email = ?
  `,

  GET_USER_BY_ID: `
    SELECT id, email, first_name, last_name, company, role 
    FROM users WHERE id = ?
  `
};