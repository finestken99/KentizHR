import { Document } from 'mongoose';

export interface User extends Document {
  email: string;
  password_hash: string;
  first_name: string;
  last_name: string;
  company: string;
  role: 'admin' | 'employee';
  created_at: Date;
  updated_at: Date;
}

export interface Session extends Document {
  user_id: User['_id'];
  token: string;
  expires_at: Date;
  created_at: Date;
}

export interface RegisterData {
  email: string;
  password: string;
  first_name: string;
  last_name: string;
  company: string;
}

export interface LoginResponse {
  user: Omit<User, 'password_hash'>;
  token: string;
}