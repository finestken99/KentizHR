import { db } from '../models/database';
import { BaseRepository } from './baseRepository';
import type { Tenant } from '../models/types';

export class TenantRepository extends BaseRepository<Tenant> {
  constructor() {
    super(db.tenants);
  }

  async findByLandlord(landlordId: number): Promise<Tenant[]> {
    return this.table.where('landlord_id').equals(landlordId).toArray();
  }

  async findByStatus(status: Tenant['subscription_status']): Promise<Tenant[]> {
    return this.table.where('subscription_status').equals(status).toArray();
  }

  async updateSubscriptionStatus(
    id: number, 
    status: Tenant['subscription_status']
  ): Promise<void> {
    await this.update(id, { subscription_status: status });
  }
}

export const tenantRepository = new TenantRepository();