import { db } from '../models/database';
import { BaseRepository } from './baseRepository';
import type { SubscriptionPlan, Feature, PlanFeature, CompanySubscription } from '../models/types/subscription';

export class SubscriptionRepository extends BaseRepository<SubscriptionPlan> {
  constructor() {
    super(db.subscriptionPlans);
  }

  async getActivePlans(): Promise<SubscriptionPlan[]> {
    return this.table.where('status').equals('active').toArray();
  }

  async getPlanFeatures(planId: number): Promise<Feature[]> {
    const planFeatures = await db.planFeatures
      .where('plan_id')
      .equals(planId)
      .toArray();

    const featureIds = planFeatures.map(pf => pf.feature_id);
    return db.features
      .where('id')
      .anyOf(featureIds)
      .and(feature => feature.status === 'active')
      .toArray();
  }

  async getCompanySubscription(companyId: number): Promise<CompanySubscription | undefined> {
    return db.companySubscriptions
      .where('company_id')
      .equals(companyId)
      .and(sub => sub.status === 'active' || sub.status === 'trialing')
      .first();
  }

  async checkFeatureAccess(companyId: number, featureName: string): Promise<boolean> {
    const subscription = await this.getCompanySubscription(companyId);
    if (!subscription) return false;

    const planFeatures = await this.getPlanFeatures(subscription.plan_id);
    return planFeatures.some(feature => feature.name === featureName);
  }
}

export const subscriptionRepository = new SubscriptionRepository();