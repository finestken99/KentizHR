import { db } from '../models/database';
import { BaseRepository } from './baseRepository';
import type { User } from '../models/types';
import { UserRole } from '../../auth/types';

export class UserRepository extends BaseRepository<User> {
  constructor() {
    super(db.users);
  }

  async findByEmail(email: string): Promise<User | undefined> {
    return this.table.where('email').equals(email).first();
  }

  async findByRole(role: UserRole): Promise<User[]> {
    return this.table.where('role').equals(role).toArray();
  }

  async updatePassword(id: number, password: string): Promise<void> {
    await this.update(id, { password });
  }

  async updateStatus(id: number, status: User['status']): Promise<void> {
    await this.update(id, { status });
  }
}

export const userRepository = new UserRepository();