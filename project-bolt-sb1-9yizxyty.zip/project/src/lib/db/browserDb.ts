import Dexie from 'dexie';
import type { User, RegisterData, LoginResponse } from './models/types';

class KentizDatabase extends Dexie {
  users!: Dexie.Table<User, number>;

  constructor() {
    super('kentiz-db');
    
    this.version(1).stores({
      users: '++id, email, role, status'
    });
  }

  async register(data: RegisterData): Promise<User | null> {
    try {
      // Validate required fields
      if (!data.email?.trim()) throw new Error('Email is required');
      if (!data.password?.trim()) throw new Error('Password is required');
      if (!data.first_name?.trim()) throw new Error('First name is required');
      if (!data.last_name?.trim()) throw new Error('Last name is required');
      if (!data.company?.trim()) throw new Error('Company name is required');

      // Check if email already exists
      const existingUser = await this.users.where('email').equals(data.email).first();
      if (existingUser) {
        throw new Error('An account with this email already exists');
      }

      // Create new user
      const id = await this.users.add({
        email: data.email,
        password: data.password, // In production, this should be hashed
        first_name: data.first_name,
        last_name: data.last_name,
        company_name: data.company,
        role: data.role || 'admin', // First user of company is admin
        status: 'active',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });

      const user = await this.users.get(id);
      if (!user) {
        throw new Error('Failed to create user account');
      }

      // Remove password from returned user object
      const { password, ...userWithoutPassword } = user;
      return userWithoutPassword;
    } catch (error: any) {
      console.error('Registration error:', error.message);
      throw new Error(error.message || 'Failed to create account');
    }
  }

  async login(email: string, password: string): Promise<LoginResponse | null> {
    try {
      if (!email?.trim()) throw new Error('Email is required');
      if (!password?.trim()) throw new Error('Password is required');

      const user = await this.users.where('email').equals(email).first();

      if (!user) {
        throw new Error('Invalid email or password');
      }

      if (user.password !== password) {
        throw new Error('Invalid email or password');
      }

      if (user.status !== 'active') {
        throw new Error('Account is not active');
      }

      const { password: _, ...userWithoutPassword } = user;
      const tokenData = {
        user: userWithoutPassword,
        exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60) // 24 hours
      };

      const token = btoa(JSON.stringify(tokenData));
      return { user: userWithoutPassword, token };
    } catch (error: any) {
      console.error('Login error:', error.message);
      throw new Error(error.message || 'Login failed');
    }
  }

  async initialize() {
    try {
      // Create default admin user if none exists
      const adminEmail = 'admin@kentiz.com';
      const existingAdmin = await this.users.where('email').equals(adminEmail).first();
      
      if (!existingAdmin) {
        await this.register({
          email: adminEmail,
          password: 'admin123',
          first_name: 'Admin',
          last_name: 'User',
          company: 'Kentiz',
          role: 'admin'
        });
      }
    } catch (error) {
      console.error('Database initialization error:', error);
    }
  }
}

export const browserDb = new KentizDatabase();