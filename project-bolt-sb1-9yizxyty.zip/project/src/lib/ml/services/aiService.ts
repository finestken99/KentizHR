import * as tf from '@tensorflow/tfjs';
import { PredictionService } from './predictionService';
import { DataPreprocessor } from '../preprocessing/dataPreprocessing';

export class AIService {
  private predictionService: PredictionService;
  private preprocessor: DataPreprocessor;
  private initialized: boolean = false;

  constructor() {
    this.predictionService = new PredictionService();
    this.preprocessor = new DataPreprocessor();
  }

  async initialize() {
    if (this.initialized) return;

    try {
      await tf.ready();
      await this.predictionService.initialize();
      this.initialized = true;
      console.log('AI Service initialized successfully');
    } catch (error) {
      console.error('Failed to initialize AI Service:', error);
      throw error;
    }
  }

  async predictEmployeeAttrition(employeeData: any) {
    if (!this.initialized) {
      throw new Error('AI Service not initialized');
    }

    const preprocessedData = this.preprocessor.normalizeData([employeeData])[0];
    return this.predictionService.predictAttritionRisk({
      id: employeeData.id,
      age: employeeData.age,
      yearsOfService: employeeData.yearsOfService,
      salary: employeeData.salary,
      performanceScore: employeeData.performanceScore,
      trainingHours: employeeData.trainingHours,
      projectsCompleted: employeeData.projectsCompleted,
      overtimeHours: employeeData.overtimeHours,
      absenceDays: employeeData.absenceDays
    });
  }

  async predictPerformance(employeeData: any) {
    if (!this.initialized) {
      throw new Error('AI Service not initialized');
    }

    const preprocessedData = this.preprocessor.normalizeData([employeeData])[0];
    return this.predictionService.predictPerformance({
      id: employeeData.id,
      age: employeeData.age,
      yearsOfService: employeeData.yearsOfService,
      salary: employeeData.salary,
      performanceScore: employeeData.performanceScore,
      trainingHours: employeeData.trainingHours,
      projectsCompleted: employeeData.projectsCompleted,
      overtimeHours: employeeData.overtimeHours,
      absenceDays: employeeData.absenceDays
    });
  }

  async generateCareerRecommendations(employeeData: any) {
    if (!this.initialized) {
      throw new Error('AI Service not initialized');
    }

    const { predictedScore } = await this.predictPerformance(employeeData);
    const recommendations = [];

    if (predictedScore > 4.0) {
      recommendations.push({
        type: 'promotion',
        message: 'Consider for leadership role',
        confidence: 0.85
      });
    }

    if (employeeData.trainingHours < 40) {
      recommendations.push({
        type: 'training',
        message: 'Increase training participation',
        confidence: 0.75
      });
    }

    return recommendations;
  }

  async analyzeTeamDynamics(teamData: any[]) {
    if (!this.initialized) {
      throw new Error('AI Service not initialized');
    }

    const teamMetrics = {
      overallPerformance: 0,
      riskFactors: [],
      recommendations: []
    };

    // Calculate team performance
    const performanceScores = await Promise.all(
      teamData.map(member => this.predictPerformance(member))
    );

    teamMetrics.overallPerformance = performanceScores.reduce(
      (acc, curr) => acc + curr.predictedScore, 
      0
    ) / performanceScores.length;

    // Analyze risk factors
    const attritionRisks = await Promise.all(
      teamData.map(member => this.predictEmployeeAttrition(member))
    );

    const highRiskCount = attritionRisks.filter(risk => risk.risk > 0.7).length;
    if (highRiskCount > 0) {
      teamMetrics.riskFactors.push({
        type: 'attrition',
        severity: 'high',
        message: `${highRiskCount} team members at high risk of leaving`
      });
    }

    return teamMetrics;
  }
}

export const aiService = new AIService();