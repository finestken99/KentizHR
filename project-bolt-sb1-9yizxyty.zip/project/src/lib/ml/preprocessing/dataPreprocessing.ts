export interface EmployeeData {
  id: number;
  age: number;
  yearsOfService: number;
  salary: number;
  performanceScore: number;
  trainingHours: number;
  projectsCompleted: number;
  overtimeHours: number;
  absenceDays: number;
}

export class DataPreprocessor {
  private normalizeValue(value: number, min: number, max: number): number {
    return (value - min) / (max - min);
  }

  normalizeData(data: EmployeeData[]): number[][] {
    const numericFeatures = data.map(employee => ([
      this.normalizeValue(employee.age, 20, 65),
      this.normalizeValue(employee.yearsOfService, 0, 40),
      this.normalizeValue(employee.salary, 30000, 200000),
      this.normalizeValue(employee.performanceScore, 1, 5),
      this.normalizeValue(employee.trainingHours, 0, 100),
      this.normalizeValue(employee.projectsCompleted, 0, 50),
      this.normalizeValue(employee.overtimeHours, 0, 500),
      this.normalizeValue(employee.absenceDays, 0, 30)
    ]));

    return numericFeatures;
  }

  encodeLabels(labels: string[]): number[] {
    return labels.map(label => label === 'left' ? 1 : 0);
  }
}