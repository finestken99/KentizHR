import { useState, useEffect } from 'react';
import { PredictionService } from '../services/predictionService';
import type { EmployeeData } from '../preprocessing/dataPreprocessing';

export function usePredictions() {
  const [predictionService, setPredictionService] = useState<PredictionService | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const initializeService = async () => {
      try {
        const service = new PredictionService();
        await service.initialize();
        setPredictionService(service);
      } catch (err) {
        setError('Failed to initialize prediction service');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    initializeService();
  }, []);

  const predictAttrition = async (employee: EmployeeData) => {
    if (!predictionService) {
      throw new Error('Prediction service not initialized');
    }
    return predictionService.predictAttritionRisk(employee);
  };

  const predictPerformance = async (employee: EmployeeData) => {
    if (!predictionService) {
      throw new Error('Prediction service not initialized');
    }
    return predictionService.predictPerformance(employee);
  };

  return {
    loading,
    error,
    predictAttrition,
    predictPerformance
  };
}