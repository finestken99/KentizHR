export const JWT_SECRET = 'your-secret-key';
export const SQLITE_WASM_URL = 'https://sql.js.org/dist/sql-wasm.wasm';