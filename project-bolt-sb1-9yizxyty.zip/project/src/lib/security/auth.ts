import { securityConfig } from './config';
import { db } from '../db/models/database';
import { createToken, verifyToken } from '../auth/jwt';
import type { User } from '../db/models/types';

interface LoginAttempt {
  email: string;
  attempts: number;
  lastAttempt: number;
  lockedUntil?: number;
}

const loginAttempts = new Map<string, LoginAttempt>();

export const securityService = {
  async validateLogin(email: string, password: string): Promise<User | null> {
    // Check login attempts
    const attempt = loginAttempts.get(email) || { email, attempts: 0, lastAttempt: Date.now() };
    
    // Check if account is locked
    if (attempt.lockedUntil && Date.now() < attempt.lockedUntil) {
      const remainingTime = Math.ceil((attempt.lockedUntil - Date.now()) / 1000 / 60);
      throw new Error(`Account is locked. Try again in ${remainingTime} minutes`);
    }

    // Validate credentials
    const user = await db.users.where('email').equals(email).first();
    if (!user || user.password !== password) {
      // Update failed attempts
      attempt.attempts += 1;
      attempt.lastAttempt = Date.now();

      if (attempt.attempts >= securityConfig.password.maxAttempts) {
        attempt.lockedUntil = Date.now() + securityConfig.password.lockoutDuration;
      }

      loginAttempts.set(email, attempt);
      return null;
    }

    // Reset attempts on successful login
    loginAttempts.delete(email);
    return user;
  },

  async createSession(user: User) {
    // Check concurrent sessions
    const activeSessions = await db.sessions
      .where('user_id')
      .equals(user.id!)
      .count();

    if (activeSessions >= securityConfig.session.maxConcurrentSessions) {
      throw new Error('Maximum number of concurrent sessions reached');
    }

    // Create new session
    const token = createToken(
      { userId: user.id, role: user.role },
      process.env.JWT_SECRET!,
      securityConfig.session.duration
    );

    await db.sessions.add({
      user_id: user.id!,
      token,
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000)
    });

    return token;
  },

  async validateSession(token: string) {
    const session = await db.sessions
      .where('token')
      .equals(token)
      .first();

    if (!session) {
      throw new Error('Invalid session');
    }

    if (new Date(session.expires_at) < new Date()) {
      await db.sessions.delete(session.id!);
      throw new Error('Session expired');
    }

    return session;
  },

  async refreshSession(token: string) {
    const session = await this.validateSession(token);
    const decoded = verifyToken(token, process.env.JWT_SECRET!);

    // Create new token
    const newToken = createToken(
      { userId: decoded.userId, role: decoded.role },
      process.env.JWT_SECRET!,
      securityConfig.session.duration
    );

    // Update session
    await db.sessions.update(session.id!, {
      token: newToken,
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000)
    });

    return newToken;
  }
};