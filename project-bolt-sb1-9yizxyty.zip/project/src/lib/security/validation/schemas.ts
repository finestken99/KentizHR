import { z } from 'zod';

const passwordRules = {
  min: 12,
  max: 128,
  regex: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{12,}$/
};

export const passwordSchema = z.string()
  .min(passwordRules.min, `Password must be at least ${passwordRules.min} characters`)
  .max(passwordRules.max, `Password cannot exceed ${passwordRules.max} characters`)
  .regex(
    passwordRules.regex,
    'Password must contain uppercase, lowercase, number and special character'
  );

export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: passwordSchema,
  mfaToken: z.string().optional()
});

export const registerSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: passwordSchema,
  confirmPassword: z.string(),
  firstName: z.string().min(2, 'First name must be at least 2 characters'),
  lastName: z.string().min(2, 'Last name must be at least 2 characters'),
  company: z.string().min(2, 'Company name must be at least 2 characters')
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword']
});