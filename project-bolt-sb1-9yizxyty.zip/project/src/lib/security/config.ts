import { z } from 'zod';

export const securityConfig = {
  password: {
    minLength: 12,
    requireUppercase: true,
    requireLowercase: true,
    requireNumbers: true,
    requireSpecialChars: true,
    maxAttempts: 5,
    lockoutDuration: 15 * 60 * 1000 // 15 minutes
  },
  session: {
    duration: '24h',
    refreshToken: true,
    refreshThreshold: '1h',
    maxConcurrentSessions: 3
  },
  rateLimit: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    maxRequests: 100,
    message: 'Too many requests, please try again later'
  },
  mfa: {
    enabled: true,
    issuer: 'KENTIZ HR',
    digits: 6,
    window: 1
  }
};

// Password validation schema
export const passwordSchema = z.string()
  .min(securityConfig.password.minLength, `Password must be at least ${securityConfig.password.minLength} characters`)
  .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
  .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
  .regex(/[0-9]/, 'Password must contain at least one number')
  .regex(/[^A-Za-z0-9]/, 'Password must contain at least one special character');