import { db } from '../db/models/database';
import type { SubscriptionPlan, Feature, CompanySubscription } from '../db/models/types/subscription';

export const subscriptionService = {
  async getAvailablePlans(): Promise<SubscriptionPlan[]> {
    return db.subscriptionPlans.where('status').equals('active').toArray();
  },

  async getAllFeatures(): Promise<Feature[]> {
    return db.features.where('status').equals('active').toArray();
  },

  async getCurrentPlan(userId: number): Promise<{
    plan: SubscriptionPlan;
    subscription: CompanySubscription;
  } | null> {
    const subscription = await db.companySubscriptions
      .where('company_id')
      .equals(userId)
      .and(sub => sub.status === 'active')
      .first();

    if (!subscription) return null;

    const plan = await db.subscriptionPlans.get(subscription.plan_id);
    if (!plan) return null;

    return { plan, subscription };
  },

  async upgradePlan(userId: number, planId: number): Promise<boolean> {
    try {
      await db.transaction('rw', [db.subscriptionPlans, db.companySubscriptions], async () => {
        const plan = await db.subscriptionPlans.get(planId);
        if (!plan) throw new Error('Plan not found');

        const currentDate = new Date().toISOString();
        const endDate = new Date();
        endDate.setFullYear(endDate.getFullYear() + 1);

        // Cancel existing subscriptions
        await db.companySubscriptions
          .where('company_id')
          .equals(userId)
          .modify({ status: 'canceled', updated_at: currentDate });

        // Create new subscription
        await db.companySubscriptions.add({
          company_id: userId,
          plan_id: planId,
          status: 'active',
          start_date: currentDate,
          end_date: endDate.toISOString(),
          created_at: currentDate,
          updated_at: currentDate
        });
      });

      return true;
    } catch (error) {
      console.error('Error upgrading plan:', error);
      return false;
    }
  },

  async checkFeatureAccess(userId: number, featureName: string): Promise<boolean> {
    const subscription = await db.companySubscriptions
      .where('company_id')
      .equals(userId)
      .and(sub => sub.status === 'active')
      .first();

    if (!subscription) return false;

    const feature = await db.features
      .where('name')
      .equals(featureName)
      .and(f => f.status === 'active')
      .first();

    if (!feature) return false;

    const planFeature = await db.planFeatures
      .where(['plan_id', 'feature_id'])
      .equals([subscription.plan_id, feature.id!])
      .first();

    return !!planFeature;
  }
};