import { db } from '../db/config/database';
import { createToken } from '../utils/jwt';
import type { RegisterData, LoginData, AuthResponse } from '../types/auth';

export const authService = {
  async register(data: RegisterData): Promise<AuthResponse> {
    try {
      const database = await db.connect();

      // Use the appropriate database based on environment
      if (typeof window !== 'undefined') {
        // Browser - use IndexedDB
        const result = await database.register(data);
        if (!result) {
          throw new Error('Registration failed');
        }

        const token = createToken({ userId: result.id });
        return {
          user: {
            id: result.id!.toString(),
            email: result.email,
            firstName: result.first_name,
            lastName: result.last_name,
            role: result.role
          },
          token
        };
      } else {
        // Server - use MongoDB
        const User = (await import('../db/models/User')).User;
        const user = await User.create({
          email: data.email,
          password: data.password,
          firstName: data.firstName,
          lastName: data.lastName,
          company: data.company,
          role: 'employee'
        });

        const token = createToken({ userId: user._id.toString() });
        return {
          user: {
            id: user._id.toString(),
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            role: user.role
          },
          token
        };
      }
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    }
  },

  async login(data: LoginData): Promise<AuthResponse> {
    try {
      const database = await db.connect();

      if (typeof window !== 'undefined') {
        // Browser - use IndexedDB
        const result = await database.login(data.email, data.password);
        if (!result) {
          throw new Error('Invalid credentials');
        }
        return result;
      } else {
        // Server - use MongoDB
        const User = (await import('../db/models/User')).User;
        const user = await User.findOne({ email: data.email });
        if (!user) {
          throw new Error('Invalid credentials');
        }

        const isValidPassword = await user.comparePassword(data.password);
        if (!isValidPassword) {
          throw new Error('Invalid credentials');
        }

        const token = createToken({ userId: user._id.toString() });
        return {
          user: {
            id: user._id.toString(),
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            role: user.role
          },
          token
        };
      }
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  }
};