import { employeeRepository } from '../db/repositories/employeeRepository';
import { userRepository } from '../db/repositories/userRepository';
import { generatePassword } from '../utils/auth';
import { sendWelcomeEmail } from '../utils/email';
import { UserRole } from '../auth/types';
import type { CreateEmployeeData } from './types';

export const employeeService = {
  async createEmployee(tenantId: number, data: CreateEmployeeData) {
    try {
      // Check if email already exists
      const existingUser = await userRepository.findByEmail(data.email);
      if (existingUser) {
        throw new Error('Email already exists');
      }

      // Generate secure random password
      const password = generatePassword();

      // Create user account
      const user = await userRepository.create({
        email: data.email,
        password,
        first_name: data.firstName,
        last_name: data.lastName,
        role: UserRole.EMPLOYEE,
        status: 'active'
      });

      // Create employee record
      const employee = await employeeRepository.create({
        email: data.email,
        tenant_id: tenantId,
        position: data.position,
        department: data.department,
        status: 'active'
      });

      // Send welcome email with credentials
      await sendWelcomeEmail({
        to: data.email,
        firstName: data.firstName,
        password,
        loginUrl: `${window.location.origin}/#login`
      });

      return {
        user,
        employee
      };
    } catch (error) {
      console.error('Error creating employee:', error);
      throw error;
    }
  }
};