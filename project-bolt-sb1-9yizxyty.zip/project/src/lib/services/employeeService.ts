import { employeeRepository } from '../db/repositories/employeeRepository';
import { userRepository } from '../db/repositories/userRepository';

export const employeeService = {
  async deleteEmployee(employeeId: number) {
    try {
      // Get employee details first
      const employee = await employeeRepository.findById(employeeId);
      if (!employee) {
        throw new Error('Employee not found');
      }

      // Delete employee record
      await employeeRepository.delete(employeeId);

      // Delete associated user account
      const user = await userRepository.findByEmail(employee.email);
      if (user) {
        await userRepository.delete(user.id!);
      }

      return true;
    } catch (error) {
      console.error('Error deleting employee:', error);
      throw error;
    }
  }
};