import { tenantRepository } from '../db/repositories/tenantRepository';
import { userRepository } from '../db/repositories/userRepository';
import { generatePassword } from '../utils/auth';
import { sendWelcomeEmail } from '../utils/email';
import { UserRole } from '../auth/types';
import type { Tenant } from '../db/models/types';

export const landlordService = {
  async createTenant(landlordId: number, data: {
    companyName: string;
    email: string;
    firstName: string;
    lastName: string;
  }) {
    try {
      // Check if email already exists
      const existingUser = await userRepository.findByEmail(data.email);
      if (existingUser) {
        throw new Error('Email already exists');
      }

      // Generate admin password
      const password = generatePassword();

      // Create tenant admin user
      const user = await userRepository.create({
        email: data.email,
        password,
        first_name: data.firstName,
        last_name: data.lastName,
        role: UserRole.TENANT,
        company_name: data.companyName,
        status: 'active'
      });

      // Create tenant record
      const tenant = await tenantRepository.create({
        company_name: data.companyName,
        email: data.email,
        subscription_status: 'pending',
        landlord_id: landlordId
      });

      // Send welcome email
      await sendWelcomeEmail({
        to: data.email,
        firstName: data.firstName,
        password,
        loginUrl: `${window.location.origin}/#login`
      });

      return { user, tenant };
    } catch (error) {
      console.error('Error creating tenant:', error);
      throw error;
    }
  },

  async getTenants(landlordId: number) {
    return tenantRepository.findByLandlord(landlordId);
  },

  async updateTenantStatus(tenantId: number, status: Tenant['subscription_status']) {
    return tenantRepository.updateSubscriptionStatus(tenantId, status);
  },

  async getTenantAnalytics(landlordId: number) {
    const tenants = await this.getTenants(landlordId);
    
    return {
      total: tenants.length,
      active: tenants.filter(t => t.subscription_status === 'active').length,
      pending: tenants.filter(t => t.subscription_status === 'pending').length,
      inactive: tenants.filter(t => t.subscription_status === 'inactive').length
    };
  }
};