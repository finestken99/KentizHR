import { tenantRepository } from '../db/repositories/tenantRepository';
import { userRepository } from '../db/repositories/userRepository';
import type { Tenant } from '../db/models/types';
import { UserRole } from '../auth/types';

export const tenantService = {
  async create(data: Omit<Tenant, 'id' | 'created_at' | 'updated_at'>) {
    // Create tenant user account
    const user = await userRepository.create({
      email: data.email,
      role: UserRole.TENANT,
      password: Math.random().toString(36).slice(-8), // Generate random password
      first_name: '',
      last_name: '',
      company_name: data.company_name,
      status: 'active'
    });

    // Create tenant record
    return tenantRepository.create({
      ...data,
      subscription_status: 'pending'
    });
  },

  async updateSubscription(tenantId: number, status: Tenant['subscription_status']) {
    await tenantRepository.updateSubscriptionStatus(tenantId, status);
  },

  async getTenantsByLandlord(landlordId: number) {
    return tenantRepository.findByLandlord(landlordId);
  }
};