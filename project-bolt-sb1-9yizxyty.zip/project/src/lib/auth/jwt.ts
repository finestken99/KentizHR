// Custom JWT implementation for browser environment
export function createToken(payload: any, secret: string, expiresIn: string = '24h'): string {
  const header = {
    alg: 'HS256',
    typ: 'JWT'
  };

  const now = Math.floor(Date.now() / 1000);
  const exp = now + (parseInt(expiresIn) * 3600);
  
  const encodedHeader = btoa(JSON.stringify(header));
  const encodedPayload = btoa(JSON.stringify({ ...payload, exp }));
  
  const signature = btoa(
    JSON.stringify({ data: `${encodedHeader}.${encodedPayload}`, secret })
  );

  return `${encodedHeader}.${encodedPayload}.${signature}`;
}

export function verifyToken(token: string, secret: string): any {
  try {
    const [headerB64, payloadB64] = token.split('.');
    const payload = JSON.parse(atob(payloadB64));
    
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      throw new Error('Token expired');
    }
    
    return payload;
  } catch (error) {
    throw new Error('Invalid token');
  }
}