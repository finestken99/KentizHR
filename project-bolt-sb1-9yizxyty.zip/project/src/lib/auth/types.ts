export enum UserRole {
  ADMIN = 'admin',
  LANDLORD = 'landlord',
  TENANT = 'tenant',
  EMPLOYEE = 'employee'
}

export interface AuthUser {
  id: number;
  email: string;
  role: UserRole;
  exp?: number;
}

export interface AuthError {
  message: string;
  code: 'TOKEN_MISSING' | 'TOKEN_INVALID' | 'TOKEN_EXPIRED' | 'UNAUTHORIZED';
}