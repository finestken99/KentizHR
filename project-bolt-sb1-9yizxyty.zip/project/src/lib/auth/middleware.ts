import { AuthUser, AuthError, UserRole } from './types';

export function verifyAuth(token: string | null): AuthUser | AuthError {
  if (!token) {
    return { message: 'No token provided', code: 'TOKEN_MISSING' };
  }

  try {
    const decoded = JSON.parse(atob(token));
    
    // Check token expiration
    if (decoded.exp && decoded.exp < Math.floor(Date.now() / 1000)) {
      return { message: 'Token expired', code: 'TOKEN_EXPIRED' };
    }

    return decoded.user;
  } catch (error) {
    return { message: 'Invalid token', code: 'TOKEN_INVALID' };
  }
}

export function checkRole(user: AuthUser | null, allowedRoles: UserRole[]): boolean {
  if (!user) return false;
  return allowedRoles.includes(user.role);
}

export function requireAuth(allowedRoles: UserRole[] = []) {
  return () => {
    const token = localStorage.getItem('auth_token');
    const result = verifyAuth(token);
    
    if ('code' in result) {
      throw new Error(result.message);
    }

    if (allowedRoles.length && !checkRole(result, allowedRoles)) {
      throw new Error('Unauthorized access');
    }

    return result;
  };
}