import React from 'react';
import { Container } from '../ui/Container';
import { Button } from '../ui/Button';
import { Navigation } from './Navigation';
import { Logo } from './Logo';

export function Header() {
  return (
    <header className="fixed w-full bg-white shadow-sm z-50">
      <Container>
        <div className="flex justify-between items-center h-16">
          <Logo />
          <Navigation />
          <div className="flex items-center space-x-4">
            <a 
              href="#login"
              className="text-gray-600 hover:text-gray-900 transition-colors"
            >
              Sign in
            </a>
            <Button 
              variant="primary" 
              onClick={() => window.location.href = '#register'}
            >
              Start Free Trial
            </Button>
          </div>
        </div>
      </Container>
    </header>
  );
}