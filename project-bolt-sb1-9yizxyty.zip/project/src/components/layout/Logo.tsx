import React from 'react';
import { BarChart2, Activity } from 'lucide-react';
import { useUser } from '../../contexts/UserContext';

export function Logo() {
  const { user } = useUser();

  const getHomeLink = () => {
    if (user?.role === 'admin') {
      return '#admin-dashboard';
    }
    if (user?.role === 'employee') {
      return '#dashboard';
    }
    return '#';
  };

  const getLogoText = () => {
    if (user?.role === 'admin') {
      return 'Admin Portal';
    }
    if (user?.role === 'employee') {
      return 'HR Portal';
    }
    return 'HR Solutions';
  };

  return (
    <a 
      href={getHomeLink()} 
      className="flex items-center space-x-2 hover:opacity-90 transition-opacity"
      aria-label="Go to homepage"
    >
      <div className="relative">
        <Activity className="h-8 w-8 text-blue-600 absolute transform -rotate-12" />
        <BarChart2 className="h-8 w-8 text-blue-500 opacity-80" />
      </div>
      <div className="flex flex-col">
        <span className="text-2xl font-extrabold tracking-tight text-gray-900">
          KEN<span className="text-blue-600">TIZ</span>
        </span>
        <span className="text-xs uppercase tracking-wider text-gray-500 -mt-1">
          {getLogoText()}
        </span>
      </div>
    </a>
  );
}