import React from 'react';
import { Facebook, Twitter, Linkedin, Github, Youtube } from 'lucide-react';

const socialLinks = [
  { icon: Facebook, href: '#facebook', label: 'Facebook' },
  { icon: Twitter, href: '#twitter', label: 'Twitter' },
  { icon: Linkedin, href: '#linkedin', label: 'LinkedIn' },
  { icon: Github, href: '#github', label: 'GitHub' },
  { icon: Youtube, href: '#youtube', label: 'YouTube' }
];

export function SocialLinks() {
  return (
    <div>
      <h3 className="text-lg font-semibold text-white mb-4">Connect With Us</h3>
      <div className="flex space-x-4">
        {socialLinks.map(({ icon: Icon, href, label }) => (
          <a
            key={label}
            href={href}
            className="text-gray-400 hover:text-white transition-colors"
            aria-label={label}
          >
            <Icon className="h-6 w-6" />
          </a>
        ))}
      </div>
    </div>
  );
}