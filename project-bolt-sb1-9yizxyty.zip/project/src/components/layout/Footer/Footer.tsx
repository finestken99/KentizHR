import React from 'react';
import { Container } from '../../ui/Container';
import { FooterColumn } from './FooterColumn';
import { SocialLinks } from './SocialLinks';
import { ContactInfo } from './ContactInfo';

const footerSections = [
  {
    title: 'Product',
    links: [
      { label: 'Features', href: '#features' },
      { label: 'Solutions', href: '#solutions' },
      { label: 'Integrations', href: '#integrations' },
      { label: 'Documentation', href: '#docs' },
      { label: 'API Reference', href: '#api' }
    ]
  },
  {
    title: 'Resources',
    links: [
      { label: 'Blog', href: '#blog' },
      { label: 'Knowledge Base', href: '#knowledge-base' },
      { label: 'Community', href: '#community' },
      { label: 'Case Studies', href: '#case-studies' },
      { label: 'Webinars', href: '#webinars' }
    ]
  },
  {
    title: 'Company',
    links: [
      { label: 'About Us', href: '#about' },
      { label: 'Careers', href: '#careers' },
      { label: 'Press', href: '#press' },
      { label: 'Partners', href: '#partners' },
      { label: 'Contact', href: '#contact' }
    ]
  },
  {
    title: 'Legal',
    links: [
      { label: 'Privacy Policy', href: '#privacy' },
      { label: 'Terms of Service', href: '#terms' },
      { label: 'Security', href: '#security' },
      { label: 'Compliance', href: '#compliance' },
      { label: 'GDPR', href: '#gdpr' }
    ]
  }
];

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <Container>
        <div className="py-12">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 mb-8">
            {footerSections.map((section) => (
              <div key={section.title} className="col-span-1 md:col-span-1 lg:col-span-1">
                <FooterColumn {...section} />
              </div>
            ))}
            <div className="col-span-2 md:col-span-3 lg:col-span-2">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <ContactInfo />
                <SocialLinks />
              </div>
            </div>
          </div>
          
          <div className="pt-8 mt-8 border-t border-gray-800">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-gray-400 text-sm">
                © {new Date().getFullYear()} KENTIZ. All rights reserved.
              </p>
              <div className="flex space-x-4 mt-4 md:mt-0">
                <a href="#accessibility" className="text-gray-400 hover:text-white text-sm">
                  Accessibility
                </a>
                <a href="#sitemap" className="text-gray-400 hover:text-white text-sm">
                  Sitemap
                </a>
                <a href="#cookies" className="text-gray-400 hover:text-white text-sm">
                  Cookie Preferences
                </a>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </footer>
  );
}