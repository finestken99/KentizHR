import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

const contactInfo = [
  {
    icon: Mail,
    text: 'support@kentiz.com',
    href: 'mailto:support@kentiz.com'
  },
  {
    icon: Phone,
    text: '+1 (555) 123-4567',
    href: 'tel:+15551234567'
  },
  {
    icon: MapPin,
    text: 'San Francisco, CA',
    href: '#location'
  }
];

export function ContactInfo() {
  return (
    <div>
      <h3 className="text-lg font-semibold text-white mb-4">Contact Us</h3>
      <div className="space-y-3">
        {contactInfo.map(({ icon: Icon, text, href }) => (
          <a
            key={text}
            href={href}
            className="flex items-center text-gray-400 hover:text-white transition-colors"
          >
            <Icon className="h-5 w-5 mr-2" />
            <span>{text}</span>
          </a>
        ))}
      </div>
    </div>
  );
}