import React from 'react';
import { Check } from 'lucide-react';

interface Step {
  id: string;
  title: string;
}

interface SignupStepsProps {
  steps: Step[];
  currentStep: number;
}

export function SignupSteps({ steps, currentStep }: SignupStepsProps) {
  return (
    <div className="relative">
      <div className="absolute inset-0 flex items-center" aria-hidden="true">
        <div className="w-full border-t border-gray-200" />
      </div>
      <div className="relative flex justify-between">
        {steps.map((step, index) => (
          <div
            key={step.id}
            className={`flex items-center ${
              index <= currentStep ? 'text-blue-600' : 'text-gray-500'
            }`}
          >
            <div className={`
              relative w-8 h-8 flex items-center justify-center rounded-full
              ${index < currentStep
                ? 'bg-blue-600'
                : index === currentStep
                ? 'bg-blue-600 ring-2 ring-blue-600 ring-offset-2'
                : 'bg-gray-200'
              }
            `}>
              {index < currentStep ? (
                <Check className="w-5 h-5 text-white" />
              ) : (
                <span className={`text-sm font-medium ${
                  index === currentStep ? 'text-white' : 'text-gray-500'
                }`}>
                  {index + 1}
                </span>
              )}
            </div>
            <span className="ml-3 text-sm font-medium">{step.title}</span>
          </div>
        ))}
      </div>
    </div>
  );
}