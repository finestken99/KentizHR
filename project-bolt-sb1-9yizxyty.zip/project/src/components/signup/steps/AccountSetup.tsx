import React, { useState } from 'react';
import { Mail, Lock, Building2, Users, Briefcase } from 'lucide-react';
import { FormField } from '../../ui/FormField';
import { Button } from '../../ui/Button';
import { useFormSubmit } from '../../../hooks/useFormSubmit';
import { accountSetupSchema, type AccountSetupData } from '../../../lib/validation/forms';

interface AccountSetupProps {
  data: Partial<AccountSetupData>;
  onComplete: (data: AccountSetupData) => Promise<void>;
}

export function AccountSetup({ data, onComplete }: AccountSetupProps) {
  const [formData, setFormData] = useState<AccountSetupData>({
    companyName: data.companyName || '',
    adminEmail: data.adminEmail || '',
    password: data.password || '',
    firstName: data.firstName || '',
    lastName: data.lastName || '',
    industry: data.industry || '',
    size: data.size || ''
  });

  const { loading, error, handleSubmit } = useFormSubmit({
    schema: accountSetupSchema,
    onSubmit: onComplete
  });

  const handleChange = (field: keyof AccountSetupData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await handleSubmit(formData);
  };

  return (
    <form onSubmit={onSubmit} className="space-y-6">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
          {error}
        </div>
      )}

      <FormField
        label="Company Name"
        name="companyName"
        value={formData.companyName}
        onChange={(e) => handleChange('companyName', e.target.value)}
        icon={Building2}
        required
        disabled={loading}
      />

      <div className="grid grid-cols-2 gap-4">
        <FormField
          label="First Name"
          name="firstName"
          value={formData.firstName}
          onChange={(e) => handleChange('firstName', e.target.value)}
          icon={Users}
          required
          disabled={loading}
        />

        <FormField
          label="Last Name"
          name="lastName"
          value={formData.lastName}
          onChange={(e) => handleChange('lastName', e.target.value)}
          icon={Users}
          required
          disabled={loading}
        />
      </div>

      <FormField
        label="Admin Email"
        name="adminEmail"
        type="email"
        value={formData.adminEmail}
        onChange={(e) => handleChange('adminEmail', e.target.value)}
        icon={Mail}
        required
        disabled={loading}
      />

      <FormField
        label="Password"
        name="password"
        type="password"
        value={formData.password}
        onChange={(e) => handleChange('password', e.target.value)}
        icon={Lock}
        required
        disabled={loading}
      />

      <FormField
        label="Industry"
        name="industry"
        type="select"
        value={formData.industry}
        onChange={(e) => handleChange('industry', e.target.value)}
        icon={Briefcase}
        required
        disabled={loading}
        options={[
          { value: '', label: 'Select industry' },
          { value: 'technology', label: 'Technology' },
          { value: 'healthcare', label: 'Healthcare' },
          { value: 'finance', label: 'Finance' },
          { value: 'retail', label: 'Retail' },
          { value: 'manufacturing', label: 'Manufacturing' }
        ]}
      />

      <FormField
        label="Company Size"
        name="size"
        type="select"
        value={formData.size}
        onChange={(e) => handleChange('size', e.target.value)}
        icon={Users}
        required
        disabled={loading}
        options={[
          { value: '', label: 'Select company size' },
          { value: '1-10', label: '1-10 employees' },
          { value: '11-50', label: '11-50 employees' },
          { value: '51-200', label: '51-200 employees' },
          { value: '201-500', label: '201-500 employees' },
          { value: '501+', label: '501+ employees' }
        ]}
      />

      <Button
        variant="primary"
        type="submit"
        className="w-full"
        disabled={loading}
      >
        {loading ? 'Creating Account...' : 'Continue'}
      </Button>
    </form>
  );
}