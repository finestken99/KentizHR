import React, { useState } from 'react';
import { CreditCard, Calendar, Lock } from 'lucide-react';
import { FormField } from '../../ui/FormField';
import { Button } from '../../ui/Button';
import { useFormValidation } from '../../../hooks/useFormValidation';
import { paymentSchema } from '../../../lib/validation/signup';

interface PaymentSetupProps {
  data: any;
  onComplete: (data: any) => void;
  onBack: () => void;
}

export function PaymentSetup({ data, onComplete, onBack }: PaymentSetupProps) {
  const [formData, setFormData] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    plan: data.plan || ''
  });

  const { validationState, validateForm } = useFormValidation(paymentSchema);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm(formData)) {
      onComplete(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-blue-50 rounded-lg p-4 mb-6">
        <h3 className="text-lg font-medium text-gray-900">
          Selected Plan: {data.plan}
        </h3>
        <p className="text-sm text-gray-600 mt-1">
          You can change your plan at any time
        </p>
      </div>

      <FormField
        label="Card Number"
        name="cardNumber"
        value={formData.cardNumber}
        onChange={(e) => setFormData(prev => ({ ...prev, cardNumber: e.target.value }))}
        error={validationState.cardNumber?.error}
        icon={CreditCard}
        required
      />

      <div className="grid grid-cols-2 gap-4">
        <FormField
          label="Expiry Date"
          name="expiryDate"
          placeholder="MM/YY"
          value={formData.expiryDate}
          onChange={(e) => setFormData(prev => ({ ...prev, expiryDate: e.target.value }))}
          error={validationState.expiryDate?.error}
          icon={Calendar}
          required
        />

        <FormField
          label="CVV"
          name="cvv"
          value={formData.cvv}
          onChange={(e) => setFormData(prev => ({ ...prev, cvv: e.target.value }))}
          error={validationState.cvv?.error}
          icon={Lock}
          required
        />
      </div>

      <div className="flex justify-between pt-6">
        <Button variant="secondary" onClick={onBack}>
          Back
        </Button>
        <Button variant="primary" type="submit">
          Complete Payment
        </Button>
      </div>
    </form>
  );
}