import React, { useState } from 'react';
import { Building2, Clock, Calendar } from 'lucide-react';
import { FormField } from '../../ui/FormField';
import { Button } from '../../ui/Button';
import { useFormValidation } from '../../../hooks/useFormValidation';
import { systemConfigSchema } from '../../../lib/validation/forms';

interface SystemConfigurationProps {
  data: any;
  onComplete: (data: any) => Promise<void>;
  onBack: () => void;
}

export function SystemConfiguration({ data, onComplete, onBack }: SystemConfigurationProps) {
  const [formData, setFormData] = useState({
    departments: data.departments || [],
    workingHoursStart: data.workingHours?.start || '',
    workingHoursEnd: data.workingHours?.end || '',
    leaveDays: data.leaveDays || 20
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { validationState, validateForm } = useFormValidation(systemConfigSchema);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    try {
      setLoading(true);

      const validData = {
        departments: formData.departments,
        workingHours: {
          start: formData.workingHoursStart,
          end: formData.workingHoursEnd
        },
        leaveDays: Number(formData.leaveDays)
      };

      if (!validateForm(validData)) {
        return;
      }

      await onComplete(validData);
    } catch (err: any) {
      setError(err.message || 'Failed to save configuration');
      console.error('Configuration error:', err);
    } finally {
      setLoading(false);
    }
  };

  const defaultDepartments = [
    'HR', 'Engineering', 'Sales', 'Marketing', 'Finance', 'Operations'
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
          {error}
        </div>
      )}

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Departments
        </label>
        <div className="grid grid-cols-2 gap-4">
          {defaultDepartments.map((dept) => (
            <label key={dept} className="flex items-center">
              <input
                type="checkbox"
                checked={formData.departments.includes(dept)}
                onChange={(e) => {
                  const newDepts = e.target.checked
                    ? [...formData.departments, dept]
                    : formData.departments.filter(d => d !== dept);
                  setFormData(prev => ({ ...prev, departments: newDepts }));
                }}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <span className="ml-2 text-sm text-gray-600">{dept}</span>
            </label>
          ))}
        </div>
        {validationState.departments?.error && (
          <p className="mt-1 text-sm text-red-600">{validationState.departments.error}</p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <FormField
          label="Working Hours Start"
          name="workingHoursStart"
          type="time"
          value={formData.workingHoursStart}
          onChange={(e) => setFormData(prev => ({ ...prev, workingHoursStart: e.target.value }))}
          error={validationState.workingHours?.error}
          icon={Clock}
          required
          disabled={loading}
        />

        <FormField
          label="Working Hours End"
          name="workingHoursEnd"
          type="time"
          value={formData.workingHoursEnd}
          onChange={(e) => setFormData(prev => ({ ...prev, workingHoursEnd: e.target.value }))}
          error={validationState.workingHours?.error}
          icon={Clock}
          required
          disabled={loading}
        />
      </div>

      <FormField
        label="Annual Leave Days"
        name="leaveDays"
        type="number"
        value={formData.leaveDays.toString()}
        onChange={(e) => setFormData(prev => ({ ...prev, leaveDays: parseInt(e.target.value) }))}
        error={validationState.leaveDays?.error}
        icon={Calendar}
        required
        disabled={loading}
        min="0"
        max="365"
      />

      <div className="flex justify-between pt-6">
        <Button 
          variant="secondary" 
          onClick={onBack}
          disabled={loading}
        >
          Back
        </Button>
        <Button 
          variant="primary" 
          type="submit"
          disabled={loading}
        >
          {loading ? 'Saving...' : 'Complete Setup'}
        </Button>
      </div>
    </form>
  );
}