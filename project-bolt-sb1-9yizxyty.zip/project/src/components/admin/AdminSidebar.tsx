import React from 'react';
import { 
  Home,
  Users,
  Calendar,
  Award,
  BarChart2,
  Settings,
  FileText,
  MessageSquare
} from 'lucide-react';
import { useHash } from '../../hooks/useHash';

const menuItems = [
  { icon: Home, label: 'Overview', href: '#admin-dashboard' },
  { icon: Users, label: 'Employees', href: '#admin-dashboard/employees' },
  { icon: Calendar, label: 'Leave Management', href: '#admin-dashboard/leave' },
  { icon: Award, label: 'Performance', href: '#admin-dashboard/performance' },
  { icon: FileText, label: 'Documents', href: '#admin-dashboard/documents' },
  { icon: BarChart2, label: 'Analytics', href: '#admin-dashboard/analytics' },
  { icon: MessageSquare, label: 'Queries', href: '#admin-dashboard/queries' },
  { icon: Settings, label: 'Settings', href: '#admin-dashboard/settings' }
];

export function AdminSidebar() {
  const currentHash = useHash();

  return (
    <aside className="w-64 bg-gray-800 min-h-screen">
      <nav className="mt-5 px-2">
        <div className="space-y-1">
          {menuItems.map(({ icon: Icon, label, href }) => {
            const isActive = currentHash === href;
            return (
              <a
                key={label}
                href={href}
                className={`
                  group flex items-center px-2 py-2 text-base font-medium rounded-md
                  ${isActive
                    ? 'bg-gray-900 text-white'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                  }
                `}
              >
                <Icon className="mr-4 h-6 w-6" />
                {label}
              </a>
            );
          })}
        </div>
      </nav>
    </aside>
  );
}