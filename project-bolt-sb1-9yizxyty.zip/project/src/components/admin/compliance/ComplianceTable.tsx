import React from 'react';
import { CheckCircle, AlertTriangle, Clock, AlertCircle } from 'lucide-react';

const complianceItems = [
  {
    id: 1,
    requirement: 'Data Protection Policy',
    category: 'Privacy',
    status: 'compliant',
    dueDate: '2024-12-31',
    assignee: 'John Smith',
    risk: 'high'
  },
  {
    id: 2,
    requirement: 'Employee Safety Training',
    category: 'Health & Safety',
    status: 'pending',
    dueDate: '2024-04-15',
    assignee: 'Sarah Johnson',
    risk: 'medium'
  },
  {
    id: 3,
    requirement: 'Financial Reporting',
    category: 'Finance',
    status: 'non_compliant',
    dueDate: '2024-03-31',
    assignee: 'Mike Brown',
    risk: 'high'
  }
];

const statusConfig = {
  compliant: { icon: CheckCircle, className: 'text-green-600', label: 'Compliant' },
  pending: { icon: Clock, className: 'text-yellow-600', label: 'Pending Review' },
  non_compliant: { icon: AlertTriangle, className: 'text-red-600', label: 'Non-Compliant' }
};

const riskConfig = {
  high: 'bg-red-100 text-red-800',
  medium: 'bg-yellow-100 text-yellow-800',
  low: 'bg-green-100 text-green-800'
};

export function ComplianceTable() {
  return (
    <div className="mt-6 overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Requirement
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Category
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Status
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Due Date
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Assignee
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Risk Level
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {complianceItems.map((item) => {
            const StatusIcon = statusConfig[item.status].icon;
            return (
              <tr key={item.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900">
                    {item.requirement}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-500">{item.category}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <StatusIcon className={`h-5 w-5 ${statusConfig[item.status].className} mr-2`} />
                    <span className="text-sm text-gray-500">
                      {statusConfig[item.status].label}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {item.dueDate}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {item.assignee}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${riskConfig[item.risk]}`}>
                    {item.risk.charAt(0).toUpperCase() + item.risk.slice(1)}
                  </span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}