import React from 'react';
import { Shield, AlertTriangle, CheckCircle, Clock } from 'lucide-react';

const stats = [
  {
    label: 'Overall Compliance',
    value: '94%',
    icon: Shield,
    color: 'text-green-600',
    bgColor: 'bg-green-100'
  },
  {
    label: 'Critical Issues',
    value: '3',
    icon: AlertTriangle,
    color: 'text-red-600',
    bgColor: 'bg-red-100'
  },
  {
    label: 'Compliant Items',
    value: '156',
    icon: CheckCircle,
    color: 'text-blue-600',
    bgColor: 'bg-blue-100'
  },
  {
    label: 'Pending Reviews',
    value: '8',
    icon: Clock,
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-100'
  }
];

export function ComplianceOverview() {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map(({ label, value, icon: Icon, color, bgColor }) => (
        <div
          key={label}
          className="bg-white overflow-hidden shadow rounded-lg"
        >
          <div className="p-5">
            <div className="flex items-center">
              <div className={`flex-shrink-0 rounded-md p-3 ${bgColor}`}>
                <Icon className={`h-6 w-6 ${color}`} />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    {label}
                  </dt>
                  <dd className="text-2xl font-semibold text-gray-900">
                    {value}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}