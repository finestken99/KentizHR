import React, { useState } from 'react';
import { BarChart2, Plus, Settings, Save } from 'lucide-react';
import { Button } from '../../../ui/Button';

interface Widget {
  id: number;
  type: string;
  title: string;
  metric: string;
}

export function CustomDashboards() {
  const [widgets, setWidgets] = useState<Widget[]>([
    {
      id: 1,
      type: 'kpi',
      title: 'Employee Turnover',
      metric: 'turnover_rate'
    },
    {
      id: 2,
      type: 'chart',
      title: 'Hiring Trends',
      metric: 'monthly_hires'
    }
  ]);

  const handleAddWidget = () => {
    const newWidget: Widget = {
      id: Date.now(),
      type: 'kpi',
      title: 'New Widget',
      metric: ''
    };
    setWidgets([...widgets, newWidget]);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Custom Dashboards</h3>
          <p className="text-sm text-gray-500">Create personalized views</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="secondary" onClick={handleAddWidget}>
            <Plus className="h-4 w-4 mr-2" />
            Add Widget
          </Button>
          <Button variant="primary">
            <Save className="h-4 w-4 mr-2" />
            Save Layout
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {widgets.map(widget => (
          <div
            key={widget.id}
            className="border border-gray-200 rounded-lg p-4 hover:border-blue-200 transition-colors"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <BarChart2 className="h-5 w-5 text-gray-400" />
                <h4 className="text-sm font-medium text-gray-900">{widget.title}</h4>
              </div>
              <button className="p-1 hover:bg-gray-100 rounded">
                <Settings className="h-4 w-4 text-gray-400" />
              </button>
            </div>
            <div className="h-32 bg-gray-50 rounded flex items-center justify-center">
              <span className="text-sm text-gray-500">Widget Content</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}