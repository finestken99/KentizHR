import React, { useState } from 'react';
import { FileText, Calendar, Mail, Clock } from 'lucide-react';
import { Button } from '../../../ui/Button';

interface Report {
  id: number;
  name: string;
  schedule: string;
  recipients: string[];
  lastRun?: string;
  nextRun: string;
  format: string;
}

export function AutomatedReports() {
  const [reports, setReports] = useState<Report[]>([
    {
      id: 1,
      name: 'Monthly HR Metrics',
      schedule: 'Monthly',
      recipients: ['hr@company.com', 'management@company.com'],
      lastRun: '2024-03-01',
      nextRun: '2024-04-01',
      format: 'PDF'
    },
    {
      id: 2,
      name: 'Weekly Recruitment Update',
      schedule: 'Weekly',
      recipients: ['recruiting@company.com'],
      lastRun: '2024-03-15',
      nextRun: '2024-03-22',
      format: 'Excel'
    }
  ]);

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Automated Reports</h3>
          <p className="text-sm text-gray-500">Schedule and manage recurring reports</p>
        </div>
        <Button variant="primary">
          <FileText className="h-4 w-4 mr-2" />
          New Report
        </Button>
      </div>

      <div className="space-y-4">
        {reports.map(report => (
          <div
            key={report.id}
            className="border border-gray-200 rounded-lg p-4"
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <h4 className="text-sm font-medium text-gray-900">{report.name}</h4>
                <div className="flex items-center mt-1 space-x-4">
                  <div className="flex items-center text-sm text-gray-500">
                    <Calendar className="h-4 w-4 mr-1" />
                    {report.schedule}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <FileText className="h-4 w-4 mr-1" />
                    {report.format}
                  </div>
                </div>
              </div>
              <Button variant="secondary">Edit Schedule</Button>
            </div>

            <div className="flex items-center space-x-4 text-sm text-gray-500">
              <div className="flex items-center">
                <Mail className="h-4 w-4 mr-1" />
                {report.recipients.length} recipients
              </div>
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                Next run: {report.nextRun}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}