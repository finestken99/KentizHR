import React from 'react';
import { Shield, Lock, FileCheck, AlertTriangle } from 'lucide-react';

const complianceItems = [
  {
    title: 'Data Protection',
    status: 'compliant',
    lastCheck: '2024-03-15',
    details: 'GDPR and CCPA compliant'
  },
  {
    title: 'Access Controls',
    status: 'warning',
    lastCheck: '2024-03-14',
    details: 'Review pending for new roles'
  },
  {
    title: 'Data Encryption',
    status: 'compliant',
    lastCheck: '2024-03-13',
    details: 'All data encrypted at rest and in transit'
  }
];

export function SecurityCompliance() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Security & Compliance</h3>
          <p className="text-sm text-gray-500">System security status</p>
        </div>
        <Shield className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {complianceItems.map((item, index) => (
          <div
            key={index}
            className="p-4 bg-gray-50 rounded-lg"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-3">
                {item.status === 'compliant' ? (
                  <Lock className="h-5 w-5 text-green-500" />
                ) : (
                  <AlertTriangle className="h-5 w-5 text-yellow-500" />
                )}
                <h4 className="text-sm font-medium text-gray-900">{item.title}</h4>
              </div>
              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                item.status === 'compliant' 
                  ? 'bg-green-100 text-green-800'
                  : 'bg-yellow-100 text-yellow-800'
              }`}>
                {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
              </span>
            </div>
            <p className="text-sm text-gray-600 ml-8">{item.details}</p>
            <div className="flex items-center mt-2 ml-8">
              <FileCheck className="h-4 w-4 text-gray-400 mr-1" />
              <span className="text-xs text-gray-500">
                Last checked: {item.lastCheck}
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <Shield className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">Security Status</h4>
            <p className="text-sm text-gray-600 mt-1">
              All critical security measures are in place and actively monitored.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}