import React, { useState, useEffect } from 'react';
import { Brain, AlertTriangle, TrendingUp } from 'lucide-react';
import { usePredictions } from '../../../lib/ml/hooks/usePredictions';
import type { EmployeeData } from '../../../lib/ml/preprocessing/dataPreprocessing';

const mockEmployee: EmployeeData = {
  id: 1,
  age: 35,
  yearsOfService: 5,
  salary: 85000,
  performanceScore: 4.2,
  trainingHours: 45,
  projectsCompleted: 12,
  overtimeHours: 180,
  absenceDays: 5
};

export function PredictiveInsights() {
  const { loading, error, predictAttrition, predictPerformance } = usePredictions();
  const [predictions, setPredictions] = useState<{
    attrition: { risk: number; factors: string[] } | null;
    performance: { predictedScore: number; recommendations: string[] } | null;
  }>({
    attrition: null,
    performance: null
  });

  useEffect(() => {
    const loadPredictions = async () => {
      try {
        const [attrition, performance] = await Promise.all([
          predictAttrition(mockEmployee),
          predictPerformance(mockEmployee)
        ]);

        setPredictions({ attrition, performance });
      } catch (err) {
        console.error('Failed to load predictions:', err);
      }
    };

    if (!loading && !error) {
      loadPredictions();
    }
  }, [loading, error, predictAttrition, predictPerformance]);

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-200 rounded w-1/4"></div>
          <div className="space-y-3">
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded w-5/6"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="text-red-500">Failed to load predictions</div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">AI Predictions</h3>
          <p className="text-sm text-gray-500">Machine learning-powered insights</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-6">
        {predictions.attrition && (
          <div className={`p-4 rounded-lg ${
            predictions.attrition.risk > 0.7 ? 'bg-red-50' :
            predictions.attrition.risk > 0.3 ? 'bg-yellow-50' : 'bg-green-50'
          }`}>
            <div className="flex items-start space-x-3">
              <AlertTriangle className="h-5 w-5 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium">Attrition Risk Analysis</h4>
                <p className="text-sm mt-1">
                  Risk Score: {(predictions.attrition.risk * 100).toFixed(1)}%
                </p>
                {predictions.attrition.factors.length > 0 && (
                  <div className="mt-2">
                    <p className="text-sm font-medium">Key Factors:</p>
                    <ul className="mt-1 space-y-1">
                      {predictions.attrition.factors.map((factor, index) => (
                        <li key={index} className="text-sm flex items-center">
                          <span className="w-1.5 h-1.5 bg-red-400 rounded-full mr-2"></span>
                          {factor}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {predictions.performance && (
          <div className="p-4 rounded-lg bg-blue-50">
            <div className="flex items-start space-x-3">
              <TrendingUp className="h-5 w-5 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium">Performance Prediction</h4>
                <p className="text-sm mt-1">
                  Predicted Score: {predictions.performance.predictedScore.toFixed(1)}/5.0
                </p>
                {predictions.performance.recommendations.length > 0 && (
                  <div className="mt-2">
                    <p className="text-sm font-medium">Recommendations:</p>
                    <ul className="mt-1 space-y-1">
                      {predictions.performance.recommendations.map((rec, index) => (
                        <li key={index} className="text-sm flex items-center">
                          <span className="w-1.5 h-1.5 bg-blue-400 rounded-full mr-2"></span>
                          {rec}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}