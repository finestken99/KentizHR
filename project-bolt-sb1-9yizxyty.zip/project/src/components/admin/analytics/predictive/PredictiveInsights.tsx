import React from 'react';
import { Brain, TrendingUp, AlertTriangle } from 'lucide-react';

const predictions = [
  {
    category: 'Turnover Risk',
    prediction: 'Engineering team shows 15% increased turnover risk',
    impact: 'High impact on project delivery',
    recommendation: 'Consider implementing retention programs',
    priority: 'high'
  },
  {
    category: 'Performance Trend',
    prediction: 'Marketing team productivity expected to rise by 12%',
    impact: 'Positive impact on Q3 goals',
    recommendation: 'Maintain current team dynamics',
    priority: 'medium'
  },
  {
    category: 'Resource Planning',
    prediction: 'Additional hiring needed in Q4',
    impact: 'Moderate impact on delivery timelines',
    recommendation: 'Begin recruitment planning',
    priority: 'low'
  }
];

const priorityStyles = {
  high: 'bg-red-50 border-red-200 text-red-700',
  medium: 'bg-yellow-50 border-yellow-200 text-yellow-700',
  low: 'bg-green-50 border-green-200 text-green-700'
};

export function PredictiveInsights() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">AI Predictions</h3>
          <p className="text-sm text-gray-500">Machine learning-powered insights</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {predictions.map((prediction, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg border ${priorityStyles[prediction.priority]}`}
          >
            <div className="flex items-start space-x-3">
              {prediction.priority === 'high' ? (
                <AlertTriangle className="h-5 w-5 mt-0.5" />
              ) : (
                <TrendingUp className="h-5 w-5 mt-0.5" />
              )}
              <div>
                <h4 className="text-sm font-medium">{prediction.category}</h4>
                <p className="text-sm mt-1">{prediction.prediction}</p>
                <div className="mt-2 text-sm">
                  <p><span className="font-medium">Impact:</span> {prediction.impact}</p>
                  <p className="mt-1">
                    <span className="font-medium">Recommendation:</span> {prediction.recommendation}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <Brain className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">AI Confidence Level</h4>
            <p className="text-sm text-gray-600 mt-1">
              Predictions are based on historical data analysis with 92% accuracy rate.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}