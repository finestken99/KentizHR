import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { Brain, Users } from 'lucide-react';

const diversityData = [
  { name: 'Gender Diversity', data: [
    { name: 'Male', value: 55, color: '#3B82F6' },
    { name: 'Female', value: 42, color: '#EC4899' },
    { name: 'Non-Binary', value: 3, color: '#8B5CF6' }
  ]},
  { name: 'Age Distribution', data: [
    { name: '20-30', value: 30, color: '#10B981' },
    { name: '31-40', value: 45, color: '#6366F1' },
    { name: '41-50', value: 20, color: '#F59E0B' },
    { name: '51+', value: 5, color: '#EF4444' }
  ]},
  { name: 'Ethnicity', data: [
    { name: 'Asian', value: 35, color: '#3B82F6' },
    { name: 'White', value: 30, color: '#10B981' },
    { name: 'Hispanic', value: 20, color: '#F59E0B' },
    { name: 'Black', value: 15, color: '#6366F1' }
  ]}
];

const insights = [
  {
    metric: 'Gender Pay Gap',
    value: '97%',
    trend: '+2%',
    description: 'Progress towards pay equity'
  },
  {
    metric: 'Leadership Diversity',
    value: '42%',
    trend: '+5%',
    description: 'Diverse representation in management'
  }
];

export function DiversityMetrics() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Diversity Analytics</h3>
          <p className="text-sm text-gray-500">Workforce diversity insights and trends</p>
        </div>
        <Users className="h-6 w-6 text-blue-500" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {diversityData.map((category) => (
          <div key={category.name} className="h-64">
            <h4 className="text-sm font-medium text-gray-900 mb-2">{category.name}</h4>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={category.data}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {category.data.map((entry) => (
                    <Cell key={entry.name} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <Brain className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">Key Metrics</h4>
            <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-4">
              {insights.map((insight) => (
                <div key={insight.metric} className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{insight.metric}</p>
                    <p className="text-xs text-gray-600">{insight.description}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-lg font-semibold text-gray-900">{insight.value}</span>
                    <span className="ml-1 text-sm text-green-600">{insight.trend}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}