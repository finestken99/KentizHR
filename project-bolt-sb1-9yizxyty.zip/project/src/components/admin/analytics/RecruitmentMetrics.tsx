import React from 'react';
import { Users, Clock, DollarSign, CheckCircle } from 'lucide-react';

const metrics = [
  {
    label: 'Open Positions',
    value: '12',
    icon: Users,
    details: [
      { label: 'Engineering', value: '5' },
      { label: 'Sales', value: '3' },
      { label: 'Marketing', value: '2' },
      { label: 'Other', value: '2' }
    ]
  },
  {
    label: 'Time to Fill',
    value: '28 days',
    icon: Clock,
    details: [
      { label: 'Screening', value: '7 days' },
      { label: 'Interviews', value: '14 days' },
      { label: 'Offer', value: '7 days' }
    ]
  },
  {
    label: 'Cost per Hire',
    value: '$3,200',
    icon: DollarSign,
    details: [
      { label: 'Advertising', value: '$800' },
      { label: 'Agency Fees', value: '$1,500' },
      { label: 'Other', value: '$900' }
    ]
  },
  {
    label: 'Offer Acceptance',
    value: '85%',
    icon: CheckCircle,
    details: [
      { label: 'Accepted', value: '17' },
      { label: 'Declined', value: '3' },
      { label: 'Pending', value: '2' }
    ]
  }
];

export function RecruitmentMetrics() {
  return (
    <div className="bg-white rounded-lg shadow">
      <div className="px-6 py-5 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900">
          Recruitment Analytics
        </h3>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 divide-y md:divide-y-0 md:divide-x divide-gray-200">
        {metrics.map(({ label, value, icon: Icon, details }) => (
          <div key={label} className="p-6">
            <div className="flex items-center mb-4">
              <Icon className="h-6 w-6 text-blue-600 mr-2" />
              <h4 className="text-sm font-medium text-gray-500">{label}</h4>
            </div>
            <p className="text-2xl font-semibold text-gray-900 mb-4">{value}</p>
            <div className="space-y-2">
              {details.map((detail) => (
                <div key={detail.label} className="flex justify-between text-sm">
                  <span className="text-gray-500">{detail.label}</span>
                  <span className="text-gray-900 font-medium">{detail.value}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}