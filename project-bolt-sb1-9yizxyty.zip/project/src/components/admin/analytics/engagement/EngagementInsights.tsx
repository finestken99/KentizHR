import React from 'react';
import { Brain, TrendingUp, AlertTriangle } from 'lucide-react';

const insights = [
  {
    type: 'trend',
    content: 'Engineering team shows highest engagement growth at 15%',
    icon: TrendingUp,
    color: 'text-green-500',
    bgColor: 'bg-green-50'
  },
  {
    type: 'action',
    content: 'Consider team building activities for Marketing department',
    icon: Brain,
    color: 'text-blue-500',
    bgColor: 'bg-blue-50'
  },
  {
    type: 'alert',
    content: 'Slight decline in Finance team participation this month',
    icon: AlertTriangle,
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-50'
  }
];

export function EngagementInsights() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">AI Insights</h3>
          <p className="text-sm text-gray-500">Engagement analysis and recommendations</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {insights.map((insight, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg ${insight.bgColor}`}
          >
            <div className="flex items-start space-x-3">
              <insight.icon className={`h-5 w-5 ${insight.color} mt-0.5`} />
              <div>
                <div className="text-sm text-gray-900">{insight.content}</div>
                <div className={`text-xs mt-1 capitalize ${insight.color}`}>{insight.type}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}