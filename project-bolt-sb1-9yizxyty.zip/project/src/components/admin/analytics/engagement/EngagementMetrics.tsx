import React from 'react';
import { Heart, Users, TrendingUp, Target } from 'lucide-react';

const metrics = [
  {
    label: 'Overall Engagement',
    value: '85%',
    change: '+5%',
    icon: Heart,
    color: 'text-pink-500',
    bgColor: 'bg-pink-100'
  },
  {
    label: 'Active Participation',
    value: '92%',
    change: '+3%',
    icon: Users,
    color: 'text-blue-500',
    bgColor: 'bg-blue-100'
  },
  {
    label: 'Growth Index',
    value: '78%',
    change: '+8%',
    icon: TrendingUp,
    color: 'text-green-500',
    bgColor: 'bg-green-100'
  },
  {
    label: 'Goal Achievement',
    value: '88%',
    change: '+6%',
    icon: Target,
    color: 'text-purple-500',
    bgColor: 'bg-purple-100'
  }
];

export function EngagementMetrics() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metrics.map(({ label, value, change, icon: Icon, color, bgColor }) => (
        <div key={label} className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center space-x-4">
            <div className={`${bgColor} p-3 rounded-lg`}>
              <Icon className={`h-6 w-6 ${color}`} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">{label}</p>
              <div className="flex items-baseline">
                <p className="text-2xl font-semibold text-gray-900">{value}</p>
                <span className={`ml-2 text-sm ${
                  change.startsWith('+') ? 'text-green-500' : 'text-red-500'
                }`}>
                  {change}
                </span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}