import React from 'react';
import { Container } from '../../ui/Container';
import { AnalyticsOverview } from './sections/AnalyticsOverview';
import { CustomDashboards } from './sections/CustomDashboards';
import { DataVisualization } from './sections/DataVisualization';
import { AutomatedReports } from './sections/AutomatedReports';
import { SecurityCompliance } from './sections/SecurityCompliance';

export function AnalyticsDashboard() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Analytics & Reporting</h2>
          <p className="mt-2 text-gray-600">
            Comprehensive insights and data visualization tools
          </p>
        </div>

        <div className="space-y-8">
          <AnalyticsOverview />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <CustomDashboards />
            <DataVisualization />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <AutomatedReports />
            <SecurityCompliance />
          </div>
        </div>
      </Container>
    </div>
  );
}