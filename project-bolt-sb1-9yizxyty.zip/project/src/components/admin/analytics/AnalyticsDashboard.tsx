import React from 'react';
import { Container } from '../../ui/Container';
import { AnalyticsOverview } from './overview/AnalyticsOverview';
import { WorkforceComposition } from './workforce/WorkforceComposition';
import { TalentMetrics } from './talent/TalentMetrics';
import { EngagementAnalytics } from './engagement/EngagementAnalytics';
import { DiversityMetrics } from './diversity/DiversityMetrics';
import { PredictiveInsights } from './predictive/PredictiveInsights';
import { PerformanceTrends } from './performance/PerformanceTrends';

export function AnalyticsDashboard() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Advanced People Analytics</h2>
          <p className="mt-2 text-gray-600">
            AI-powered workforce analytics and predictive insights
          </p>
        </div>

        <div className="space-y-8">
          <AnalyticsOverview />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <WorkforceComposition />
            <TalentMetrics />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <EngagementAnalytics />
            <DiversityMetrics />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <PredictiveInsights />
            <PerformanceTrends />
          </div>
        </div>
      </Container>
    </div>
  );
}