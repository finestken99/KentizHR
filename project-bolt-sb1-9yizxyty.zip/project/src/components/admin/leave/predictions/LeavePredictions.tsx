import React from 'react';
import { Brain, AlertTriangle, Calendar, Users } from 'lucide-react';

const predictions = [
  {
    department: 'Engineering',
    risk: 'high',
    impact: 'Critical project deadlines may be affected',
    recommendation: 'Consider temporary staff allocation'
  },
  {
    department: 'Sales',
    risk: 'medium',
    impact: 'Quarter-end targets might be impacted',
    recommendation: 'Adjust team schedules proactively'
  },
  {
    department: 'Marketing',
    risk: 'low',
    impact: 'Minimal disruption expected',
    recommendation: 'Standard coverage should suffice'
  }
];

const riskStyles = {
  high: 'bg-red-50 border-red-200',
  medium: 'bg-yellow-50 border-yellow-200',
  low: 'bg-green-50 border-green-200'
};

export function LeavePredictions() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Leave Impact Predictions</h3>
          <p className="text-sm text-gray-500">AI-powered workforce planning insights</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {predictions.map((pred, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg border ${riskStyles[pred.risk]}`}
          >
            <div className="flex items-start space-x-3">
              <AlertTriangle className="h-5 w-5 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium">{pred.department}</h4>
                <p className="text-sm mt-1">{pred.impact}</p>
                <div className="flex items-center mt-2 text-sm text-blue-600">
                  <Brain className="h-4 w-4 mr-1" />
                  {pred.recommendation}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}