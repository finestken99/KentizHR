import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Brain, TrendingUp } from 'lucide-react';

const data = [
  { month: 'Jan', actual: 45, predicted: 42 },
  { month: 'Feb', actual: 38, predicted: 40 },
  { month: 'Mar', actual: 52, predicted: 50 },
  { month: 'Apr', actual: 35, predicted: 38 },
  { month: 'May', actual: 40, predicted: 42 },
  { month: 'Jun', actual: 48, predicted: 45 }
];

export function LeaveAnalytics() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Leave Trends</h3>
          <p className="text-sm text-gray-500">Historical and predicted leave patterns</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Line 
              type="monotone" 
              dataKey="actual" 
              stroke="#3B82F6" 
              strokeWidth={2}
              name="Actual Leave"
            />
            <Line 
              type="monotone" 
              dataKey="predicted" 
              stroke="#10B981" 
              strokeWidth={2}
              strokeDasharray="5 5"
              name="Predicted Leave"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-4">
        <div className="p-4 bg-blue-50 rounded-lg">
          <div className="flex items-center space-x-2">
            <TrendingUp className="h-5 w-5 text-blue-500" />
            <span className="text-sm font-medium text-gray-900">Current Trend</span>
          </div>
          <p className="mt-2 text-sm text-gray-600">
            Leave requests are 15% higher than the same period last year
          </p>
        </div>
        <div className="p-4 bg-green-50 rounded-lg">
          <div className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-green-500" />
            <span className="text-sm font-medium text-gray-900">AI Prediction</span>
          </div>
          <p className="mt-2 text-sm text-gray-600">
            Expected 20% increase in leave requests next quarter
          </p>
        </div>
      </div>
    </div>
  );
}