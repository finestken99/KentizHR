import React from 'react';
import { LeaveStats } from './LeaveStats';
import { LeaveBalance } from './LeaveBalance';

export function LeaveOverview() {
  return (
    <div className="space-y-8">
      <LeaveStats />
      <LeaveBalance />
    </div>
  );
}