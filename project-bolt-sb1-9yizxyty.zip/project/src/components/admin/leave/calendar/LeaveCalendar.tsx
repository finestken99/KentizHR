import React, { useState } from 'react';
import { CalendarHeader } from './CalendarHeader';
import { CalendarGrid } from './CalendarGrid';

const mockEvents = [
  {
    date: '2024-03-20',
    events: [
      { name: 'John Smith', type: 'Annual Leave' },
      { name: 'Sarah Johnson', type: 'Sick Leave' }
    ]
  },
  {
    date: '2024-03-21',
    events: [
      { name: 'Mike Wilson', type: 'Personal Leave' }
    ]
  }
];

export function LeaveCalendar() {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const handlePreviousMonth = () => {
    setCurrentMonth(new Date(
      currentMonth.getFullYear(),
      currentMonth.getMonth() - 1,
      1
    ));
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(
      currentMonth.getFullYear(),
      currentMonth.getMonth() + 1,
      1
    ));
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <CalendarHeader
        currentMonth={currentMonth}
        onPreviousMonth={handlePreviousMonth}
        onNextMonth={handleNextMonth}
      />
      <CalendarGrid
        currentMonth={currentMonth}
        events={mockEvents}
      />
    </div>
  );
}