import React from 'react';
import { Link2, MessageSquare, Video, Mail, CreditCard } from 'lucide-react';
import { Button } from '../../../ui/Button';

const integrations = [
  {
    name: 'Slack',
    icon: MessageSquare,
    status: 'connected',
    lastSync: '5 minutes ago'
  },
  {
    name: 'Zoom',
    icon: Video,
    status: 'connected',
    lastSync: '1 hour ago'
  },
  {
    name: 'Gmail',
    icon: Mail,
    status: 'disconnected',
    lastSync: 'Never'
  },
  {
    name: 'QuickBooks',
    icon: CreditCard,
    status: 'connected',
    lastSync: '30 minutes ago'
  }
];

export function IntegrationSettings() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-gray-900">Integration Settings</h3>
        <Button variant="secondary">
          <Link2 className="h-4 w-4 mr-2" />
          Add Integration
        </Button>
      </div>
      
      <div className="space-y-4">
        {integrations.map((integration) => {
          const Icon = integration.icon;
          return (
            <div
              key={integration.name}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center space-x-3">
                <Icon className="h-6 w-6 text-blue-500" />
                <div>
                  <h4 className="text-sm font-medium text-gray-900">{integration.name}</h4>
                  <p className="text-sm text-gray-500">Last sync: {integration.lastSync}</p>
                </div>
              </div>
              <Button 
                variant={integration.status === 'connected' ? 'secondary' : 'primary'}
              >
                {integration.status === 'connected' ? 'Configure' : 'Connect'}
              </Button>
            </div>
          );
        })}
      </div>
    </div>
  );
}