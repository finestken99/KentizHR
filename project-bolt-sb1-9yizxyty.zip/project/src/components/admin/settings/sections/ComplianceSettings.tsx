import React from 'react';
import { Shield, FileCheck, AlertTriangle } from 'lucide-react';
import { Button } from '../../../ui/Button';

const complianceItems = [
  {
    title: 'Data Protection',
    status: 'compliant',
    lastCheck: '2024-03-15',
    icon: Shield
  },
  {
    title: 'Document Retention',
    status: 'review_needed',
    lastCheck: '2024-03-10',
    icon: FileCheck
  },
  {
    title: 'Security Standards',
    status: 'compliant',
    lastCheck: '2024-03-14',
    icon: AlertTriangle
  }
];

export function ComplianceSettings() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">Compliance Settings</h3>
      
      <div className="space-y-4">
        {complianceItems.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.title}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center space-x-3">
                <Icon className={`h-6 w-6 ${
                  item.status === 'compliant' ? 'text-green-500' : 'text-yellow-500'
                }`} />
                <div>
                  <h4 className="text-sm font-medium text-gray-900">{item.title}</h4>
                  <p className="text-sm text-gray-500">Last check: {item.lastCheck}</p>
                </div>
              </div>
              <Button variant="secondary">Review</Button>
            </div>
          );
        })}
      </div>
    </div>
  );
}