import React, { useState } from 'react';
import { Lock, Key, Shield, Smartphone, AlertTriangle } from 'lucide-react';
import { Button } from '../../../ui/Button';
import { useUser } from '../../../../contexts/UserContext';

export function SecuritySettings() {
  const [mfaEnabled, setMfaEnabled] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const { setUser } = useUser();

  const handleDeleteAccount = () => {
    localStorage.removeItem('auth_token');
    setUser(null);
    window.location.hash = '#';
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">Security Settings</h3>

      <div className="space-y-6">
        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center space-x-3">
            <Lock className="h-6 w-6 text-blue-500" />
            <div>
              <h4 className="text-sm font-medium text-gray-900">Change Password</h4>
              <p className="text-sm text-gray-500">Update your account password</p>
            </div>
          </div>
          <Button variant="secondary">Change</Button>
        </div>

        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center space-x-3">
            <Key className="h-6 w-6 text-blue-500" />
            <div>
              <h4 className="text-sm font-medium text-gray-900">Two-Factor Authentication</h4>
              <p className="text-sm text-gray-500">Add an extra layer of security</p>
            </div>
          </div>
          <div className="flex items-center">
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                className="sr-only peer"
                checked={mfaEnabled}
                onChange={() => setMfaEnabled(!mfaEnabled)}
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
        </div>

        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center space-x-3">
            <Shield className="h-6 w-6 text-blue-500" />
            <div>
              <h4 className="text-sm font-medium text-gray-900">Security Log</h4>
              <p className="text-sm text-gray-500">View recent security activity</p>
            </div>
          </div>
          <Button variant="secondary">View Log</Button>
        </div>

        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center space-x-3">
            <Smartphone className="h-6 w-6 text-blue-500" />
            <div>
              <h4 className="text-sm font-medium text-gray-900">Connected Devices</h4>
              <p className="text-sm text-gray-500">Manage your connected devices</p>
            </div>
          </div>
          <Button variant="secondary">Manage</Button>
        </div>

        <div className="border-t pt-6 mt-6">
          <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <AlertTriangle className="h-6 w-6 text-red-500" />
              <div>
                <h4 className="text-sm font-medium text-gray-900">Delete Account</h4>
                <p className="text-sm text-gray-500">Permanently delete your account and all data</p>
              </div>
            </div>
            {!showDeleteConfirm ? (
              <Button 
                variant="secondary" 
                className="text-red-600 hover:text-red-700 border-red-200 hover:bg-red-50"
                onClick={() => setShowDeleteConfirm(true)}
              >
                Delete Account
              </Button>
            ) : (
              <div className="flex items-center space-x-2">
                <Button 
                  variant="secondary"
                  onClick={() => setShowDeleteConfirm(false)}
                >
                  Cancel
                </Button>
                <Button 
                  variant="secondary"
                  className="bg-red-600 text-white hover:bg-red-700 border-red-600"
                  onClick={handleDeleteAccount}
                >
                  Confirm Delete
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}