import React from 'react';
import { Container } from '../../ui/Container';
import { GeneralSettings } from './sections/GeneralSettings';
import { SecuritySettings } from './sections/SecuritySettings';
import { NotificationSettings } from './sections/NotificationSettings';
import { IntegrationSettings } from './sections/IntegrationSettings';
import { ComplianceSettings } from './sections/ComplianceSettings';
import { AuditLogs } from './sections/AuditLogs';

export function SettingsDashboard() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">System Settings</h2>
          <p className="mt-2 text-gray-600">
            Configure and manage your organization's HR system settings
          </p>
        </div>

        <div className="space-y-8">
          <GeneralSettings />
          <SecuritySettings />
          <NotificationSettings />
          <IntegrationSettings />
          <ComplianceSettings />
          <AuditLogs />
        </div>
      </Container>
    </div>
  );
}