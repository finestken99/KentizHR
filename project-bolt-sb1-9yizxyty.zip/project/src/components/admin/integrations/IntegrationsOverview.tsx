import React from 'react';
import { Link2, AlertTriangle, CheckCircle, Activity } from 'lucide-react';

const stats = [
  {
    label: 'Active Integrations',
    value: '12',
    change: '+2',
    icon: Link2,
    color: 'blue'
  },
  {
    label: 'Failed Syncs',
    value: '3',
    change: '-1',
    icon: AlertTriangle,
    color: 'red'
  },
  {
    label: 'Successful Syncs',
    value: '2.4K',
    change: '+12%',
    icon: CheckCircle,
    color: 'green'
  },
  {
    label: 'API Usage',
    value: '85%',
    change: '+5%',
    icon: Activity,
    color: 'yellow'
  }
];

export function IntegrationsOverview() {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map(({ label, value, change, icon: Icon, color }) => (
        <div key={label} className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className={`flex-shrink-0 rounded-md p-3 bg-${color}-100`}>
                <Icon className={`h-6 w-6 text-${color}-600`} />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    {label}
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      {value}
                    </div>
                    <div className="ml-2 flex items-baseline text-sm font-semibold text-green-600">
                      {change}
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}