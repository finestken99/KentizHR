import React from 'react';
import { CheckCircle, AlertTriangle, Clock, Search, Filter } from 'lucide-react';

const logs = [
  {
    id: 1,
    integration: 'Slack',
    event: 'Data Sync',
    status: 'success',
    message: 'Successfully synced user data',
    timestamp: '2024-03-15 14:30:00'
  },
  {
    id: 2,
    integration: 'QuickBooks',
    event: 'API Call',
    status: 'error',
    message: 'Failed to update payroll data',
    timestamp: '2024-03-15 14:15:00'
  },
  {
    id: 3,
    integration: 'Zoom',
    event: 'Authentication',
    status: 'pending',
    message: 'Waiting for OAuth token refresh',
    timestamp: '2024-03-15 14:00:00'
  }
];

const statusConfig = {
  success: { icon: CheckCircle, className: 'text-green-600' },
  error: { icon: AlertTriangle, className: 'text-red-600' },
  pending: { icon: Clock, className: 'text-yellow-600' }
};

export function IntegrationLogs() {
  return (
    <div className="bg-white shadow rounded-lg">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-medium text-gray-900">Integration Logs</h3>
          <div className="flex gap-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search logs..."
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
            <button className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50">
              <Filter className="h-5 w-5 text-gray-400" />
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Integration
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Event
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Message
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Timestamp
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {logs.map((log) => {
                const StatusIcon = statusConfig[log.status].icon;
                return (
                  <tr key={log.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-sm font-medium text-gray-900">
                        {log.integration}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-sm text-gray-500">
                        {log.event}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <StatusIcon className={`h-5 w-5 ${statusConfig[log.status].className} mr-2`} />
                        <span className="text-sm text-gray-900 capitalize">
                          {log.status}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-sm text-gray-500">
                        {log.message}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {log.timestamp}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}