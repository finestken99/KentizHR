import React from 'react';
import { MessageSquare, Video, Mail, CreditCard, Linkedin as LinkedIn, Phone, Settings, Power } from 'lucide-react';
import { Button } from '../../ui/Button';

const integrations = [
  {
    id: 1,
    name: 'Slack',
    description: 'Team communication and notifications',
    icon: MessageSquare,
    status: 'active',
    lastSync: '5 minutes ago'
  },
  {
    id: 2,
    name: 'Zoom',
    description: 'Video conferencing integration',
    icon: Video,
    status: 'active',
    lastSync: '1 hour ago'
  },
  {
    id: 3,
    name: 'Gmail',
    description: 'Email notifications and calendar sync',
    icon: Mail,
    status: 'inactive',
    lastSync: 'Never'
  },
  {
    id: 4,
    name: 'QuickBooks',
    description: 'Payroll and accounting integration',
    icon: CreditCard,
    status: 'active',
    lastSync: '30 minutes ago'
  },
  {
    id: 5,
    name: 'LinkedIn',
    description: 'Recruitment and job posting',
    icon: LinkedIn,
    status: 'active',
    lastSync: '2 hours ago'
  },
  {
    id: 6,
    name: 'Teams',
    description: 'Microsoft Teams integration',
    icon: Phone,
    status: 'inactive',
    lastSync: 'Never'
  }
];

export function IntegrationsList() {
  return (
    <div className="bg-white shadow rounded-lg">
      <div className="p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-6">Available Integrations</h3>
        <div className="space-y-4">
          {integrations.map((integration) => {
            const Icon = integration.icon;
            return (
              <div
                key={integration.id}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-gray-300 transition-colors"
              >
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-gray-100 rounded-lg">
                    <Icon className="h-6 w-6 text-gray-600" />
                  </div>
                  <div>
                    <h4 className="text-base font-medium text-gray-900">
                      {integration.name}
                    </h4>
                    <p className="text-sm text-gray-500">
                      {integration.description}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <div className={`text-sm font-medium ${
                      integration.status === 'active' ? 'text-green-600' : 'text-gray-500'
                    }`}>
                      {integration.status === 'active' ? 'Active' : 'Inactive'}
                    </div>
                    <div className="text-xs text-gray-500">
                      Last sync: {integration.lastSync}
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="secondary" className="p-2">
                      <Settings className="h-5 w-5" />
                    </Button>
                    <Button 
                      variant="secondary" 
                      className={`p-2 ${
                        integration.status === 'active' 
                          ? 'text-green-600 hover:text-green-700' 
                          : 'text-gray-400 hover:text-gray-500'
                      }`}
                    >
                      <Power className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}