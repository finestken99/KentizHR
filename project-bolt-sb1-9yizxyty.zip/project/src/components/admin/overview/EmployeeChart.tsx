import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { month: 'Jan', total: 220, newHires: 15, departures: 8 },
  { month: 'Feb', total: 227, newHires: 12, departures: 5 },
  { month: 'Mar', total: 234, newHires: 18, departures: 11 },
  { month: 'Apr', total: 241, newHires: 14, departures: 7 },
  { month: 'May', total: 248, newHires: 16, departures: 9 },
  { month: 'Jun', total: 255, newHires: 20, departures: 13 }
];

export function EmployeeChart() {
  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium text-gray-900">Employee Growth Trends</h3>
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-500 rounded-full mr-2" />
            <span className="text-sm text-gray-600">Total Employees</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-2" />
            <span className="text-sm text-gray-600">New Hires</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-red-500 rounded-full mr-2" />
            <span className="text-sm text-gray-600">Departures</span>
          </div>
        </div>
      </div>

      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis yAxisId="left" />
            <YAxis yAxisId="right" orientation="right" />
            <Tooltip />
            <Line
              yAxisId="left"
              type="monotone"
              dataKey="total"
              stroke="#3B82F6"
              strokeWidth={2}
              dot={{ r: 4 }}
              name="Total Employees"
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="newHires"
              stroke="#10B981"
              strokeWidth={2}
              dot={{ r: 4 }}
              name="New Hires"
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="departures"
              stroke="#EF4444"
              strokeWidth={2}
              dot={{ r: 4 }}
              name="Departures"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-4">
        <div className="bg-blue-50 p-3 rounded-lg">
          <div className="text-sm text-gray-500">Current Headcount</div>
          <div className="text-xl font-semibold text-blue-600">255</div>
        </div>
        <div className="bg-green-50 p-3 rounded-lg">
          <div className="text-sm text-gray-500">YTD New Hires</div>
          <div className="text-xl font-semibold text-green-600">95</div>
        </div>
        <div className="bg-red-50 p-3 rounded-lg">
          <div className="text-sm text-gray-500">YTD Turnover Rate</div>
          <div className="text-xl font-semibold text-red-600">4.2%</div>
        </div>
      </div>
    </div>
  );
}