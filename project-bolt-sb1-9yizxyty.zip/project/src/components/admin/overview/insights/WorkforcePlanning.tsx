import React from 'react';
import { Brain, Book, Target, Award } from 'lucide-react';

const recommendations = [
  {
    title: 'Hiring Needs',
    description: 'Consider hiring 3 engineers in Q3 based on project pipeline',
    icon: Target,
    priority: 'high'
  },
  {
    title: 'Skill Development',
    description: 'Invest in AI/ML training for the data team',
    icon: Book,
    priority: 'medium'
  },
  {
    title: 'Resource Allocation',
    description: 'Rebalance project teams for optimal productivity',
    icon: Award,
    priority: 'low'
  }
];

const priorityStyles = {
  high: 'bg-red-50 text-red-700',
  medium: 'bg-yellow-50 text-yellow-700',
  low: 'bg-green-50 text-green-700'
};

export function WorkforcePlanning() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Workforce Planning</h3>
          <p className="text-sm text-gray-500">AI-generated recommendations</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {recommendations.map((rec, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg ${priorityStyles[rec.priority]}`}
          >
            <div className="flex items-start space-x-3">
              <rec.icon className="h-5 w-5 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium">{rec.title}</h4>
                <p className="text-sm mt-1">{rec.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}