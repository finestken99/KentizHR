import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, Users } from 'lucide-react';

const data = [
  { department: 'Engineering', headcount: 85, growth: 12 },
  { department: 'Sales', headcount: 45, growth: 8 },
  { department: 'Marketing', headcount: 30, growth: 5 },
  { department: 'HR', headcount: 15, growth: 2 },
  { department: 'Finance', headcount: 25, growth: 4 }
];

export function WorkforceAnalytics() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Workforce Analytics</h3>
          <p className="text-sm text-gray-500">Department-wise distribution and growth</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center text-green-600">
            <TrendingUp className="h-5 w-5 mr-1" />
            <span className="text-sm font-medium">+15% YoY</span>
          </div>
          <div className="flex items-center text-blue-600">
            <Users className="h-5 w-5 mr-1" />
            <span className="text-sm font-medium">200 Total</span>
          </div>
        </div>
      </div>

      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="department" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="headcount" fill="#3B82F6" name="Headcount" />
            <Bar dataKey="growth" fill="#10B981" name="Growth" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}