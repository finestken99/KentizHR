import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp } from 'lucide-react';

const data = [
  { month: 'Jan', engagement: 75, productivity: 80 },
  { month: 'Feb', engagement: 78, productivity: 82 },
  { month: 'Mar', engagement: 82, productivity: 85 },
  { month: 'Apr', engagement: 85, productivity: 88 },
  { month: 'May', engagement: 88, productivity: 90 },
  { month: 'Jun', engagement: 92, productivity: 92 }
];

export function TrendAnalysis() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Trend Analysis</h3>
          <p className="text-sm text-gray-500">Performance metrics over time</p>
        </div>
        <TrendingUp className="h-6 w-6 text-blue-500" />
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="engagement" stroke="#3B82F6" name="Engagement" />
            <Line type="monotone" dataKey="productivity" stroke="#10B981" name="Productivity" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}