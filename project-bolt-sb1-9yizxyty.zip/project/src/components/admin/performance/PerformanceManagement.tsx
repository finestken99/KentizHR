import React from 'react';
import { PerformanceOverview } from './PerformanceOverview';
import { ReviewCycles } from './ReviewCycles';
import { TeamPerformance } from './TeamPerformance';
import { GoalTracking } from './GoalTracking';

export function PerformanceManagement() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Performance Management</h2>
        <p className="mt-1 text-sm text-gray-500">
          Track and manage employee performance, goals, and reviews
        </p>
      </div>

      <PerformanceOverview />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ReviewCycles />
        <TeamPerformance />
      </div>

      <GoalTracking />
    </div>
  );
}