import React from 'react';
import { Target, CheckCircle, Clock, AlertCircle } from 'lucide-react';

const goals = [
  {
    id: 1,
    title: 'Increase Team Productivity',
    owner: 'Engineering Team',
    progress: 75,
    status: 'on_track',
    dueDate: '2024-06-30',
    metrics: 'Sprint velocity increased by 20%'
  },
  {
    id: 2,
    title: 'Improve Customer Satisfaction',
    owner: 'Customer Success',
    progress: 60,
    status: 'at_risk',
    dueDate: '2024-04-15',
    metrics: 'NPS score target: 60'
  },
  {
    id: 3,
    title: 'Launch New Product Features',
    owner: 'Product Team',
    progress: 90,
    status: 'completed',
    dueDate: '2024-03-31',
    metrics: '5 new features launched'
  }
];

const statusConfig = {
  on_track: { icon: Clock, className: 'text-blue-600', label: 'On Track' },
  at_risk: { icon: AlertCircle, className: 'text-yellow-600', label: 'At Risk' },
  completed: { icon: CheckCircle, className: 'text-green-600', label: 'Completed' }
};

export function GoalTracking() {
  return (
    <div className="bg-white shadow rounded-lg">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-medium text-gray-900">Team Goals</h3>
          <button className="text-blue-600 hover:text-blue-700 font-medium">
            Add Goal
          </button>
        </div>

        <div className="space-y-6">
          {goals.map((goal) => {
            const StatusIcon = statusConfig[goal.status].icon;
            return (
              <div
                key={goal.id}
                className="border border-gray-200 rounded-lg p-4"
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center">
                      <Target className="h-5 w-5 text-gray-400 mr-2" />
                      <h4 className="text-lg font-medium text-gray-900">
                        {goal.title}
                      </h4>
                    </div>
                    <p className="mt-1 text-sm text-gray-500">
                      Owned by {goal.owner}
                    </p>
                  </div>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium`}>
                    <StatusIcon className={`h-4 w-4 ${statusConfig[goal.status].className} mr-1`} />
                    {statusConfig[goal.status].label}
                  </span>
                </div>

                <div className="mt-4">
                  <div className="flex justify-between text-sm text-gray-500 mb-1">
                    <span>Progress</span>
                    <span>{goal.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`rounded-full h-2 ${
                        goal.status === 'completed'
                          ? 'bg-green-600'
                          : goal.status === 'at_risk'
                          ? 'bg-yellow-600'
                          : 'bg-blue-600'
                      }`}
                      style={{ width: `${goal.progress}%` }}
                    />
                  </div>
                </div>

                <div className="mt-4 flex justify-between items-center text-sm">
                  <div className="text-gray-500">
                    Due: {goal.dueDate}
                  </div>
                  <div className="text-gray-900 font-medium">
                    {goal.metrics}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}