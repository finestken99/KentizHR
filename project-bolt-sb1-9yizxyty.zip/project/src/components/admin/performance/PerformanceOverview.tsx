import React from 'react';
import { TrendingUp, Users, Target, Award } from 'lucide-react';

const stats = [
  {
    label: 'Average Rating',
    value: '4.2',
    change: '+0.3',
    icon: TrendingUp,
    color: 'blue'
  },
  {
    label: 'Reviews Due',
    value: '28',
    change: '12 this week',
    icon: Users,
    color: 'yellow'
  },
  {
    label: 'Goals Completed',
    value: '85%',
    change: '+5%',
    icon: Target,
    color: 'green'
  },
  {
    label: 'Top Performers',
    value: '32',
    change: '+4',
    icon: Award,
    color: 'purple'
  }
];

export function PerformanceOverview() {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map(({ label, value, change, icon: Icon, color }) => (
        <div key={label} className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className={`flex-shrink-0 rounded-md p-3 bg-${color}-100`}>
                <Icon className={`h-6 w-6 text-${color}-600`} />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    {label}
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      {value}
                    </div>
                    <div className="ml-2 flex items-baseline text-sm font-semibold text-green-600">
                      {change}
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}