import React from 'react';
import { Calendar, Clock, CheckCircle } from 'lucide-react';

const reviews = [
  {
    id: 1,
    cycle: 'Q1 2024 Review',
    status: 'In Progress',
    dueDate: '2024-03-31',
    completion: 65,
    totalReviews: 48,
    completed: 31
  },
  {
    id: 2,
    cycle: 'Annual Review 2023',
    status: 'Completed',
    dueDate: '2023-12-31',
    completion: 100,
    totalReviews: 45,
    completed: 45
  },
  {
    id: 3,
    cycle: 'Mid-Year Review 2023',
    status: 'Completed',
    dueDate: '2023-06-30',
    completion: 100,
    totalReviews: 42,
    completed: 42
  }
];

export function ReviewCycles() {
  return (
    <div className="bg-white shadow rounded-lg">
      <div className="p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Review Cycles</h3>
        <div className="space-y-4">
          {reviews.map((review) => (
            <div
              key={review.id}
              className="border border-gray-200 rounded-lg p-4"
            >
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="text-base font-medium text-gray-900">
                    {review.cycle}
                  </h4>
                  <div className="flex items-center text-sm text-gray-500 mt-1">
                    <Calendar className="h-4 w-4 mr-1" />
                    Due: {review.dueDate}
                  </div>
                </div>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  review.status === 'Completed' 
                    ? 'bg-green-100 text-green-800'
                    : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {review.status}
                </span>
              </div>
              <div className="mt-4">
                <div className="flex justify-between text-sm text-gray-500 mb-1">
                  <span>Progress</span>
                  <span>{review.completion}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 rounded-full h-2"
                    style={{ width: `${review.completion}%` }}
                  />
                </div>
                <div className="flex justify-between items-center mt-2 text-sm text-gray-500">
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
                    {review.completed} completed
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 text-gray-400 mr-1" />
                    {review.totalReviews - review.completed} pending
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}