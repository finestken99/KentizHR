import React from 'react';
import { Users, Clock, CheckCircle, XCircle } from 'lucide-react';

const stats = [
  {
    label: 'Active Candidates',
    value: '124',
    change: '+12',
    icon: Users,
    color: 'text-blue-500',
    bgColor: 'bg-blue-100'
  },
  {
    label: 'Time to Hire',
    value: '28 days',
    change: '-3 days',
    icon: Clock,
    color: 'text-green-500',
    bgColor: 'bg-green-100'
  },
  {
    label: 'Offer Acceptance',
    value: '85%',
    change: '+5%',
    icon: CheckCircle,
    color: 'text-purple-500',
    bgColor: 'bg-purple-100'
  },
  {
    label: 'Rejection Rate',
    value: '15%',
    change: '-2%',
    icon: XCircle,
    color: 'text-red-500',
    bgColor: 'bg-red-100'
  }
];

export function CandidateStats() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">Recruitment Overview</h3>
      <div className="grid grid-cols-2 gap-4">
        {stats.map(({ label, value, change, icon: Icon, color, bgColor }) => (
          <div key={label} className="p-4 rounded-lg border border-gray-100">
            <div className={`w-10 h-10 ${bgColor} rounded-lg flex items-center justify-center mb-3`}>
              <Icon className={`h-5 w-5 ${color}`} />
            </div>
            <div className="text-sm font-medium text-gray-900">{label}</div>
            <div className="mt-1 flex items-baseline">
              <span className="text-2xl font-semibold text-gray-900">{value}</span>
              <span className={`ml-2 text-sm ${
                change.startsWith('+') ? 'text-green-500' : 'text-red-500'
              }`}>
                {change}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}