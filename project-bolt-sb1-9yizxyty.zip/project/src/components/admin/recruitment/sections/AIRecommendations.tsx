import React from 'react';
import { Brain, Star, TrendingUp } from 'lucide-react';

const recommendations = [
  {
    type: 'match',
    candidate: 'Sarah Wilson',
    score: 92,
    reason: 'Strong technical background and culture fit'
  },
  {
    type: 'insight',
    content: 'Consider scheduling technical interviews in the morning for better candidate performance',
    confidence: 85
  },
  {
    type: 'action',
    content: 'Follow up with 3 pending candidates within 24 hours',
    priority: 'high'
  }
];

export function AIRecommendations() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">AI Insights</h3>
          <p className="text-sm text-gray-500">Smart recruitment recommendations</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {recommendations.map((rec, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg ${
              rec.type === 'match'
                ? 'bg-green-50'
                : rec.type === 'insight'
                ? 'bg-blue-50'
                : 'bg-yellow-50'
            }`}
          >
            {rec.type === 'match' ? (
              <div className="flex items-start space-x-3">
                <Star className="h-5 w-5 text-green-500 mt-0.5" />
                <div>
                  <div className="text-sm font-medium text-gray-900">
                    Top Match: {rec.candidate}
                  </div>
                  <div className="text-sm text-gray-600 mt-1">
                    Match Score: {rec.score}%
                  </div>
                  <div className="text-sm text-gray-600 mt-1">
                    {rec.reason}
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-start space-x-3">
                {rec.type === 'insight' ? (
                  <Brain className="h-5 w-5 text-blue-500 mt-0.5" />
                ) : (
                  <TrendingUp className="h-5 w-5 text-yellow-500 mt-0.5" />
                )}
                <div>
                  <div className="text-sm text-gray-900">{rec.content}</div>
                  {rec.confidence && (
                    <div className="text-sm text-gray-600 mt-1">
                      Confidence: {rec.confidence}%
                    </div>
                  )}
                  {rec.priority && (
                    <div className="text-sm text-yellow-600 mt-1">
                      Priority: {rec.priority.toUpperCase()}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}