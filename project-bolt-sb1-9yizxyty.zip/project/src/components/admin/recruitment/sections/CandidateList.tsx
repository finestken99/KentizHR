import React from 'react';
import { User, Star, Mail, Phone, MapPin } from 'lucide-react';

const candidates = [
  {
    id: 1,
    name: 'Sarah Wilson',
    role: 'Senior Software Engineer',
    status: 'interview',
    location: 'San Francisco, CA',
    email: 'sarah.w@example.com',
    phone: '+1 (555) 123-4567',
    rating: 4
  },
  {
    id: 2,
    name: 'Michael Chen',
    role: 'Product Manager',
    status: 'screening',
    location: 'New York, NY',
    email: 'michael.c@example.com',
    phone: '+1 (555) 234-5678',
    rating: 3
  },
  {
    id: 3,
    name: 'Emily Rodriguez',
    role: 'UX Designer',
    status: 'offer',
    location: 'Austin, TX',
    email: 'emily.r@example.com',
    phone: '+1 (555) 345-6789',
    rating: 5
  }
];

const statusStyles = {
  screening: 'bg-yellow-100 text-yellow-800',
  interview: 'bg-blue-100 text-blue-800',
  offer: 'bg-green-100 text-green-800',
  rejected: 'bg-red-100 text-red-800'
};

export function CandidateList() {
  return (
    <div className="bg-white shadow-sm rounded-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Candidate
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Role
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Rating
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Contact
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {candidates.map((candidate) => (
              <tr key={candidate.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <User className="h-10 w-10 rounded-full bg-gray-100 p-2" />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">
                        {candidate.name}
                      </div>
                      <div className="flex items-center text-sm text-gray-500">
                        <MapPin className="h-4 w-4 mr-1" />
                        {candidate.location}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{candidate.role}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                    statusStyles[candidate.status]
                  }`}>
                    {candidate.status.charAt(0).toUpperCase() + candidate.status.slice(1)}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex">
                    {[...Array(5)].map((_, index) => (
                      <Star
                        key={index}
                        className={`h-5 w-5 ${
                          index < candidate.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <div className="flex items-center space-x-4">
                    <a href={`mailto:${candidate.email}`} className="text-gray-400 hover:text-gray-500">
                      <Mail className="h-5 w-5" />
                    </a>
                    <a href={`tel:${candidate.phone}`} className="text-gray-400 hover:text-gray-500">
                      <Phone className="h-5 w-5" />
                    </a>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}