import React, { useState } from 'react';
import { Container } from '../../ui/Container';
import { CandidateList } from './sections/CandidateList';
import { CandidateFilters } from './sections/CandidateFilters';
import { CandidateStats } from './sections/CandidateStats';
import { AIRecommendations } from './sections/AIRecommendations';
import { Button } from '../../ui/Button';
import { Plus } from 'lucide-react';

export function CandidateManagement() {
  const [showAddCandidate, setShowAddCandidate] = useState(false);

  return (
    <div className="py-8">
      <Container>
        <div className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Candidate Management</h2>
            <p className="mt-2 text-gray-600">
              Track and manage your recruitment pipeline
            </p>
          </div>
          <Button 
            variant="primary"
            onClick={() => setShowAddCandidate(true)}
          >
            <Plus className="h-5 w-5 mr-2" />
            Add Candidate
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <CandidateFilters />
            <CandidateList />
          </div>
          <div className="space-y-8">
            <CandidateStats />
            <AIRecommendations />
          </div>
        </div>
      </Container>
    </div>
  );
}