import React from 'react';
import { RecruitmentOverview } from './RecruitmentOverview';
import { CandidateTable } from './CandidateTable';
import { JobPostings } from './JobPostings';
import { RecruitmentFilters } from './RecruitmentFilters';

export function RecruitmentDashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Recruitment Dashboard</h2>
        <p className="mt-1 text-sm text-gray-500">
          Manage your recruitment pipeline and track candidate progress
        </p>
      </div>

      <RecruitmentOverview />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <RecruitmentFilters />
          <CandidateTable />
        </div>
        <div>
          <JobPostings />
        </div>
      </div>
    </div>
  );
}