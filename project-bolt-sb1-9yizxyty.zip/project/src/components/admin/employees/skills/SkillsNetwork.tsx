import React from 'react';
import { Brain, Star } from 'lucide-react';

const skills = [
  { name: 'Leadership', level: 85, growth: '+12%', category: 'Soft Skills' },
  { name: 'Technical', level: 92, growth: '+8%', category: 'Hard Skills' },
  { name: 'Communication', level: 88, growth: '+15%', category: 'Soft Skills' },
  { name: 'Problem Solving', level: 90, growth: '+10%', category: 'Core Skills' },
  { name: 'Innovation', level: 82, growth: '+18%', category: 'Core Skills' }
];

export function SkillsNetwork() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Skills Intelligence</h3>
          <p className="text-sm text-gray-500">AI-powered skills analysis</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {skills.map((skill) => (
          <div key={skill.name} className="p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <Star className="h-5 w-5 text-yellow-500" />
                <span className="font-medium text-gray-900">{skill.name}</span>
              </div>
              <span className="text-sm text-gray-500">{skill.category}</span>
            </div>
            
            <div className="mt-2">
              <div className="flex justify-between text-sm text-gray-600 mb-1">
                <span>Proficiency</span>
                <span className="text-green-600">{skill.growth}</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full">
                <div 
                  className="h-2 bg-blue-500 rounded-full"
                  style={{ width: `${skill.level}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}