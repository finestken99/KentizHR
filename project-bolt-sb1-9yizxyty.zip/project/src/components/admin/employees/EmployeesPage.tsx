import React from 'react';
import { Container } from '../../ui/Container';
import { EmployeeStats } from './stats/EmployeeStats';
import { EmployeeDistribution } from './distribution/EmployeeDistribution';
import { EmployeeSkills } from './skills/EmployeeSkills';
import { EmployeePerformance } from './performance/EmployeePerformance';
import { EmployeeRetention } from './retention/EmployeeRetention';
import { EmployeeList } from './list/EmployeeList';
import { EmployeeFilters } from './filters/EmployeeFilters';

export function EmployeesPage() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Employee Intelligence</h2>
          <p className="mt-2 text-gray-600">
            AI-powered talent insights and workforce analytics
          </p>
        </div>

        <div className="space-y-8">
          <EmployeeStats />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <EmployeeDistribution />
            <EmployeeSkills />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <EmployeePerformance />
            <EmployeeRetention />
          </div>

          <div className="bg-white rounded-lg shadow-sm">
            <EmployeeFilters />
            <EmployeeList />
          </div>
        </div>
      </Container>
    </div>
  );
}