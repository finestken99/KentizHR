export interface Employee {
  id: number;
  name: string;
  email: string;
  department: string;
  position: string;
  performance: number;
  status: string;
}

export interface Department {
  id: number;
  name: string;
  employeeCount: number;
  performance: number;
}

export interface Skill {
  name: string;
  level: number;
  growth: string;
  category: string;
}

export interface PerformanceMetric {
  month: string;
  average: number;
  top: number;
  bottom: number;
}

export interface RetentionRisk {
  department: string;
  riskLevel: 'high' | 'medium' | 'low';
  factors: string[];
  percentage: number;
}