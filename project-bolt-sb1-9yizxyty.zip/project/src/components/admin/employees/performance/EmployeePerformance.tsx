import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Brain, Star } from 'lucide-react';

const performanceData = [
  { month: 'Jan', rating: 4.2, teamAvg: 4.0 },
  { month: 'Feb', rating: 4.3, teamAvg: 4.1 },
  { month: 'Mar', rating: 4.5, teamAvg: 4.0 },
  { month: 'Apr', rating: 4.4, teamAvg: 4.2 },
  { month: 'May', rating: 4.6, teamAvg: 4.1 },
  { month: 'Jun', rating: 4.7, teamAvg: 4.2 }
];

export function EmployeePerformance() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Performance Trends</h3>
          <p className="text-sm text-gray-500">Monthly performance evaluation</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={performanceData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis domain={[0, 5]} />
            <Tooltip />
            <Line
              type="monotone"
              dataKey="rating"
              stroke="#3B82F6"
              strokeWidth={2}
              name="Individual Rating"
            />
            <Line
              type="monotone"
              dataKey="teamAvg"
              stroke="#10B981"
              strokeWidth={2}
              strokeDasharray="5 5"
              name="Team Average"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-6 grid grid-cols-3 gap-4">
        <div className="p-4 bg-blue-50 rounded-lg">
          <div className="flex items-center space-x-2">
            <Star className="h-5 w-5 text-blue-500" />
            <span className="text-sm font-medium text-gray-900">Current Rating</span>
          </div>
          <p className="mt-2 text-2xl font-semibold text-blue-600">4.7</p>
          <p className="text-sm text-blue-600">+0.2 from last month</p>
        </div>

        <div className="p-4 bg-green-50 rounded-lg">
          <div className="flex items-center space-x-2">
            <Star className="h-5 w-5 text-green-500" />
            <span className="text-sm font-medium text-gray-900">Team Average</span>
          </div>
          <p className="mt-2 text-2xl font-semibold text-green-600">4.2</p>
          <p className="text-sm text-green-600">Top 15% in team</p>
        </div>

        <div className="p-4 bg-purple-50 rounded-lg">
          <div className="flex items-center space-x-2">
            <Star className="h-5 w-5 text-purple-500" />
            <span className="text-sm font-medium text-gray-900">Growth Trend</span>
          </div>
          <p className="mt-2 text-2xl font-semibold text-purple-600">+12%</p>
          <p className="text-sm text-purple-600">Consistent improvement</p>
        </div>
      </div>
    </div>
  );
}