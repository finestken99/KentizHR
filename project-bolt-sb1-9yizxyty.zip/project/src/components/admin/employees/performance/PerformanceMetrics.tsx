import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, Brain } from 'lucide-react';

const data = [
  { month: 'Jan', average: 85, top: 95, bottom: 75 },
  { month: 'Feb', average: 87, top: 96, bottom: 76 },
  { month: 'Mar', average: 89, top: 98, bottom: 77 },
  { month: 'Apr', average: 86, top: 97, bottom: 74 },
  { month: 'May', average: 90, top: 99, bottom: 78 },
  { month: 'Jun', average: 92, top: 100, bottom: 80 }
];

export function PerformanceMetrics() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Performance Trends</h3>
          <p className="text-sm text-gray-500">AI-analyzed performance metrics</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis domain={[60, 100]} />
            <Tooltip />
            <Line 
              type="monotone" 
              dataKey="top" 
              stroke="#10B981" 
              name="Top Performers"
              strokeWidth={2}
            />
            <Line 
              type="monotone" 
              dataKey="average" 
              stroke="#3B82F6" 
              name="Average"
              strokeWidth={2}
            />
            <Line 
              type="monotone" 
              dataKey="bottom" 
              stroke="#EF4444" 
              name="Needs Improvement"
              strokeWidth={2}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-6 grid grid-cols-3 gap-4">
        <div className="p-4 bg-green-50 rounded-lg">
          <div className="text-sm font-medium text-gray-900">Top Performers</div>
          <div className="mt-1 text-2xl font-semibold text-green-600">32%</div>
          <div className="text-sm text-green-600">+5% from last month</div>
        </div>
        <div className="p-4 bg-blue-50 rounded-lg">
          <div className="text-sm font-medium text-gray-900">Average Score</div>
          <div className="mt-1 text-2xl font-semibold text-blue-600">88%</div>
          <div className="text-sm text-blue-600">+3% from last month</div>
        </div>
        <div className="p-4 bg-red-50 rounded-lg">
          <div className="text-sm font-medium text-gray-900">Needs Focus</div>
          <div className="mt-1 text-2xl font-semibold text-red-600">12%</div>
          <div className="text-sm text-red-600">-2% from last month</div>
        </div>
      </div>
    </div>
  );
}