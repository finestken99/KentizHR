import React from 'react';
import { Users, AlertTriangle, Brain } from 'lucide-react';

const riskFactors = [
  {
    department: 'Engineering',
    riskLevel: 'medium',
    factors: ['Workload', 'Career Growth'],
    percentage: 15
  },
  {
    department: 'Sales',
    riskLevel: 'low',
    factors: ['Compensation'],
    percentage: 8
  },
  {
    department: 'Marketing',
    riskLevel: 'high',
    factors: ['Work-Life Balance', 'Management', 'Compensation'],
    percentage: 25
  }
];

const riskStyles = {
  high: 'bg-red-50 border-red-200 text-red-700',
  medium: 'bg-yellow-50 border-yellow-200 text-yellow-700',
  low: 'bg-green-50 border-green-200 text-green-700'
};

export function EmployeeRetention() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Retention Risk Analysis</h3>
          <p className="text-sm text-gray-500">AI-predicted retention insights</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {riskFactors.map((dept) => (
          <div 
            key={dept.department}
            className={`p-4 rounded-lg ${riskStyles[dept.riskLevel]}`}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <Users className="h-5 w-5" />
                <span className="font-medium">{dept.department}</span>
              </div>
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-4 w-4" />
                <span className="text-sm">{dept.percentage}% Risk</span>
              </div>
            </div>

            <div className="mt-2">
              <div className="text-sm mb-2">Key Risk Factors:</div>
              <div className="flex flex-wrap gap-2">
                {dept.factors.map((factor) => (
                  <span
                    key={factor}
                    className="px-2 py-1 text-xs rounded-full bg-white bg-opacity-50"
                  >
                    {factor}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <Brain className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">AI Recommendation</h4>
            <p className="text-sm text-gray-600 mt-1">
              Consider implementing career development programs and reviewing compensation packages
              in the Marketing department to address retention risks.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}