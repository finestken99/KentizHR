import React from 'react';
import { Users, TrendingUp, Award, Brain } from 'lucide-react';
import { StatCard } from './StatCard';

const stats = [
  {
    label: 'Total Employees',
    value: '248',
    change: '+12',
    icon: Users,
    color: 'blue'
  },
  {
    label: 'High Performers',
    value: '42',
    change: '+8',
    icon: Award,
    color: 'green'
  },
  {
    label: 'Growth Potential',
    value: '85%',
    change: '+5%',
    icon: TrendingUp,
    color: 'purple'
  },
  {
    label: 'Skill Match',
    value: '92%',
    change: '+3%',
    icon: Brain,
    color: 'yellow'
  }
];

export function EmployeeStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat) => (
        <StatCard key={stat.label} {...stat} />
      ))}
    </div>
  );
}