import React from 'react';
import { User, Mail, Building2, Star } from 'lucide-react';
import { Employee } from '../types';

interface EmployeeRowProps {
  employee: Employee;
}

export function EmployeeRow({ employee }: EmployeeRowProps) {
  return (
    <tr className="hover:bg-gray-50">
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <User className="h-10 w-10 rounded-full bg-gray-100 p-2" />
          </div>
          <div className="ml-4">
            <div className="text-sm font-medium text-gray-900">
              {employee.name}
            </div>
            <div className="flex items-center text-sm text-gray-500">
              <Mail className="h-4 w-4 mr-1" />
              {employee.email}
            </div>
          </div>
        </div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="flex items-center text-sm text-gray-900">
          <Building2 className="h-4 w-4 mr-1 text-gray-400" />
          {employee.department}
        </div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
        {employee.position}
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="flex items-center">
          <Star className="h-4 w-4 text-yellow-400 mr-1" />
          <span className="text-sm font-medium text-gray-900">
            {employee.performance}%
          </span>
        </div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
          {employee.status}
        </span>
      </td>
    </tr>
  );
}