import React, { useState } from 'react';
import { FileText, Plus, Settings } from 'lucide-react';

const reportTypes = [
  { id: 'workforce', name: 'Workforce Composition' },
  { id: 'performance', name: 'Performance Analysis' },
  { id: 'recruitment', name: 'Recruitment Metrics' },
  { id: 'training', name: 'Training Impact' }
];

export function CustomReportBuilder() {
  const [selectedType, setSelectedType] = useState('');

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Custom Report</h3>
          <p className="text-sm text-gray-500">Build tailored reports</p>
        </div>
        <Settings className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Report Type
          </label>
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="">Select type</option>
            {reportTypes.map((type) => (
              <option key={type.id} value={type.id}>
                {type.name}
              </option>
            ))}
          </select>
        </div>

        <button className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">
          <Plus className="h-4 w-4 mr-2" />
          Generate Report
        </button>
      </div>
    </div>
  );
}