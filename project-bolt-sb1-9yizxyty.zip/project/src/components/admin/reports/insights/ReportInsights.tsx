import React from 'react';
import { Brain, TrendingUp, AlertTriangle } from 'lucide-react';

const insights = [
  {
    type: 'trend',
    content: 'Employee satisfaction increased by 15% this quarter',
    priority: 'high',
    category: 'Performance'
  },
  {
    type: 'prediction',
    content: 'Potential turnover risk in Engineering department',
    priority: 'medium',
    category: 'Workforce'
  },
  {
    type: 'anomaly',
    content: 'Unusual spike in leave requests for next month',
    priority: 'low',
    category: 'Leave'
  }
];

const priorityStyles = {
  high: 'bg-red-50 border-red-200 text-red-700',
  medium: 'bg-yellow-50 border-yellow-200 text-yellow-700',
  low: 'bg-green-50 border-green-200 text-green-700'
};

export function ReportInsights() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">AI Insights</h3>
          <p className="text-sm text-gray-500">Real-time analytics insights</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {insights.map((insight, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg border ${priorityStyles[insight.priority]}`}
          >
            <div className="flex items-start space-x-3">
              {insight.type === 'trend' ? (
                <TrendingUp className="h-5 w-5 mt-0.5" />
              ) : (
                <AlertTriangle className="h-5 w-5 mt-0.5" />
              )}
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-medium">{insight.category}</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-white bg-opacity-50">
                    {insight.type}
                  </span>
                </div>
                <p className="text-sm mt-1">{insight.content}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}