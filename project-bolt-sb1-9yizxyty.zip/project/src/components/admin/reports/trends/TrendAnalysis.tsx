import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp } from 'lucide-react';

const data = [
  { month: 'Jan', performance: 85, engagement: 78, turnover: 4.2 },
  { month: 'Feb', performance: 88, engagement: 82, turnover: 3.8 },
  { month: 'Mar', performance: 92, engagement: 85, turnover: 3.5 },
  { month: 'Apr', performance: 90, engagement: 88, turnover: 3.2 },
  { month: 'May', performance: 95, engagement: 92, turnover: 2.8 },
  { month: 'Jun', performance: 97, engagement: 94, turnover: 2.5 }
];

export function TrendAnalysis() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Key Metrics Trend</h3>
          <p className="text-sm text-gray-500">Performance and engagement analysis</p>
        </div>
        <TrendingUp className="h-6 w-6 text-blue-500" />
      </div>

      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Line 
              type="monotone" 
              dataKey="performance" 
              stroke="#3B82F6" 
              strokeWidth={2}
              name="Performance"
            />
            <Line 
              type="monotone" 
              dataKey="engagement" 
              stroke="#10B981" 
              strokeWidth={2}
              name="Engagement"
            />
            <Line 
              type="monotone" 
              dataKey="turnover" 
              stroke="#EF4444" 
              strokeWidth={2}
              name="Turnover Rate"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}