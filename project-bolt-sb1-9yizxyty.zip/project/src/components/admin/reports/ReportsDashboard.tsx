import React from 'react';
import { Container } from '../../ui/Container';
import { ReportsOverview } from './overview/ReportsOverview';
import { ReportsList } from './list/ReportsList';
import { ReportInsights } from './insights/ReportInsights';
import { TrendAnalysis } from './trends/TrendAnalysis';
import { CustomReportBuilder } from './builder/CustomReportBuilder';

export function ReportsDashboard() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Advanced Reporting Intelligence</h2>
          <p className="mt-2 text-gray-600">
            AI-powered analytics and insights for data-driven decision making
          </p>
        </div>

        <div className="space-y-8">
          <ReportsOverview />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <ReportsList />
              <TrendAnalysis />
            </div>
            <div className="space-y-8">
              <ReportInsights />
              <CustomReportBuilder />
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}