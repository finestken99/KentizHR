import React from 'react';
import { FileText, Download, Eye, BarChart2, TrendingUp, Users } from 'lucide-react';

const reports = [
  {
    id: 1,
    title: 'Workforce Composition Analysis',
    type: 'Workforce',
    generated: '2024-03-15',
    insights: 12,
    status: 'ready'
  },
  {
    id: 2,
    title: 'Performance Trend Report Q1',
    type: 'Performance',
    generated: '2024-03-14',
    insights: 8,
    status: 'processing'
  },
  {
    id: 3,
    title: 'Recruitment Effectiveness',
    type: 'Recruitment',
    generated: '2024-03-13',
    insights: 15,
    status: 'ready'
  }
];

const typeIcons = {
  Workforce: BarChart2,
  Performance: TrendingUp,
  Recruitment: Users
};

export function ReportsList() {
  return (
    <div className="bg-white rounded-lg shadow-sm">
      <div className="p-6 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-medium text-gray-900">Generated Reports</h3>
          <button className="text-blue-600 hover:text-blue-700 font-medium">
            Generate New Report
          </button>
        </div>
      </div>

      <div className="divide-y divide-gray-200">
        {reports.map((report) => {
          const TypeIcon = typeIcons[report.type];
          return (
            <div key={report.id} className="p-6 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-blue-50 rounded-lg">
                    <TypeIcon className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-900">{report.title}</h4>
                    <div className="mt-1 flex items-center space-x-4">
                      <span className="text-sm text-gray-500">{report.type}</span>
                      <span className="text-sm text-gray-500">Generated: {report.generated}</span>
                      <span className="text-sm text-blue-600">{report.insights} insights</span>
                    </div>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button className="p-2 hover:bg-gray-100 rounded-lg">
                    <Eye className="h-5 w-5 text-gray-400" />
                  </button>
                  <button className="p-2 hover:bg-gray-100 rounded-lg">
                    <Download className="h-5 w-5 text-gray-400" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}