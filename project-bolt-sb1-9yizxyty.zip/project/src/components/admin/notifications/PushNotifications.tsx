import React, { useState } from 'react';
import { Bell, Settings, AlertTriangle } from 'lucide-react';
import { Button } from '../../ui/Button';

interface Notification {
  id: number;
  title: string;
  message: string;
  type: 'task' | 'reminder' | 'alert';
  status: 'pending' | 'sent' | 'failed';
  scheduledFor?: string;
}

export function PushNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: 1,
      title: 'Performance Review Due',
      message: 'Complete your self-assessment by March 31',
      type: 'reminder',
      status: 'pending',
      scheduledFor: '2024-03-24'
    },
    {
      id: 2,
      title: 'Training Completion',
      message: 'Required compliance training due in 3 days',
      type: 'alert',
      status: 'sent'
    },
    {
      id: 3,
      title: 'Team Meeting',
      message: 'Weekly team sync at 10 AM tomorrow',
      type: 'task',
      status: 'pending',
      scheduledFor: '2024-03-19'
    }
  ]);

  const handleSendNotification = async (id: number) => {
    // Simulated API call to send notification
    setNotifications(prev => prev.map(notif => 
      notif.id === id ? { ...notif, status: 'sent' } : notif
    ));
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Push Notifications</h3>
          <p className="text-sm text-gray-500">Manage system notifications</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="secondary">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
          <Button variant="primary">
            <Bell className="h-4 w-4 mr-2" />
            New Notification
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        {notifications.map(notification => (
          <div
            key={notification.id}
            className="border border-gray-200 rounded-lg p-4"
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center space-x-2">
                  {notification.type === 'alert' ? (
                    <AlertTriangle className="h-5 w-5 text-yellow-500" />
                  ) : (
                    <Bell className="h-5 w-5 text-blue-500" />
                  )}
                  <h4 className="text-sm font-medium text-gray-900">
                    {notification.title}
                  </h4>
                </div>
                <p className="text-sm text-gray-600 mt-1 ml-7">
                  {notification.message}
                </p>
                {notification.scheduledFor && (
                  <div className="flex items-center mt-2 ml-7">
                    <Clock className="h-4 w-4 text-gray-400 mr-1" />
                    <span className="text-xs text-gray-500">
                      Scheduled for: {notification.scheduledFor}
                    </span>
                  </div>
                )}
              </div>
              <div className="flex items-center space-x-2">
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  notification.status === 'sent'
                    ? 'bg-green-100 text-green-800'
                    : notification.status === 'failed'
                    ? 'bg-red-100 text-red-800'
                    : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {notification.status.charAt(0).toUpperCase() + notification.status.slice(1)}
                </span>
                {notification.status === 'pending' && (
                  <Button
                    variant="secondary"
                    onClick={() => handleSendNotification(notification.id)}
                  >
                    Send Now
                  </Button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}