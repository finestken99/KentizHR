import React, { useState } from 'react';
import { FileText, Download, Filter, Calendar } from 'lucide-react';
import { Button } from '../../../ui/Button';

interface ReportConfig {
  type: string;
  dateRange: string;
  format: string;
  filters: string[];
}

export function ReportGenerator() {
  const [config, setConfig] = useState<ReportConfig>({
    type: '',
    dateRange: '',
    format: 'pdf',
    filters: []
  });
  const [loading, setLoading] = useState(false);

  const handleGenerateReport = async () => {
    setLoading(true);
    try {
      // API call to generate report would go here
      await new Promise(resolve => setTimeout(resolve, 1500));
      // Handle report download
    } catch (error) {
      console.error('Error generating report:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Report Generator</h3>
          <p className="text-sm text-gray-500">Create custom HR reports</p>
        </div>
        <FileText className="h-6 w-6 text-blue-500" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Report Type
          </label>
          <select
            value={config.type}
            onChange={(e) => setConfig(prev => ({ ...prev, type: e.target.value }))}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="">Select type</option>
            <option value="employee">Employee Report</option>
            <option value="turnover">Turnover Analysis</option>
            <option value="recruitment">Recruitment Metrics</option>
            <option value="training">Training Progress</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Date Range
          </label>
          <select
            value={config.dateRange}
            onChange={(e) => setConfig(prev => ({ ...prev, dateRange: e.target.value }))}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="">Select range</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
            <option value="1y">Last Year</option>
            <option value="custom">Custom Range</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Format
          </label>
          <select
            value={config.format}
            onChange={(e) => setConfig(prev => ({ ...prev, format: e.target.value }))}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="pdf">PDF</option>
            <option value="excel">Excel</option>
            <option value="csv">CSV</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Additional Filters
          </label>
          <button className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
            <Filter className="h-4 w-4 mr-2" />
            Add Filters
          </button>
        </div>
      </div>

      <div className="flex justify-end space-x-4">
        <Button variant="secondary">
          <Calendar className="h-4 w-4 mr-2" />
          Schedule Report
        </Button>
        <Button
          variant="primary"
          onClick={handleGenerateReport}
          disabled={loading || !config.type || !config.dateRange}
        >
          <Download className="h-4 w-4 mr-2" />
          {loading ? 'Generating...' : 'Generate Report'}
        </Button>
      </div>
    </div>
  );
}