import React from 'react';
import { Container } from '../../ui/Container';
import { KPIOverview } from './sections/KPIOverview';
import { EmployeeMetrics } from './sections/EmployeeMetrics';
import { RecruitmentAnalytics } from './sections/RecruitmentAnalytics';
import { EngagementScores } from './sections/EngagementScores';
import { TurnoverAnalysis } from './sections/TurnoverAnalysis';
import { TrainingProgress } from './sections/TrainingProgress';
import { ReportGenerator } from './sections/ReportGenerator';

export function HRDashboard() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">HR Analytics Dashboard</h2>
          <p className="mt-2 text-gray-600">
            Real-time insights and key performance indicators
          </p>
        </div>

        <div className="space-y-8">
          <KPIOverview />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <EmployeeMetrics />
            <RecruitmentAnalytics />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <EngagementScores />
            <TurnoverAnalysis />
            <TrainingProgress />
          </div>

          <ReportGenerator />
        </div>
      </Container>
    </div>
  );
}