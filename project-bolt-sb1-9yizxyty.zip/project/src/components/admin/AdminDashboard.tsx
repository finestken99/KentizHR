import React from 'react';
import { AdminHeader } from './AdminHeader';
import { AdminSidebar } from './AdminSidebar';
import { AdminOverview } from './overview/AdminOverview';
import { EmployeesPage } from './employees/EmployeesPage';
import { LeaveManagement } from './leave/LeaveManagement';
import { PerformanceManagement } from './performance/PerformanceManagement';
import { DocumentManagement } from './documents/DocumentManagement';
import { AnalyticsReporting } from './analytics/AnalyticsReporting';
import { QueriesDashboard } from '../queries/QueriesDashboard';
import { SettingsDashboard } from './settings/SettingsDashboard';
import { useHash } from '../../hooks/useHash';

export function AdminDashboard() {
  const hash = useHash();
  const section = hash.split('/')[1] || 'overview';

  const renderContent = () => {
    switch (section) {
      case 'employees':
        return <EmployeesPage />;
      case 'leave':
        return <LeaveManagement />;
      case 'performance':
        return <PerformanceManagement />;
      case 'documents':
        return <DocumentManagement />;
      case 'analytics':
        return <AnalyticsReporting />;
      case 'queries':
        return <QueriesDashboard />;
      case 'settings':
        return <SettingsDashboard />;
      default:
        return <AdminOverview />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <AdminHeader />
      <div className="flex">
        <AdminSidebar />
        <main className="flex-1 overflow-auto">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}