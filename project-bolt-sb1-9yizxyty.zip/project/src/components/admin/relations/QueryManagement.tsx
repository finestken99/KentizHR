import React from 'react';
import { MessageSquare, AlertTriangle, Clock, CheckCircle } from 'lucide-react';

const queries = [
  {
    id: 1,
    title: 'Benefits Package Inquiry',
    employee: 'John Smith',
    department: 'Engineering',
    priority: 'medium',
    status: 'open',
    timestamp: '2h ago'
  },
  {
    id: 2,
    title: 'Work From Home Policy',
    employee: 'Sarah Johnson',
    department: 'Marketing',
    priority: 'high',
    status: 'in_progress',
    timestamp: '4h ago'
  },
  {
    id: 3,
    title: 'Training Program Access',
    employee: 'Mike Wilson',
    department: 'Sales',
    priority: 'low',
    status: 'resolved',
    timestamp: '1d ago'
  }
];

const priorityConfig = {
  high: { className: 'bg-red-100 text-red-800' },
  medium: { className: 'bg-yellow-100 text-yellow-800' },
  low: { className: 'bg-green-100 text-green-800' }
};

const statusConfig = {
  open: { icon: MessageSquare, className: 'text-blue-600' },
  in_progress: { icon: Clock, className: 'text-yellow-600' },
  resolved: { icon: CheckCircle, className: 'text-green-600' }
};

export function QueryManagement() {
  return (
    <div className="bg-white shadow rounded-lg">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-medium text-gray-900">Active Queries</h3>
          <button className="text-blue-600 hover:text-blue-700 font-medium">
            View All
          </button>
        </div>

        <div className="space-y-4">
          {queries.map((query) => {
            const StatusIcon = statusConfig[query.status].icon;
            return (
              <div
                key={query.id}
                className="border border-gray-200 rounded-lg p-4"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-base font-medium text-gray-900">
                      {query.title}
                    </h4>
                    <p className="mt-1 text-sm text-gray-500">
                      {query.employee} · {query.department}
                    </p>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    priorityConfig[query.priority].className
                  }`}>
                    {query.priority.charAt(0).toUpperCase() + query.priority.slice(1)}
                  </span>
                </div>
                <div className="mt-4 flex justify-between items-center text-sm">
                  <div className="flex items-center text-gray-500">
                    <StatusIcon className={`h-4 w-4 ${statusConfig[query.status].className} mr-1`} />
                    <span className="capitalize">{query.status.replace('_', ' ')}</span>
                  </div>
                  <span className="text-gray-500">{query.timestamp}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}