import React from 'react';
import { RelationsOverview } from './RelationsOverview';
import { QueryManagement } from './QueryManagement';
import { FeedbackAnalytics } from './FeedbackAnalytics';
import { CaseHistory } from './CaseHistory';

export function EmployeeRelations() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Employee Relations</h2>
        <p className="mt-1 text-sm text-gray-500">
          Manage employee queries, feedback, and relations
        </p>
      </div>

      <RelationsOverview />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <QueryManagement />
        <FeedbackAnalytics />
      </div>

      <CaseHistory />
    </div>
  );
}