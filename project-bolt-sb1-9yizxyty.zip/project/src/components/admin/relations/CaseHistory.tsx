import React from 'react';
import { Search, Filter, AlertTriangle, CheckCircle, Clock } from 'lucide-react';

const cases = [
  {
    id: 1,
    title: 'Workplace Accommodation Request',
    employee: 'Emma Thompson',
    type: 'accommodation',
    status: 'resolved',
    priority: 'high',
    openDate: '2024-02-15',
    resolvedDate: '2024-02-20'
  },
  {
    id: 2,
    title: 'Performance Improvement Plan Discussion',
    employee: 'James Wilson',
    type: 'performance',
    status: 'in_progress',
    priority: 'medium',
    openDate: '2024-03-01',
    resolvedDate: null
  },
  {
    id: 3,
    title: 'Remote Work Policy Clarification',
    employee: 'Lisa Chen',
    type: 'policy',
    status: 'open',
    priority: 'low',
    openDate: '2024-03-10',
    resolvedDate: null
  }
];

const statusIcons = {
  open: Clock,
  in_progress: AlertTriangle,
  resolved: CheckCircle
};

const statusColors = {
  open: 'text-yellow-600',
  in_progress: 'text-blue-600',
  resolved: 'text-green-600'
};

export function CaseHistory() {
  return (
    <div className="bg-white shadow rounded-lg">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-medium text-gray-900">Case History</h3>
          <div className="flex gap-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search cases..."
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
            <button className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50">
              <Filter className="h-5 w-5 text-gray-400" />
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Case Details
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Priority
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Dates
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {cases.map((case_) => {
                const StatusIcon = statusIcons[case_.status];
                return (
                  <tr key={case_.id}>
                    <td className="px-6 py-4">
                      <div className="text-sm font-medium text-gray-900">
                        {case_.title}
                      </div>
                      <div className="text-sm text-gray-500">
                        {case_.employee}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-sm text-gray-900 capitalize">
                        {case_.type}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <StatusIcon className={`h-5 w-5 ${statusColors[case_.status]} mr-2`} />
                        <span className="text-sm text-gray-900 capitalize">
                          {case_.status.replace('_', ' ')}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        case_.priority === 'high'
                          ? 'bg-red-100 text-red-800'
                          : case_.priority === 'medium'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-green-100 text-green-800'
                      }`}>
                        {case_.priority.charAt(0).toUpperCase() + case_.priority.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div>Opened: {case_.openDate}</div>
                      {case_.resolvedDate && (
                        <div>Resolved: {case_.resolvedDate}</div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}