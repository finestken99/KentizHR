import React from 'react';
import { Brain, TrendingUp, AlertTriangle } from 'lucide-react';

const insights = [
  {
    type: 'trend',
    content: 'Document compliance rate increased by 8% this month',
    icon: TrendingUp,
    color: 'text-green-500',
    bgColor: 'bg-green-50'
  },
  {
    type: 'risk',
    content: '3 documents require immediate review for compliance',
    icon: AlertTriangle,
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-50'
  },
  {
    type: 'recommendation',
    content: 'Consider updating privacy policy based on new regulations',
    icon: Brain,
    color: 'text-blue-500',
    bgColor: 'bg-blue-50'
  }
];

export function DocumentInsights() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900">AI Insights</h3>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {insights.map((insight, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg ${insight.bgColor}`}
          >
            <div className="flex items-start space-x-3">
              <insight.icon className={`h-5 w-5 ${insight.color} mt-0.5`} />
              <div>
                <p className="text-sm text-gray-900">{insight.content}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}