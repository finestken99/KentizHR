import React from 'react';
import { FileText, Download, Share2, MoreVertical, Shield, AlertTriangle } from 'lucide-react';

const documents = [
  {
    title: 'Employee Handbook 2024',
    type: 'PDF',
    size: '2.4 MB',
    modified: '2024-03-15',
    status: 'compliant',
    category: 'Policy',
    tags: ['HR', 'Guidelines']
  },
  {
    title: 'Benefits Documentation',
    type: 'DOCX',
    size: '1.8 MB',
    modified: '2024-03-14',
    status: 'review_needed',
    category: 'Benefits',
    tags: ['HR', 'Healthcare']
  },
  {
    title: 'Compliance Report Q1',
    type: 'PDF',
    size: '3.2 MB',
    modified: '2024-03-13',
    status: 'flagged',
    category: 'Compliance',
    tags: ['Legal', 'Quarterly']
  }
];

const statusConfig = {
  compliant: { icon: Shield, className: 'text-green-500' },
  review_needed: { icon: AlertTriangle, className: 'text-yellow-500' },
  flagged: { icon: AlertTriangle, className: 'text-red-500' }
};

export function DocumentGrid() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {documents.map((doc) => {
        const StatusIcon = statusConfig[doc.status].icon;
        return (
          <div
            key={doc.title}
            className="bg-white rounded-lg shadow-sm p-4 border border-gray-200 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <FileText className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-900">{doc.title}</h3>
                  <p className="text-xs text-gray-500">
                    {doc.type} • {doc.size}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <StatusIcon className={`h-5 w-5 ${statusConfig[doc.status].className}`} />
                <button className="p-1 hover:bg-gray-100 rounded">
                  <MoreVertical className="h-4 w-4 text-gray-400" />
                </button>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between">
              <div className="flex flex-wrap gap-2">
                {doc.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs"
                  >
                    {tag}
                  </span>
                ))}
              </div>
              <div className="flex space-x-2">
                <button className="p-1 hover:bg-gray-100 rounded">
                  <Share2 className="h-4 w-4 text-gray-400" />
                </button>
                <button className="p-1 hover:bg-gray-100 rounded">
                  <Download className="h-4 w-4 text-gray-400" />
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}