import React from 'react';
import { FileText, Download, Trash2, CheckCircle, Clock, AlertCircle } from 'lucide-react';

const documents = [
  {
    id: 1,
    name: 'Employee Handbook 2024',
    type: 'Policy',
    status: 'active',
    updatedAt: '2024-03-01',
    size: '2.4 MB'
  },
  {
    id: 2,
    name: 'Health & Safety Guidelines',
    type: 'Compliance',
    status: 'pending',
    updatedAt: '2024-03-10',
    size: '1.8 MB'
  },
  {
    id: 3,
    name: 'Remote Work Policy',
    type: 'Policy',
    status: 'review',
    updatedAt: '2024-03-12',
    size: '1.2 MB'
  }
];

const statusIcons = {
  active: { icon: CheckCircle, className: 'text-green-500' },
  pending: { icon: Clock, className: 'text-yellow-500' },
  review: { icon: AlertCircle, className: 'text-red-500' }
};

export function DocumentList() {
  return (
    <div className="bg-white shadow-sm rounded-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Document
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Type
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Last Updated
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Size
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {documents.map((doc) => {
              const StatusIcon = statusIcons[doc.status].icon;
              return (
                <tr key={doc.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <FileText className="h-5 w-5 text-gray-400 mr-3" />
                      <span className="text-sm font-medium text-gray-900">{doc.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-500">{doc.type}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <StatusIcon className={`h-5 w-5 ${statusIcons[doc.status].className} mr-2`} />
                      <span className="text-sm text-gray-500 capitalize">{doc.status}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {doc.updatedAt}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {doc.size}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end space-x-3">
                      <button className="text-blue-600 hover:text-blue-900">
                        <Download className="h-5 w-5" />
                      </button>
                      <button className="text-red-600 hover:text-red-900">
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}