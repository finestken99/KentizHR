import React from 'react';
import { Shield, AlertTriangle, CheckCircle } from 'lucide-react';

const complianceItems = [
  {
    title: 'Data Protection',
    status: 'compliant',
    lastCheck: '2024-03-15',
    icon: Shield,
    color: 'text-green-500'
  },
  {
    title: 'Document Retention',
    status: 'warning',
    lastCheck: '2024-03-14',
    icon: AlertTriangle,
    color: 'text-yellow-500'
  },
  {
    title: 'Access Controls',
    status: 'compliant',
    lastCheck: '2024-03-13',
    icon: CheckCircle,
    color: 'text-green-500'
  }
];

export function ComplianceOverview() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Compliance Status</h3>
      <div className="space-y-4">
        {complianceItems.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.title}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center space-x-3">
                <Icon className={`h-5 w-5 ${item.color}`} />
                <div>
                  <p className="text-sm font-medium text-gray-900">{item.title}</p>
                  <p className="text-xs text-gray-500">Last checked: {item.lastCheck}</p>
                </div>
              </div>
              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                item.status === 'compliant' 
                  ? 'bg-green-100 text-green-800'
                  : 'bg-yellow-100 text-yellow-800'
              }`}>
                {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}