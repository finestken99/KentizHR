import React from 'react';
import { Container } from '../../ui/Container';
import { DocumentStats } from './stats/DocumentStats';
import { DocumentUpload } from './upload/DocumentUpload';
import { DocumentSearch } from './search/DocumentSearch';
import { DocumentGrid } from './grid/DocumentGrid';
import { ComplianceOverview } from './compliance/ComplianceOverview';
import { DocumentInsights } from './insights/DocumentInsights';

export function AdminDocuments() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Document Intelligence</h2>
          <p className="mt-2 text-gray-600">
            AI-powered document management and compliance monitoring
          </p>
        </div>

        <div className="space-y-8">
          <DocumentStats />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <DocumentSearch />
              <DocumentGrid />
            </div>
            <div className="space-y-8">
              <DocumentUpload />
              <ComplianceOverview />
              <DocumentInsights />
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}