import React, { useState, useEffect } from 'react';
import { subscriptionService } from '../../lib/services/subscriptionService';
import { PlanSelector } from './PlanSelector';
import { PlanComparison } from './PlanComparison';
import { useUser } from '../../contexts/UserContext';
import type { SubscriptionPlan, Feature } from '../../lib/db/models/types/subscription';

export function SubscriptionManager() {
  const { user } = useUser();
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [features, setFeatures] = useState<Feature[]>([]);
  const [currentPlan, setCurrentPlan] = useState<SubscriptionPlan | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'cards' | 'comparison'>('cards');

  useEffect(() => {
    const loadData = async () => {
      try {
        const [availablePlans, allFeatures] = await Promise.all([
          subscriptionService.getAvailablePlans(),
          subscriptionService.getAllFeatures()
        ]);
        
        setPlans(availablePlans);
        setFeatures(allFeatures);

        if (user?.id) {
          const current = await subscriptionService.getCurrentPlan(user.id);
          if (current) {
            setCurrentPlan(current.plan);
          }
        }
      } catch (error) {
        console.error('Error loading subscription data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [user?.id]);

  const handlePlanChange = async (planId: number) => {
    if (!user?.id) {
      window.location.hash = '#login';
      return;
    }

    try {
      setLoading(true);
      const success = await subscriptionService.upgradePlan(user.id, planId);
      
      if (success) {
        const newPlan = plans.find(p => p.id === planId);
        setCurrentPlan(newPlan || null);
      }
    } catch (error) {
      console.error('Error changing plan:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[200px]">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-end space-x-4">
        <button
          onClick={() => setView('cards')}
          className={`px-4 py-2 rounded-lg ${
            view === 'cards' 
              ? 'bg-blue-100 text-blue-600' 
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          Card View
        </button>
        <button
          onClick={() => setView('comparison')}
          className={`px-4 py-2 rounded-lg ${
            view === 'comparison'
              ? 'bg-blue-100 text-blue-600'
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          Compare Plans
        </button>
      </div>

      {view === 'cards' ? (
        <PlanSelector
          plans={plans}
          currentPlanId={currentPlan?.id}
          onSelectPlan={handlePlanChange}
        />
      ) : (
        <PlanComparison
          plans={plans}
          features={features}
          currentPlanId={currentPlan?.id}
          onSelectPlan={handlePlanChange}
        />
      )}
    </div>
  );
}