import React from 'react';
import { Check, X } from 'lucide-react';
import type { SubscriptionPlan, Feature } from '../../lib/db/models/types/subscription';

interface PlanComparisonProps {
  plans: SubscriptionPlan[];
  features: Feature[];
  currentPlanId?: number;
  onSelectPlan: (planId: number) => void;
}

export function PlanComparison({ plans, features, currentPlanId, onSelectPlan }: PlanComparisonProps) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-t border-gray-200">
            <th className="py-5 px-4 text-left text-sm font-medium text-gray-500">Features</th>
            {plans.map((plan) => (
              <th key={plan.id} className="py-5 px-4 text-center">
                <div className="text-sm font-medium text-gray-900">{plan.name}</div>
                <div className="mt-1 text-2xl font-bold text-gray-900">${plan.price}</div>
                <div className="mt-1 text-sm text-gray-500">per month</div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="border-t border-gray-200 divide-y divide-gray-200">
          {features.map((feature) => (
            <tr key={feature.id}>
              <td className="py-5 px-4 text-sm text-gray-500">{feature.name}</td>
              {plans.map((plan) => (
                <td key={plan.id} className="py-5 px-4 text-center">
                  {/* In a real app, you'd check if the feature is included in the plan */}
                  {Math.random() > 0.3 ? (
                    <Check className="h-5 w-5 text-green-500 mx-auto" />
                  ) : (
                    <X className="h-5 w-5 text-gray-300 mx-auto" />
                  )}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}