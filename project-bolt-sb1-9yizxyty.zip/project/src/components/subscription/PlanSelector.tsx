import React from 'react';
import { Check, X } from 'lucide-react';
import { Button } from '../ui/Button';
import type { SubscriptionPlan } from '../../lib/db/models/types/subscription';

interface PlanSelectorProps {
  plans: SubscriptionPlan[];
  currentPlanId?: number;
  onSelectPlan: (planId: number) => void;
}

export function PlanSelector({ plans, currentPlanId, onSelectPlan }: PlanSelectorProps) {
  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
      {plans.map((plan) => (
        <div
          key={plan.id}
          className={`bg-white rounded-lg shadow-sm p-6 border-2 ${
            currentPlanId === plan.id ? 'border-blue-500' : 'border-gray-200'
          }`}
        >
          <div className="text-center mb-6">
            <h3 className="text-2xl font-bold text-gray-900">{plan.name}</h3>
            <div className="mt-4">
              <span className="text-4xl font-bold">${plan.price}</span>
              <span className="text-gray-500">/{plan.billing_cycle}</span>
            </div>
            <p className="mt-2 text-sm text-gray-600">{plan.description}</p>
          </div>

          <div className="space-y-4 mb-6">
            <div className="flex items-center">
              <Check className="h-5 w-5 text-green-500 mr-2" />
              <span>Up to {plan.max_employees} employees</span>
            </div>
            {/* Add more features here */}
          </div>

          <Button
            variant={currentPlanId === plan.id ? 'secondary' : 'primary'}
            className="w-full"
            onClick={() => onSelectPlan(plan.id!)}
          >
            {currentPlanId === plan.id ? 'Current Plan' : 'Upgrade'}
          </Button>
        </div>
      ))}
    </div>
  );
}