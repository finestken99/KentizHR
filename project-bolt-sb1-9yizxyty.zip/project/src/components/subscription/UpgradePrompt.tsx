import React from 'react';
import { Lock } from 'lucide-react';
import { Button } from '../ui/Button';

interface UpgradePromptProps {
  feature: string;
  requiredPlan: string;
}

export function UpgradePrompt({ feature, requiredPlan }: UpgradePromptProps) {
  return (
    <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 text-center">
      <Lock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
      <h3 className="text-lg font-medium text-gray-900 mb-2">
        Upgrade Required
      </h3>
      <p className="text-gray-600 mb-4">
        {feature} is available in the {requiredPlan} plan and above
      </p>
      <Button
        variant="primary"
        onClick={() => window.location.hash = '#subscription'}
      >
        Upgrade Now
      </Button>
    </div>
  );
}