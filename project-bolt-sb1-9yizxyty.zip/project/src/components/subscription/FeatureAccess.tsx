import React from 'react';
import { Lock } from 'lucide-react';
import { Button } from '../ui/Button';
import { useSubscription } from '../../hooks/useSubscription';

interface FeatureAccessProps {
  featureName: string;
  children: React.ReactNode;
}

export function FeatureAccess({ featureName, children }: FeatureAccessProps) {
  const { hasAccess, currentPlan } = useSubscription(featureName);

  if (hasAccess) {
    return <>{children}</>;
  }

  return (
    <div className="relative">
      <div className="absolute inset-0 bg-gray-100 bg-opacity-75 flex items-center justify-center backdrop-blur-sm rounded-lg">
        <div className="text-center p-6">
          <Lock className="h-8 w-8 text-gray-400 mx-auto mb-2" />
          <p className="text-sm text-gray-600 mb-4">
            This feature is only available in the {currentPlan?.name} plan and above
          </p>
          <Button variant="primary" onClick={() => window.location.hash = '#subscription'}>
            Upgrade Plan
          </Button>
        </div>
      </div>
      <div className="opacity-50 pointer-events-none">
        {children}
      </div>
    </div>
  );
}