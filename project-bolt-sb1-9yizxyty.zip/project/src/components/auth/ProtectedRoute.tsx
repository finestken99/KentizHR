import React from 'react';
import { useAuth } from '../../hooks/useAuth';
import { UserRole } from '../../lib/auth/types';

interface ProtectedRouteProps {
  children: React.ReactNode;
  roles?: UserRole[];
}

export function ProtectedRoute({ children, roles = [] }: ProtectedRouteProps) {
  const { user, loading, error } = useAuth(roles);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error || !user) {
    window.location.hash = '#login';
    return null;
  }

  return <>{children}</>;
}