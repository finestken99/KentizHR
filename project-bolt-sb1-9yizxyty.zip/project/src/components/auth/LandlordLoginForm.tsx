import React, { useState } from 'react';
import { Mail, Lock } from 'lucide-react';
import { Button } from '../ui/Button';
import { FormField } from '../ui/FormField';
import { browserDb } from '../../lib/db/browserDb';
import { useUser } from '../../contexts/UserContext';

export function LandlordLoginForm() {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { setUser } = useUser();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const result = await browserDb.login(formData.email, formData.password);
      if (result && result.user.role === 'landlord') {
        localStorage.setItem('auth_token', result.token);
        setUser(result.user);
        window.location.hash = '#tenants';
      } else {
        setError('Invalid landlord credentials');
      }
    } catch (err) {
      setError('An error occurred during login');
      console.error('Login error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
          {error}
        </div>
      )}

      <FormField
        label="Email Address"
        name="email"
        type="email"
        value={formData.email}
        onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
        icon={Mail}
        required
        disabled={loading}
      />

      <FormField
        label="Password"
        name="password"
        type="password"
        value={formData.password}
        onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
        icon={Lock}
        required
        disabled={loading}
      />

      <Button
        variant="primary"
        className="w-full"
        type="submit"
        disabled={loading}
      >
        {loading ? 'Signing in...' : 'Sign in'}
      </Button>
    </form>
  );
}