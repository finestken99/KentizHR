import React from 'react';
import { LandlordLoginForm } from './LandlordLoginForm';
import { Shield } from 'lucide-react';

export function LandlordLoginPage() {
  return (
    <div className="min-h-screen bg-gray-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <div className="p-2 bg-blue-600 rounded-lg">
            <Shield className="h-12 w-12 text-white" />
          </div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-white">
          Landlord Portal
        </h2>
        <p className="mt-2 text-center text-sm text-gray-400">
          Secure access for property management
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <LandlordLoginForm />
        </div>
      </div>
    </div>
  );
}