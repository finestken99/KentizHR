import React from 'react';
import { MapPin, Clock, Building } from 'lucide-react';
import { FormField } from '../../../ui/FormField';

interface CompanyDetailsProps {
  data: {
    address: string;
    workingHours: string;
    departments: string[];
  };
  onChange: (field: string, value: string | string[]) => void;
  errors?: Record<string, string>;
}

export function CompanyDetails({ data, onChange, errors }: CompanyDetailsProps) {
  return (
    <div className="space-y-6">
      <FormField
        label="Company Address"
        name="address"
        value={data.address}
        onChange={(e) => onChange('address', e.target.value)}
        error={errors?.address}
        icon={MapPin}
        required
      />

      <FormField
        label="Working Hours"
        name="workingHours"
        type="select"
        value={data.workingHours}
        onChange={(e) => onChange('workingHours', e.target.value)}
        error={errors?.workingHours}
        icon={Clock}
        required
        options={[
          { value: '9-5', label: '9:00 AM - 5:00 PM' },
          { value: '8-4', label: '8:00 AM - 4:00 PM' },
          { value: '10-6', label: '10:00 AM - 6:00 PM' },
          { value: 'flexible', label: 'Flexible Hours' }
        ]}
      />

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Departments
        </label>
        <div className="space-y-2">
          {['HR', 'Engineering', 'Sales', 'Marketing', 'Finance', 'Operations'].map((dept) => (
            <label key={dept} className="flex items-center">
              <input
                type="checkbox"
                checked={data.departments.includes(dept)}
                onChange={(e) => {
                  const newDepts = e.target.checked
                    ? [...data.departments, dept]
                    : data.departments.filter(d => d !== dept);
                  onChange('departments', newDepts);
                }}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <span className="ml-2 text-sm text-gray-600">{dept}</span>
            </label>
          ))}
        </div>
        {errors?.departments && (
          <p className="mt-1 text-sm text-red-600">{errors.departments}</p>
        )}
      </div>
    </div>
  );
}