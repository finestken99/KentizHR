import React from 'react';
import { Mail, Lock, User } from 'lucide-react';
import { FormField } from '../../../ui/FormField';

interface AdminAccountProps {
  data: {
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    confirmPassword: string;
  };
  onChange: (field: string, value: string) => void;
  errors?: Record<string, string>;
}

export function AdminAccount({ data, onChange, errors }: AdminAccountProps) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <FormField
          label="First Name"
          name="firstName"
          value={data.firstName}
          onChange={(e) => onChange('firstName', e.target.value)}
          error={errors?.firstName}
          icon={User}
          required
        />

        <FormField
          label="Last Name"
          name="lastName"
          value={data.lastName}
          onChange={(e) => onChange('lastName', e.target.value)}
          error={errors?.lastName}
          icon={User}
          required
        />
      </div>

      <FormField
        label="Email Address"
        name="email"
        type="email"
        value={data.email}
        onChange={(e) => onChange('email', e.target.value)}
        error={errors?.email}
        icon={Mail}
        required
      />

      <FormField
        label="Password"
        name="password"
        type="password"
        value={data.password}
        onChange={(e) => onChange('password', e.target.value)}
        error={errors?.password}
        icon={Lock}
        required
      />

      <FormField
        label="Confirm Password"
        name="confirmPassword"
        type="password"
        value={data.confirmPassword}
        onChange={(e) => onChange('confirmPassword', e.target.value)}
        error={errors?.confirmPassword}
        icon={Lock}
        required
      />
    </div>
  );
}