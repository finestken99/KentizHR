import React from 'react';
import { Building2, Users, Briefcase } from 'lucide-react';
import { FormField } from '../../../ui/FormField';

interface BasicInfoProps {
  data: {
    companyName: string;
    industry: string;
    size: string;
  };
  onChange: (field: string, value: string) => void;
  errors?: Record<string, string>;
}

export function BasicInfo({ data, onChange, errors }: BasicInfoProps) {
  return (
    <div className="space-y-6">
      <FormField
        label="Company Name"
        name="companyName"
        value={data.companyName}
        onChange={(e) => onChange('companyName', e.target.value)}
        error={errors?.companyName}
        icon={Building2}
        required
      />

      <FormField
        label="Industry"
        name="industry"
        value={data.industry}
        onChange={(e) => onChange('industry', e.target.value)}
        error={errors?.industry}
        icon={Briefcase}
        required
      />

      <FormField
        label="Company Size"
        name="size"
        type="select"
        value={data.size}
        onChange={(e) => onChange('size', e.target.value)}
        error={errors?.size}
        icon={Users}
        required
        options={[
          { value: '1-10', label: '1-10 employees' },
          { value: '11-50', label: '11-50 employees' },
          { value: '51-200', label: '51-200 employees' },
          { value: '201-500', label: '201-500 employees' },
          { value: '501+', label: '501+ employees' }
        ]}
      />
    </div>
  );
}