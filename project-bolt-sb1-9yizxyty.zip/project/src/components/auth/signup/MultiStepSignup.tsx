import React, { useState } from 'react';
import { BasicInfo } from './steps/BasicInfo';
import { AdminAccount } from './steps/AdminAccount';
import { CompanyDetails } from './steps/CompanyDetails';
import { Button } from '../../ui/Button';
import { useFormValidation } from '../../../hooks/useFormValidation';
import { signupSchema } from '../../../lib/validation/forms';
import { authService } from '../../../lib/services/authService';
import { useUser } from '../../../contexts/UserContext';

const steps = ['Basic Info', 'Admin Account', 'Company Details'];

export function MultiStepSignup() {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    companyName: '',
    industry: '',
    size: '',
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    address: '',
    workingHours: '',
    departments: [] as string[]
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { setUser } = useUser();
  const { validationState, validateForm } = useFormValidation(signupSchema);

  const handleChange = (field: string, value: string | string[]) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError(null);
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!validateForm(formData)) {
      return;
    }

    setLoading(true);
    try {
      const result = await authService.register({
        email: formData.email,
        password: formData.password,
        firstName: formData.firstName,
        lastName: formData.lastName,
        company: formData.companyName
      });

      localStorage.setItem('auth_token', result.token);
      setUser(result.user);
      window.location.hash = '#dashboard';
    } catch (err: any) {
      setError(err.message || 'An error occurred during registration');
    } finally {
      setLoading(false);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <BasicInfo
            data={{
              companyName: formData.companyName,
              industry: formData.industry,
              size: formData.size
            }}
            onChange={handleChange}
            errors={validationState}
          />
        );
      case 1:
        return (
          <AdminAccount
            data={{
              firstName: formData.firstName,
              lastName: formData.lastName,
              email: formData.email,
              password: formData.password,
              confirmPassword: formData.confirmPassword
            }}
            onChange={handleChange}
            errors={validationState}
          />
        );
      case 2:
        return (
          <CompanyDetails
            data={{
              address: formData.address,
              workingHours: formData.workingHours,
              departments: formData.departments
            }}
            onChange={handleChange}
            errors={validationState}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      {error && (
        <div className="mb-6 bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
          {error}
        </div>
      )}

      <div className="mb-8">
        <div className="flex items-center justify-between">
          {steps.map((step, index) => (
            <React.Fragment key={step}>
              <div className="flex items-center">
                <div className={`
                  w-8 h-8 rounded-full flex items-center justify-center
                  ${index <= currentStep ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'}
                `}>
                  {index + 1}
                </div>
                <span className="ml-2 text-sm font-medium text-gray-900">{step}</span>
              </div>
              {index < steps.length - 1 && (
                <div className="flex-1 h-0.5 mx-4 bg-gray-200" />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {renderStep()}

        <div className="flex justify-between pt-6">
          {currentStep > 0 && (
            <Button
              variant="secondary"
              onClick={handleBack}
              disabled={loading}
            >
              Back
            </Button>
          )}
          <div className="ml-auto">
            {currentStep < steps.length - 1 ? (
              <Button
                variant="primary"
                onClick={handleNext}
                disabled={loading}
              >
                Next
              </Button>
            ) : (
              <Button
                variant="primary"
                type="submit"
                disabled={loading}
              >
                {loading ? 'Creating Account...' : 'Complete Setup'}
              </Button>
            )}
          </div>
        </div>
      </form>
    </div>
  );
}