import React from 'react';
import { Check } from 'lucide-react';
import type { SubscriptionPlan } from '../../../lib/db/models/types/subscription';

interface PlanSummaryProps {
  plan: SubscriptionPlan;
}

export function PlanSummary({ plan }: PlanSummaryProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6 border-2 border-blue-500">
      <div className="text-center mb-6">
        <h3 className="text-2xl font-bold text-gray-900">{plan.name} Plan</h3>
        <div className="mt-4">
          <span className="text-4xl font-bold">${plan.price}</span>
          <span className="text-gray-500">/{plan.billing_cycle}</span>
        </div>
        <p className="mt-2 text-sm text-gray-600">{plan.description}</p>
      </div>

      <div className="space-y-4">
        <div className="flex items-center">
          <Check className="h-5 w-5 text-green-500 mr-2" />
          <span>Up to {plan.max_employees} employees</span>
        </div>
        {/* Add more plan features here */}
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <h4 className="text-sm font-medium text-gray-900 mb-2">What's included:</h4>
        <ul className="space-y-2">
          <li className="flex items-center text-sm text-gray-600">
            <Check className="h-4 w-4 text-blue-500 mr-2" />
            Core HR management features
          </li>
          <li className="flex items-center text-sm text-gray-600">
            <Check className="h-4 w-4 text-blue-500 mr-2" />
            Employee self-service portal
          </li>
          <li className="flex items-center text-sm text-gray-600">
            <Check className="h-4 w-4 text-blue-500 mr-2" />
            Basic reporting and analytics
          </li>
        </ul>
      </div>
    </div>
  );
}