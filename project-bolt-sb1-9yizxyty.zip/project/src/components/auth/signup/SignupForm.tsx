import React, { useState } from 'react';
import { Mail, Lock, Building2, User } from 'lucide-react';
import { Button } from '../../ui/Button';
import { FormField } from '../../ui/FormField';
import { useFormValidation } from '../../../hooks/useFormValidation';
import { registerSchema } from '../../../lib/validation/forms';
import { browserDb } from '../../../lib/db/browserDb';
import { useUser } from '../../../contexts/UserContext';
import { subscriptionService } from '../../../lib/services/subscriptionService';
import type { SubscriptionPlan } from '../../../lib/db/models/types/subscription';

interface SignupFormProps {
  selectedPlan: SubscriptionPlan | null;
}

interface FormData {
  email: string;
  password: string;
  confirmPassword: string;
  firstName: string;
  lastName: string;
  company: string;
}

const initialFormData: FormData = {
  email: '',
  password: '',
  confirmPassword: '',
  firstName: '',
  lastName: '',
  company: ''
};

export function SignupForm({ selectedPlan }: SignupFormProps) {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { setUser } = useUser();
  const { validationState, validateForm } = useFormValidation(registerSchema);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!validateForm(formData)) {
      return;
    }

    setLoading(true);
    try {
      // Register user
      const result = await browserDb.register({
        email: formData.email,
        password: formData.password,
        first_name: formData.firstName,
        last_name: formData.lastName,
        company: formData.company
      });

      if (!result) {
        throw new Error('Registration failed');
      }

      // Log the user in
      const loginResult = await browserDb.login(formData.email, formData.password);
      if (!loginResult) {
        throw new Error('Auto-login failed');
      }

      localStorage.setItem('auth_token', loginResult.token);
      setUser(loginResult.user);

      // Handle subscription if a plan was selected
      if (selectedPlan && loginResult.user.id) {
        await subscriptionService.upgradePlan(loginResult.user.id, selectedPlan.id!);
        window.location.hash = '#subscription';
      } else {
        window.location.hash = loginResult.user.role === 'admin' ? '#admin-dashboard' : '#dashboard';
      }
    } catch (err: any) {
      console.error('Registration error:', err);
      setError(err.message || 'An error occurred during registration');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
          {error}
        </div>
      )}

      <div className="grid grid-cols-2 gap-4">
        <FormField
          label="First Name"
          name="firstName"
          value={formData.firstName}
          onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
          error={validationState.firstName?.error}
          icon={User}
          required
          disabled={loading}
        />

        <FormField
          label="Last Name"
          name="lastName"
          value={formData.lastName}
          onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
          error={validationState.lastName?.error}
          icon={User}
          required
          disabled={loading}
        />
      </div>

      <FormField
        label="Company Name"
        name="company"
        value={formData.company}
        onChange={(e) => setFormData(prev => ({ ...prev, company: e.target.value }))}
        error={validationState.company?.error}
        icon={Building2}
        required
        disabled={loading}
      />

      <FormField
        label="Email Address"
        name="email"
        type="email"
        value={formData.email}
        onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
        error={validationState.email?.error}
        icon={Mail}
        required
        disabled={loading}
      />

      <FormField
        label="Password"
        name="password"
        type="password"
        value={formData.password}
        onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
        error={validationState.password?.error}
        icon={Lock}
        required
        disabled={loading}
      />

      <FormField
        label="Confirm Password"
        name="confirmPassword"
        type="password"
        value={formData.confirmPassword}
        onChange={(e) => setFormData(prev => ({ ...prev, confirmPassword: e.target.value }))}
        error={validationState.confirmPassword?.error}
        icon={Lock}
        required
        disabled={loading}
      />

      <Button
        variant="primary"
        className="w-full"
        type="submit"
        disabled={loading}
      >
        {loading ? 'Creating Account...' : selectedPlan ? `Sign up for ${selectedPlan.name}` : 'Create Account'}
      </Button>

      <p className="text-center text-sm text-gray-600">
        Already have an account?{' '}
        <a href="#login" className="font-medium text-blue-600 hover:text-blue-500">
          Sign in
        </a>
      </p>
    </form>
  );
}