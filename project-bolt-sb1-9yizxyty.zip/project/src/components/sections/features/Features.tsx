import React from 'react';
import { Users, FileCheck, Target, CreditCard } from 'lucide-react';
import { Container } from '../../ui/Container';
import { FeatureCard } from './FeatureCard';

const features = [
  {
    title: 'Recruitment Management',
    description: 'Streamline your hiring process with applicant tracking, job posting integration, and candidate screening tools.',
    icon: Users
  },
  {
    title: 'Onboarding Automation',
    description: 'Digital employee welcome packets, document management, and automated workflow checklists.',
    icon: FileCheck
  },
  {
    title: 'Performance Management',
    description: 'Track goals, implement 360-degree feedback, and manage performance reviews efficiently.',
    icon: Target
  },
  {
    title: 'Payroll Integration',
    description: 'Automated salary processing, tax calculations, and seamless direct deposit management.',
    icon: CreditCard
  }
];

export function Features() {
  return (
    <div className="py-16 bg-white">
      <Container>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Core HR Management Features
          </h2>
          <p className="text-xl text-gray-600">
            Everything you need to manage your workforce effectively
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature) => (
            <FeatureCard key={feature.title} {...feature} />
          ))}
        </div>
      </Container>
    </div>
  );
}