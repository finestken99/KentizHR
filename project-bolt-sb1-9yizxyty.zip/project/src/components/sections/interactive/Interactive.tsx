import React from 'react';
import { Container } from '../../ui/Container';
import { DashboardPreview } from './DashboardPreview';
import { DataVisualization } from './DataVisualization';

export function Interactive() {
  return (
    <div className="py-16 bg-gray-50">
      <Container>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Experience KENTIZ in Action
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our interactive features and see how KENTIZ can transform your HR operations
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-900">Live Dashboard Preview</h3>
            <p className="text-gray-600 mb-6">
              Get a glimpse of our intuitive interface and powerful features
            </p>
            <DashboardPreview />
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-900">Real-Time Analytics</h3>
            <p className="text-gray-600 mb-6">
              Monitor key metrics and trends with interactive data visualizations
            </p>
            <DataVisualization />
          </div>
        </div>
      </Container>
    </div>
  );
}