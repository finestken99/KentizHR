import React from 'react';

const generateData = () => {
  return Array.from({ length: 12 }, (_, i) => ({
    month: new Date(2024, i).toLocaleString('default', { month: 'short' }),
    value: Math.floor(Math.random() * 80) + 20
  }));
};

export function DataVisualization() {
  const data = generateData();
  const maxValue = Math.max(...data.map(d => d.value));

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Employee Engagement Trends</h3>
      <div className="h-64 flex items-end space-x-2">
        {data.map((item, index) => (
          <div
            key={item.month}
            className="flex-1 flex flex-col items-center"
          >
            <div
              className="w-full bg-blue-500 rounded-t hover:bg-blue-600 transition-all duration-300"
              style={{
                height: `${(item.value / maxValue) * 100}%`,
                animationDelay: `${index * 100}ms`,
                animation: 'grow 1s ease-out forwards'
              }}
            />
            <span className="text-xs text-gray-600 mt-2">{item.month}</span>
          </div>
        ))}
      </div>
    </div>
  );
}