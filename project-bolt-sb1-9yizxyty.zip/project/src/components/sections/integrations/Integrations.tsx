import React from 'react';
import { MessageSquare, Video, Mail, CreditCard, Linkedin, Phone } from 'lucide-react';
import { Container } from '../../ui/Container';
import { IntegrationLogo } from './IntegrationLogo';

const integrations = [
  { name: 'Slack', icon: MessageSquare },
  { name: 'Zoom', icon: Video },
  { name: 'Gmail', icon: Mail },
  { name: 'QuickBooks', icon: CreditCard },
  { name: 'LinkedIn', icon: Linkedin },
  { name: 'Teams', icon: Phone }
];

export function Integrations() {
  return (
    <div className="py-16 bg-white">
      <Container>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Integration Ecosystem
          </h2>
          <p className="text-xl text-gray-600">
            Seamlessly connect with your favorite tools
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {integrations.map((integration) => (
            <IntegrationLogo key={integration.name} {...integration} />
          ))}
        </div>
      </Container>
    </div>
  );
}