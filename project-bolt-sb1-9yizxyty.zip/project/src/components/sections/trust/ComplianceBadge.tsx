import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ComplianceBadgeProps {
  title: string;
  icon: LucideIcon;
  status: string;
}

export function ComplianceBadge({ title, icon: Icon, status }: ComplianceBadgeProps) {
  return (
    <div className="flex items-center p-4 bg-white rounded-lg border border-gray-200">
      <div className="p-2 bg-green-50 rounded-lg">
        <Icon className="h-6 w-6 text-green-600" />
      </div>
      <div className="ml-4">
        <h4 className="text-sm font-medium text-gray-900">{title}</h4>
        <span className="text-xs text-green-600">{status}</span>
      </div>
    </div>
  );
}