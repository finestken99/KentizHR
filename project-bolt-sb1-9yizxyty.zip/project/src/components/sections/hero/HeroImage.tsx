import React from 'react';

export function HeroImage() {
  return (
    <div className="relative">
      <img
        src="https://images.unsplash.com/photo-1551434678-e076c223a692?auto=format&fit=crop&q=80"
        alt="Dashboard Interface"
        className="rounded-lg shadow-xl"
      />
    </div>
  );
}