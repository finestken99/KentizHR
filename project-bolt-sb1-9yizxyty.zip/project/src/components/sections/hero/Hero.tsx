import React from 'react';
import { Container } from '../../ui/Container';
import { HeroContent } from './HeroContent';
import { HeroImage } from './HeroImage';

export function Hero() {
  return (
    <div className="pt-24 pb-16 bg-gradient-to-br from-blue-50 to-white">
      <Container>
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
          <HeroContent />
          <HeroImage />
        </div>
      </Container>
    </div>
  );
}