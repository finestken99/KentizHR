import React from 'react';
import { Button } from '../../ui/Button';
import { Play, ArrowRight } from 'lucide-react';

export function HeroContent() {
  return (
    <div className="mb-12 lg:mb-0">
      <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
        Transform Your Workforce Management
      </h1>
      <p className="text-xl text-gray-600 mb-8">
        Comprehensive HR Solution for Modern Businesses
      </p>
      <div className="flex flex-col sm:flex-row gap-4">
        <Button 
          variant="primary" 
          icon={ArrowRight}
          onClick={() => window.location.hash = '#register'}
        >
          Start Free Trial
        </Button>
        <Button 
          variant="secondary" 
          icon={Play}
          onClick={() => window.location.hash = '#demo'}
        >
          Watch Product Demo
        </Button>
      </div>
    </div>
  );
}