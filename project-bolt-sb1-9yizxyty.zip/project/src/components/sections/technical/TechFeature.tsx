import React from 'react';
import { LucideIcon } from 'lucide-react';

interface TechFeatureProps {
  title: string;
  description: string;
  icon: LucideIcon;
  metrics?: string[];
}

export function TechFeature({ title, description, icon: Icon, metrics }: TechFeatureProps) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-center mb-4">
        <div className="p-2 bg-blue-50 rounded-lg">
          <Icon className="h-6 w-6 text-blue-600" />
        </div>
      </div>
      <h3 className="text-xl font-semibold text-gray-900 mb-3">{title}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      {metrics && (
        <div className="border-t pt-4 mt-4">
          <ul className="space-y-2">
            {metrics.map((metric, index) => (
              <li key={index} className="text-sm text-gray-600 flex items-center">
                <span className="w-2 h-2 bg-blue-500 rounded-full mr-2" />
                {metric}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}