import React from 'react';
import { 
  Cloud, 
  Scale, 
  Brain, 
  Workflow, 
  Globe 
} from 'lucide-react';
import { Container } from '../../ui/Container';
import { TechFeature } from './TechFeature';

const features = [
  {
    title: 'Cloud-Based Platform',
    description: 'Built on cutting-edge cloud infrastructure ensuring high availability and seamless scalability.',
    icon: Cloud,
    metrics: [
      '99.99% uptime guarantee',
      'Global CDN distribution',
      'Automatic backups'
    ]
  },
  {
    title: 'Scalable Architecture',
    description: 'Microservices-based architecture designed to handle growing workforce demands.',
    icon: Scale,
    metrics: [
      'Horizontal scaling',
      'Load balancing',
      'Database sharding'
    ]
  },
  {
    title: 'Machine Learning Insights',
    description: 'Advanced AI algorithms providing predictive analytics and intelligent recommendations.',
    icon: Brain,
    metrics: [
      'Predictive analytics',
      'Pattern recognition',
      'Automated insights'
    ]
  },
  {
    title: 'Automated Workflows',
    description: 'Customizable automation engine to streamline HR processes and reduce manual tasks.',
    icon: Workflow,
    metrics: [
      'Visual workflow builder',
      'Custom triggers',
      'Integration hooks'
    ]
  },
  {
    title: 'Multi-Language Support',
    description: 'Comprehensive internationalization and localization capabilities.',
    icon: Globe,
    metrics: [
      '20+ languages supported',
      'RTL support',
      'Regional formatting'
    ]
  }
];

export function Technical() {
  return (
    <section id="technical" className="py-16 bg-gradient-to-b from-white to-gray-50">
      <Container>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Built for Enterprise Scale
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Powered by cutting-edge technology to deliver reliable, secure, and scalable HR solutions
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature) => (
            <TechFeature
              key={feature.title}
              {...feature}
            />
          ))}
        </div>
      </Container>
    </section>
  );
}