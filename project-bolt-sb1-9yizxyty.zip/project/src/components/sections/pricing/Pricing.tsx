import React from 'react';
import { Container } from '../../ui/Container';
import { PricingCard } from './PricingCard';

const plans = [
  {
    name: 'Starter',
    price: '$29',
    description: 'Perfect for small teams up to 25 employees',
    features: [
      'Employee database',
      'Basic leave management',
      'Document storage',
      'Standard reports',
      'Email support'
    ]
  },
  {
    name: 'Growth',
    price: '$79',
    description: 'Ideal for growing teams up to 100 employees',
    features: [
      'Everything in Starter',
      'AI-powered insights',
      'Advanced reporting',
      'Performance tracking',
      'Priority support',
      'Basic integrations'
    ],
    isPopular: true
  },
  {
    name: 'Scale',
    price: '$199',
    description: 'Advanced features for teams up to 500 employees',
    features: [
      'Everything in Growth',
      'Custom workflows',
      'Advanced analytics',
      'API access',
      'Dedicated support',
      'All integrations'
    ]
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    description: 'Tailored solutions for large organizations',
    features: [
      '500+ employees',
      'Custom solutions',
      'Dedicated account manager',
      'Custom integrations',
      'Premium support',
      'Customized training'
    ]
  }
];

export function Pricing() {
  return (
    <div className="py-16 bg-white">
      <Container>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Simple, Transparent Pricing
          </h2>
          <p className="text-xl text-gray-600">
            Choose the plan that best fits your business needs
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {plans.map((plan) => (
            <PricingCard key={plan.name} {...plan} />
          ))}
        </div>
      </Container>
    </div>
  );
}