import React, { useState } from 'react';
import { Button } from '../../ui/Button';
import { PricingFeature } from './PricingFeature';
import { useUser } from '../../../contexts/UserContext';
import { subscriptionService } from '../../../lib/services/subscriptionService';

interface PricingCardProps {
  name: string;
  price: string;
  description: string;
  features: string[];
  isPopular?: boolean;
}

export function PricingCard({ 
  name, 
  price, 
  description, 
  features,
  isPopular = false 
}: PricingCardProps) {
  const { user } = useUser();
  const [loading, setLoading] = useState(false);

  const handleGetStarted = async () => {
    setLoading(true);
    try {
      if (!user) {
        // Store selected plan in URL for registration flow
        window.location.hash = `#register?plan=${encodeURIComponent(name.toLowerCase())}`;
        return;
      }

      // Handle subscription for existing users
      const success = await subscriptionService.upgradePlan(user.id!, name.toLowerCase());
      if (success) {
        window.location.hash = '#subscription';
      } else {
        throw new Error('Failed to upgrade plan');
      }
    } catch (error) {
      console.error('Error handling subscription:', error);
      // Here you could show an error message to the user
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`
      p-8 rounded-2xl border-2 
      ${isPopular ? 'border-blue-500 shadow-lg' : 'border-gray-200'}
      relative flex flex-col
    `}>
      {isPopular && (
        <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-500 text-white px-3 py-1 rounded-full text-sm">
          Most Popular
        </span>
      )}
      
      <div className="mb-6">
        <h3 className="text-2xl font-bold text-gray-900 mb-2">{name}</h3>
        <p className="text-gray-600">{description}</p>
      </div>
      
      <div className="mb-6">
        <span className="text-4xl font-bold text-gray-900">{price}</span>
        <span className="text-gray-600">/month</span>
      </div>
      
      <ul className="space-y-3 mb-8 flex-grow">
        {features.map((feature) => (
          <PricingFeature key={feature} feature={feature} />
        ))}
      </ul>
      
      <Button 
        variant={isPopular ? 'primary' : 'secondary'}
        className="w-full"
        onClick={handleGetStarted}
        disabled={loading}
      >
        {loading ? 'Processing...' : 'Get Started'}
      </Button>
    </div>
  );
}