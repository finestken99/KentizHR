import React from 'react';
import { Building2, Users2, Building, Factory } from 'lucide-react';
import { Container } from '../../ui/Container';
import { SolutionCard } from './SolutionCard';

const solutions = [
  {
    title: 'Enterprise HR',
    description: 'Comprehensive HR solutions for large organizations with complex workforce needs.',
    icon: Building2,
    industries: ['500+ Employees', 'Multiple Locations', 'Global Teams']
  },
  {
    title: 'Small Business',
    description: 'Streamlined HR tools perfect for growing businesses and startups.',
    icon: Users2,
    industries: ['1-50 Employees', 'Single Location', 'Fast-growing']
  },
  {
    title: 'Healthcare',
    description: 'Specialized HR management for healthcare organizations and medical facilities.',
    icon: Building,
    industries: ['Hospitals', 'Clinics', 'Medical Practices']
  },
  {
    title: 'Manufacturing',
    description: 'HR solutions tailored for manufacturing and industrial environments.',
    icon: Factory,
    industries: ['Factories', 'Production', 'Shift Management']
  }
];

export function Solutions() {
  return (
    <div className="py-16 bg-gray-50">
      <Container>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Solution Scenarios
          </h2>
          <p className="text-xl text-gray-600">
            Tailored HR solutions for every industry and company size
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {solutions.map((solution) => (
            <SolutionCard key={solution.title} {...solution} />
          ))}
        </div>
      </Container>
    </div>
  );
}