import React from 'react';
import { Container } from '../../ui/Container';
import { TestimonialCard } from './TestimonialCard';

const testimonials = [
  {
    name: 'Sarah Johnson',
    role: 'HR Director',
    company: 'TechCorp',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80',
    quote: 'KENTIZ has transformed our HR operations. The automation features alone saved us 15 hours per week.',
    rating: 5
  },
  {
    name: 'Michael Chen',
    role: 'CEO',
    company: 'StartupX',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80',
    quote: 'The best HR software for growing companies. It scales perfectly with our needs.',
    rating: 5
  },
  {
    name: 'Emily Rodriguez',
    role: 'People Operations',
    company: 'HealthCare Plus',
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80',
    quote: 'Outstanding compliance management and healthcare-specific features.',
    rating: 5
  }
];

export function Testimonials() {
  return (
    <div className="py-16 bg-gray-50">
      <Container>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Customer Success Stories
          </h2>
          <p className="text-xl text-gray-600">
            See how companies are transforming their HR with KENTIZ
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <TestimonialCard key={testimonial.name} {...testimonial} />
          ))}
        </div>
      </Container>
    </div>
  );
}