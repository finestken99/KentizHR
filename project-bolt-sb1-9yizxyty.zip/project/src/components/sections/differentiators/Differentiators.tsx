import React from 'react';
import { 
  Brain, 
  BarChart2, 
  ShieldCheck, 
  Smartphone, 
  Globe, 
  LineChart 
} from 'lucide-react';
import { Container } from '../../ui/Container';
import { DifferentiatorCard } from './DifferentiatorCard';

const differentiators = [
  {
    title: 'AI-Powered HR Insights',
    description: 'Leverage machine learning algorithms to predict employee trends, optimize hiring processes, and make data-driven HR decisions.',
    icon: Brain
  },
  {
    title: 'Predictive Workforce Analytics',
    description: 'Forecast workforce needs, identify retention risks, and analyze performance patterns with advanced analytics tools.',
    icon: BarChart2
  },
  {
    title: 'Compliance Management',
    description: 'Stay compliant with automated updates, built-in policy templates, and real-time regulatory monitoring across jurisdictions.',
    icon: ShieldCheck
  },
  {
    title: 'Mobile Workforce Management',
    description: 'Manage your team on-the-go with our mobile-first platform, enabling remote work and flexible scheduling.',
    icon: Smartphone
  },
  {
    title: 'Global Payroll Support',
    description: 'Handle international payroll with ease, supporting multiple currencies, tax systems, and compliance requirements.',
    icon: Globe
  },
  {
    title: 'Advanced Reporting Tools',
    description: 'Generate comprehensive reports with customizable dashboards, real-time metrics, and exportable data formats.',
    icon: LineChart
  }
];

export function Differentiators() {
  return (
    <div className="py-16 bg-gradient-to-b from-white to-gray-50">
      <Container>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Why Choose KENTIZ
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Leading the future of HR management with innovative technology and comprehensive solutions
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {differentiators.map((differentiator) => (
            <DifferentiatorCard 
              key={differentiator.title} 
              {...differentiator} 
            />
          ))}
        </div>
      </Container>
    </div>
  );
}