import React from 'react';
import { LucideIcon } from 'lucide-react';

interface DifferentiatorCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
}

export function DifferentiatorCard({ title, description, icon: Icon }: DifferentiatorCardProps) {
  return (
    <div className="group p-6 bg-white rounded-xl border border-gray-200 hover:shadow-xl transition-all duration-300">
      <div className="flex items-center mb-4">
        <div className="p-2 bg-blue-50 rounded-lg group-hover:bg-blue-100 transition-colors">
          <Icon className="h-8 w-8 text-blue-600" />
        </div>
      </div>
      <h3 className="text-xl font-semibold text-gray-900 mb-3">{title}</h3>
      <p className="text-gray-600 leading-relaxed">{description}</p>
    </div>
  );
}