import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ResourceCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  category: string;
  readTime: string;
}

export function ResourceCard({ title, description, icon: Icon, category, readTime }: ResourceCardProps) {
  return (
    <div className="group bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow">
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Icon className="h-5 w-5 text-blue-600" />
            <span className="text-sm font-medium text-blue-600">{category}</span>
          </div>
          <span className="text-sm text-gray-500">{readTime}</span>
        </div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
          {title}
        </h3>
        <p className="text-gray-600">{description}</p>
      </div>
      <div className="px-6 py-4 bg-gray-50 border-t border-gray-100">
        <button className="text-blue-600 font-medium hover:text-blue-700 transition-colors">
          Read More →
        </button>
      </div>
    </div>
  );
}