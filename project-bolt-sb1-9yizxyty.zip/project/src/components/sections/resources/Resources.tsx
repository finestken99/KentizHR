import React, { useState } from 'react';
import { 
  BookOpen, 
  Video, 
  FileText, 
  FileCheck, 
  BarChart3 
} from 'lucide-react';
import { Container } from '../../ui/Container';
import { ResourceCard } from './ResourceCard';
import { ResourceFilter } from './ResourceFilter';

const categories = ['All Resources', 'Guides', 'Webinars', 'Blog Posts', 'Templates', 'Reports'];

const resources = [
  {
    title: 'Complete Guide to Modern HR Practices',
    description: 'Learn the latest HR strategies and best practices for managing a modern workforce.',
    icon: BookOpen,
    category: 'Guides',
    readTime: '15 min read'
  },
  {
    title: 'Upcoming Webinar: Future of Remote Work',
    description: 'Join industry experts discussing the evolution of remote work and hybrid workplace models.',
    icon: Video,
    category: 'Webinars',
    readTime: '60 min watch'
  },
  {
    title: '2024 Compliance Updates You Need to Know',
    description: 'Stay up-to-date with the latest HR compliance requirements and regulatory changes.',
    icon: FileText,
    category: 'Blog Posts',
    readTime: '8 min read'
  },
  {
    title: 'Employee Onboarding Template Pack',
    description: 'Comprehensive templates and checklists for streamlining your onboarding process.',
    icon: FileCheck,
    category: 'Templates',
    readTime: '10 min read'
  },
  {
    title: '2024 Salary Benchmarking Report',
    description: 'In-depth analysis of compensation trends across industries and roles.',
    icon: BarChart3,
    category: 'Reports',
    readTime: '20 min read'
  }
];

export function Resources() {
  const [activeCategory, setActiveCategory] = useState('All Resources');

  const filteredResources = resources.filter(
    resource => activeCategory === 'All Resources' || resource.category === activeCategory
  );

  return (
    <div className="py-16 bg-gray-50">
      <Container>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Resource Center
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Expert insights, guides, and tools to help you master HR management
          </p>
        </div>

        <ResourceFilter
          categories={categories}
          activeCategory={activeCategory}
          onCategoryChange={setActiveCategory}
        />
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredResources.map((resource) => (
            <ResourceCard
              key={resource.title}
              {...resource}
            />
          ))}
        </div>
      </Container>
    </div>
  );
}