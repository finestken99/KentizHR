import React from 'react';

interface LinkProps {
  to: string;
  children: React.ReactNode;
  className?: string;
  params?: Record<string, string>;
}

export function Link({ to, children, className = '', params }: LinkProps) {
  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    let url = `#${to}`;
    if (params) {
      const searchParams = new URLSearchParams();
      Object.entries(params).forEach(([key, value]) => {
        searchParams.append(key, value);
      });
      url += `?${searchParams.toString()}`;
    }
    window.location.hash = url;
  };

  return (
    <a href={`#${to}`} onClick={handleClick} className={className}>
      {children}
    </a>
  );
}