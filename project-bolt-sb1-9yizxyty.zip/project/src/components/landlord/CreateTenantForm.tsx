import React, { useState } from 'react';
import { Mail, Building2, User } from 'lucide-react';
import { Button } from '../ui/Button';
import { FormField } from '../ui/FormField';
import { useFormValidation } from '../../hooks/useFormValidation';
import { landlordService } from '../../lib/services/landlordService';
import { useAuth } from '../../hooks/useAuth';
import { UserRole } from '../../lib/auth/types';

interface FormData {
  companyName: string;
  email: string;
  firstName: string;
  lastName: string;
}

const initialFormData: FormData = {
  companyName: '',
  email: '',
  firstName: '',
  lastName: ''
};

export function CreateTenantForm() {
  const { user } = useAuth([UserRole.LANDLORD]);
  const [formData, setFormData] = useState(initialFormData);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      await landlordService.createTenant(user!.id!, formData);
      setSuccess(true);
      setTimeout(() => {
        window.location.hash = '#tenants';
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Failed to create tenant');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="text-center">
        <div className="rounded-full bg-green-100 p-3 mx-auto w-fit">
          <Building2 className="h-6 w-6 text-green-600" />
        </div>
        <h3 className="mt-4 text-lg font-medium text-gray-900">Tenant Created Successfully</h3>
        <p className="mt-2 text-sm text-gray-600">
          The tenant has been created and welcome email sent to the admin.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
          {error}
        </div>
      )}

      <FormField
        label="Company Name"
        name="companyName"
        value={formData.companyName}
        onChange={(e) => setFormData(prev => ({ ...prev, companyName: e.target.value }))}
        icon={Building2}
        required
        disabled={loading}
      />

      <FormField
        label="Admin Email"
        name="email"
        type="email"
        value={formData.email}
        onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
        icon={Mail}
        required
        disabled={loading}
      />

      <div className="grid grid-cols-2 gap-4">
        <FormField
          label="Admin First Name"
          name="firstName"
          value={formData.firstName}
          onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
          icon={User}
          required
          disabled={loading}
        />

        <FormField
          label="Admin Last Name"
          name="lastName"
          value={formData.lastName}
          onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
          icon={User}
          required
          disabled={loading}
        />
      </div>

      <Button
        variant="primary"
        className="w-full"
        type="submit"
        disabled={loading}
      >
        {loading ? 'Creating Tenant...' : 'Create Tenant'}
      </Button>
    </form>
  );
}