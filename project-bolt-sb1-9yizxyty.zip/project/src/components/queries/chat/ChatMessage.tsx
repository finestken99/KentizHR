import React from 'react';
import { Bot, User } from 'lucide-react';
import type { Message } from '../../../lib/types/chat';

interface ChatMessageProps {
  message: Message;
}

export function ChatMessage({ message }: ChatMessageProps) {
  return (
    <div className={`flex items-start space-x-3 ${
      message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''
    }`}>
      <div className={`p-2 rounded-full ${
        message.type === 'bot' ? 'bg-blue-100' : 'bg-gray-100'
      }`}>
        {message.type === 'bot' ? (
          <Bot className="h-5 w-5 text-blue-600" />
        ) : (
          <User className="h-5 w-5 text-gray-600" />
        )}
      </div>
      <div className={`flex-1 rounded-lg p-4 ${
        message.type === 'bot' ? 'bg-blue-50' : 'bg-gray-50'
      }`}>
        <p className="text-sm text-gray-900">{message.content}</p>
        <span className="text-xs text-gray-500 mt-1 block">
          {message.timestamp.toLocaleTimeString()}
        </span>
      </div>
    </div>
  );
}