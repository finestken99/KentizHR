import React, { useState } from 'react';
import { MessageCircle } from 'lucide-react';
import { MessageBubble } from './MessageBubble';
import { ChatHeader } from './ChatHeader';
import { ChatInput } from './ChatInput';
import { generateAIResponse } from './aiResponses';
import { useChat } from '../../../hooks/useChat';

export function Chatbot() {
  const [input, setInput] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { messages, addMessage } = useChat();

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    setIsLoading(true);
    try {
      // Save user message
      await addMessage(input.trim(), 'user');
      setInput('');

      // Generate and save AI response
      const aiResponse = await generateAIResponse(input);
      await addMessage(aiResponse, 'bot');
    } catch (error) {
      console.error('Error in chat:', error);
      await addMessage('Sorry, I encountered an error. Please try again.', 'bot');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {isOpen ? (
        <div className="w-96 h-[500px] bg-white shadow-2xl rounded-xl border flex flex-col">
          <ChatHeader onClose={() => setIsOpen(false)} />
          
          <div className="flex-grow overflow-y-auto p-4 space-y-4">
            {messages.map((message, index) => (
              <MessageBubble key={index} message={message} />
            ))}
            {isLoading && (
              <div className="flex justify-center">
                <div className="bg-gray-100 p-3 rounded-lg text-gray-500">
                  Typing...
                </div>
              </div>
            )}
          </div>

          <ChatInput
            input={input}
            isLoading={isLoading}
            onInputChange={setInput}
            onSendMessage={handleSendMessage}
          />
        </div>
      ) : (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-blue-600 text-white p-4 rounded-full shadow-2xl hover:bg-blue-700 transition-colors"
          aria-label="Open chat"
        >
          <MessageCircle size={24} />
        </button>
      )}
    </div>
  );
}