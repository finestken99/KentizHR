export const INITIAL_MESSAGE = 'Hello! I\'m your AI HR Assistant. How can I help you today?';
export const TYPING_INDICATOR = 'Typing...';
export const ERROR_MESSAGE = 'Sorry, I encountered an error. Please try again.';
export const PLACEHOLDER_TEXT = 'Ask an HR question...';
export const AI_RESPONSE_DELAY = 1000; // milliseconds