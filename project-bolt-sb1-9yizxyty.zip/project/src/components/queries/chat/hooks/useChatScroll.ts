import { useEffect, useRef } from 'react';
import type { Message } from '../types';

export function useChatScroll(messages: Message[], isOpen: boolean) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  return { messagesEndRef };
}