import React from 'react';
import { Bot } from 'lucide-react';

export function TypingIndicator() {
  return (
    <div className="flex items-start space-x-3">
      <div className="p-2 rounded-full bg-blue-100">
        <Bot className="h-5 w-5 text-blue-600" />
      </div>
      <div className="flex-1 rounded-lg p-4 bg-blue-50">
        <div className="flex space-x-2">
          <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" />
          <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce delay-100" />
          <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce delay-200" />
        </div>
      </div>
    </div>
  );
}