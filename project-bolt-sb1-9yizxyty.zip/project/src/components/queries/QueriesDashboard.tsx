import React from 'react';
import { Container } from '../ui/Container';
import { Chatbot } from './Chatbot';
import { QueryHistory } from './history/QueryHistory';
import { KnowledgeBase } from './knowledge/KnowledgeBase';
import { QueryAnalytics } from './analytics/QueryAnalytics';
import { QueryPriority } from './priority/QueryPriority';

export function QueriesDashboard() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Intelligent Support</h2>
          <p className="mt-2 text-gray-600">
            AI-powered assistance and query management
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <Chatbot />
            <QueryHistory />
          </div>
          <div className="space-y-8">
            <QueryPriority />
            <KnowledgeBase />
            <QueryAnalytics />
          </div>
        </div>
      </Container>
    </div>
  );
}