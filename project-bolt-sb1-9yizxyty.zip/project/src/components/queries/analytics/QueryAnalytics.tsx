import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, Brain } from 'lucide-react';

const data = [
  { month: 'Jan', queries: 12, resolved: 10 },
  { month: 'Feb', queries: 15, resolved: 14 },
  { month: 'Mar', queries: 10, resolved: 9 },
  { month: 'Apr', queries: 8, resolved: 8 },
  { month: 'May', queries: 12, resolved: 11 },
  { month: 'Jun', queries: 14, resolved: 13 }
];

export function QueryAnalytics() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Query Analytics</h3>
          <p className="text-sm text-gray-500">Support trends and insights</p>
        </div>
        <TrendingUp className="h-6 w-6 text-blue-500" />
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Line
              type="monotone"
              dataKey="queries"
              stroke="#3B82F6"
              strokeWidth={2}
              name="Total Queries"
            />
            <Line
              type="monotone"
              dataKey="resolved"
              stroke="#10B981"
              strokeWidth={2}
              name="Resolved"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <Brain className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">AI Insight</h4>
            <p className="text-sm text-gray-600 mt-1">
              92% of your queries are resolved within 24 hours, above the company average of 85%.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}