import React from 'react';
import { AlertCircle, Clock, MessageSquare } from 'lucide-react';

const priorityQueries = [
  {
    id: 1,
    title: 'System Access Request',
    status: 'urgent',
    timeLeft: '2 hours',
    message: 'Requires immediate attention'
  },
  {
    id: 2,
    title: 'Benefits Update',
    status: 'high',
    timeLeft: '4 hours',
    message: 'Pending HR review'
  },
  {
    id: 3,
    title: 'Training Access',
    status: 'medium',
    timeLeft: '1 day',
    message: 'In processing queue'
  }
];

const statusStyles = {
  urgent: 'bg-red-100 text-red-800 border-red-200',
  high: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  medium: 'bg-blue-100 text-blue-800 border-blue-200'
};

export function QueryPriority() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900">Priority Queries</h3>
        <p className="text-sm text-gray-500">Time-sensitive requests</p>
      </div>

      <div className="p-4 space-y-4">
        {priorityQueries.map((query) => (
          <div
            key={query.id}
            className={`p-4 rounded-lg border ${statusStyles[query.status]}`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3">
                <AlertCircle className="h-5 w-5 mt-0.5" />
                <div>
                  <h4 className="text-sm font-medium">{query.title}</h4>
                  <div className="flex items-center mt-1 space-x-2">
                    <Clock className="h-4 w-4" />
                    <span className="text-xs">{query.timeLeft} remaining</span>
                  </div>
                  <div className="flex items-center mt-2 space-x-2">
                    <MessageSquare className="h-4 w-4" />
                    <span className="text-xs">{query.message}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}