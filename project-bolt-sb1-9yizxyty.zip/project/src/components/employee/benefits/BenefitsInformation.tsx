```tsx
import React from 'react';
import { Heart, Shield, Umbrella, DollarSign } from 'lucide-react';
import { Button } from '../../ui/Button';

interface Benefit {
  id: number;
  type: string;
  plan: string;
  coverage: string;
  status: 'active' | 'pending' | 'inactive';
  nextEnrollment?: string;
  icon: typeof Heart;
  color: string;
  bgColor: string;
}

const benefits: Benefit[] = [
  {
    id: 1,
    type: 'Health Insurance',
    plan: 'Premium PPO Plan',
    coverage: 'Family Coverage',
    status: 'active',
    nextEnrollment: '2024-11-01',
    icon: Heart,
    color: 'text-red-500',
    bgColor: 'bg-red-50'
  },
  {
    id: 2,
    type: 'Dental Insurance',
    plan: 'Comprehensive Plan',
    coverage: 'Family Coverage',
    status: 'active',
    nextEnrollment: '2024-11-01',
    icon: Shield,
    color: 'text-blue-500',
    bgColor: 'bg-blue-50'
  },
  {
    id: 3,
    type: 'Vision Insurance',
    plan: 'Standard Plan',
    coverage: 'Family Coverage',
    status: 'active',
    nextEnrollment: '2024-11-01',
    icon: Shield,
    color: 'text-green-500',
    bgColor: 'bg-green-50'
  },
  {
    id: 4,
    type: 'Life Insurance',
    plan: '2x Annual Salary',
    coverage: 'Employee Only',
    status: 'active',
    nextEnrollment: '2024-11-01',
    icon: Umbrella,
    color: 'text-purple-500',
    bgColor: 'bg-purple-50'
  },
  {
    id: 5,
    type: '401(k) Retirement',
    plan: 'Traditional 401(k)',
    coverage: '6% Contribution with Company Match',
    status: 'active',
    icon: DollarSign,
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-50'
  }
];

export function BenefitsInformation() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Benefits Information</h3>
          <p className="text-sm text-gray-500">View and manage your benefits</p>
        </div>
        <Heart className="h-6 w-6 text-red-500" />
      </div>

      <div className="mb-8 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-sm font-medium text-gray-900">Open Enrollment</h4>
            <p className="text-sm text-gray-600 mt-1">
              Next enrollment period: November 1 - November 30, 2024
            </p>
          </div>
          <Button variant="primary">
            Review Benefits
          </Button>
        </div>
      </div>

      <div className="space-y-6">
        {benefits.map(benefit => {
          const Icon = benefit.icon;
          return (
            <div
              key={benefit.id}
              className={`p-4 rounded-lg ${benefit.bgColor}`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg bg-white`}>
                    <Icon className={`h-5 w-5 ${benefit.color}`} />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-900">{benefit.type}</h4>
                    <p className="text-sm text-gray-600 mt-1">{benefit.plan}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-gray-900">{benefit.coverage}</div>
                  <div className={`text-sm mt-1 ${
                    benefit.status === 'active' ? 'text-green-600' : 'text-yellow-600'
                  }`}>
                    {benefit.status.charAt(0).toUpperCase() + benefit.status.slice(1)}
                  </div>
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between">
                {benefit.nextEnrollment && (
                  <div className="text-sm text-gray-600">
                    Next enrollment: {new Date(benefit.nextEnrollment).toLocaleDateString()}
                  </div>
                )}
                <Button variant="secondary">
                  View Details
                </Button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
```