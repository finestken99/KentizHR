import React from 'react';
import { Bell, User, LogOut } from 'lucide-react';
import { Logo } from '../layout/Logo';
import { useUser } from '../../contexts/UserContext';

export function EmployeeHeader() {
  const { user, setUser } = useUser();

  const handleLogout = () => {
    localStorage.removeItem('auth_token');
    setUser(null);
    window.location.hash = '#login';
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Logo />
          
          <div className="flex items-center space-x-4">
            <button className="p-2 text-gray-400 hover:text-gray-500">
              <Bell className="h-6 w-6" />
            </button>
            <div className="flex items-center">
              <button className="flex items-center space-x-2 text-gray-700">
                <User className="h-6 w-6 text-gray-400" />
                <span className="text-sm font-medium">
                  {user?.first_name} {user?.last_name}
                </span>
              </button>
            </div>
            <button 
              className="p-2 text-gray-400 hover:text-gray-500"
              onClick={handleLogout}
            >
              <LogOut className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}