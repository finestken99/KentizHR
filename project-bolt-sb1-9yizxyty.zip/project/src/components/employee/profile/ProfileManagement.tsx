import React from 'react';
import { Container } from '../../ui/Container';
import { ProfilePicture } from './sections/ProfilePicture';
import { PersonalInformation } from './sections/PersonalInformation';
import { WorkInformation } from './sections/WorkInformation';
import { EducationCertifications } from './sections/EducationCertifications';
import { EmergencyContacts } from './sections/EmergencyContacts';
import { DocumentsSection } from './sections/DocumentsSection';
import { useUser } from '../../../contexts/UserContext';

export function ProfileManagement() {
  const { user } = useUser();

  if (!user) {
    window.location.hash = '#login';
    return null;
  }

  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Profile Management</h2>
          <p className="mt-2 text-gray-600">
            Update and manage your personal and work information
          </p>
        </div>

        <div className="space-y-8">
          <ProfilePicture />
          <PersonalInformation />
          <WorkInformation />
          <EducationCertifications />
          <EmergencyContacts />
          <DocumentsSection />
        </div>
      </Container>
    </div>
  );
}