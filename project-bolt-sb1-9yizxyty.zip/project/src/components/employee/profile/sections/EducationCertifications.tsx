import React, { useState } from 'react';
import { BookOpen, Award, Plus, Trash2, Calendar } from 'lucide-react';
import { Button } from '../../../ui/Button';
import { FormField } from '../../../ui/FormField';

interface Education {
  id: number;
  degree: string;
  institution: string;
  field: string;
  startDate: string;
  endDate: string;
  gpa?: string;
}

interface Certification {
  id: number;
  name: string;
  issuer: string;
  dateObtained: string;
  expiryDate?: string;
  credentialId?: string;
}

export function EducationCertifications() {
  const [education, setEducation] = useState<Education[]>([{
    id: 1,
    degree: '',
    institution: '',
    field: '',
    startDate: '',
    endDate: '',
    gpa: ''
  }]);

  const [certifications, setCertifications] = useState<Certification[]>([{
    id: 1,
    name: '',
    issuer: '',
    dateObtained: '',
    expiryDate: '',
    credentialId: ''
  }]);

  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleAddEducation = () => {
    setEducation(prev => [...prev, {
      id: Date.now(),
      degree: '',
      institution: '',
      field: '',
      startDate: '',
      endDate: '',
      gpa: ''
    }]);
  };

  const handleAddCertification = () => {
    setCertifications(prev => [...prev, {
      id: Date.now(),
      name: '',
      issuer: '',
      dateObtained: '',
      expiryDate: '',
      credentialId: ''
    }]);
  };

  const handleRemoveEducation = (id: number) => {
    setEducation(prev => prev.filter(edu => edu.id !== id));
  };

  const handleRemoveCertification = (id: number) => {
    setCertifications(prev => prev.filter(cert => cert.id !== id));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSuccess(false);

    try {
      // API call to update education and certifications would go here
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulated API call
      setSuccess(true);
    } catch (error) {
      console.error('Error updating education and certifications:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Education Section */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900">Education</h3>
              <p className="text-sm text-gray-500">Add your educational background</p>
            </div>
            <Button
              variant="secondary"
              type="button"
              onClick={handleAddEducation}
              disabled={loading}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Education
            </Button>
          </div>

          <div className="space-y-6">
            {education.map((edu, index) => (
              <div key={edu.id} className="border-b border-gray-200 pb-6 last:border-0">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-sm font-medium text-gray-900">
                    Education #{index + 1}
                  </h4>
                  {education.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveEducation(edu.id)}
                      className="text-red-600 hover:text-red-700 text-sm"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    label="Degree"
                    name={`edu-${edu.id}-degree`}
                    value={edu.degree}
                    onChange={(e) => setEducation(prev => prev.map(item => 
                      item.id === edu.id ? { ...item, degree: e.target.value } : item
                    ))}
                    icon={BookOpen}
                    required
                    disabled={loading}
                  />

                  <FormField
                    label="Institution"
                    name={`edu-${edu.id}-institution`}
                    value={edu.institution}
                    onChange={(e) => setEducation(prev => prev.map(item => 
                      item.id === edu.id ? { ...item, institution: e.target.value } : item
                    ))}
                    icon={BookOpen}
                    required
                    disabled={loading}
                  />

                  <FormField
                    label="Field of Study"
                    name={`edu-${edu.id}-field`}
                    value={edu.field}
                    onChange={(e) => setEducation(prev => prev.map(item => 
                      item.id === edu.id ? { ...item, field: e.target.value } : item
                    ))}
                    icon={BookOpen}
                    required
                    disabled={loading}
                  />

                  <FormField
                    label="GPA"
                    name={`edu-${edu.id}-gpa`}
                    value={edu.gpa}
                    onChange={(e) => setEducation(prev => prev.map(item => 
                      item.id === edu.id ? { ...item, gpa: e.target.value } : item
                    ))}
                    icon={Award}
                    disabled={loading}
                  />

                  <FormField
                    label="Start Date"
                    name={`edu-${edu.id}-startDate`}
                    type="date"
                    value={edu.startDate}
                    onChange={(e) => setEducation(prev => prev.map(item => 
                      item.id === edu.id ? { ...item, startDate: e.target.value } : item
                    ))}
                    icon={Calendar}
                    required
                    disabled={loading}
                  />

                  <FormField
                    label="End Date"
                    name={`edu-${edu.id}-endDate`}
                    type="date"
                    value={edu.endDate}
                    onChange={(e) => setEducation(prev => prev.map(item => 
                      item.id === edu.id ? { ...item, endDate: e.target.value } : item
                    ))}
                    icon={Calendar}
                    required
                    disabled={loading}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Certifications Section */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900">Certifications</h3>
              <p className="text-sm text-gray-500">Add your professional certifications</p>
            </div>
            <Button
              variant="secondary"
              type="button"
              onClick={handleAddCertification}
              disabled={loading}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Certification
            </Button>
          </div>

          <div className="space-y-6">
            {certifications.map((cert, index) => (
              <div key={cert.id} className="border-b border-gray-200 pb-6 last:border-0">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-sm font-medium text-gray-900">
                    Certification #{index + 1}
                  </h4>
                  {certifications.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveCertification(cert.id)}
                      className="text-red-600 hover:text-red-700 text-sm"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    label="Certification Name"
                    name={`cert-${cert.id}-name`}
                    value={cert.name}
                    onChange={(e) => setCertifications(prev => prev.map(item => 
                      item.id === cert.id ? { ...item, name: e.target.value } : item
                    ))}
                    icon={Award}
                    required
                    disabled={loading}
                  />

                  <FormField
                    label="Issuing Organization"
                    name={`cert-${cert.id}-issuer`}
                    value={cert.issuer}
                    onChange={(e) => setCertifications(prev => prev.map(item => 
                      item.id === cert.id ? { ...item, issuer: e.target.value } : item
                    ))}
                    icon={Award}
                    required
                    disabled={loading}
                  />

                  <FormField
                    label="Date Obtained"
                    name={`cert-${cert.id}-dateObtained`}
                    type="date"
                    value={cert.dateObtained}
                    onChange={(e) => setCertifications(prev => prev.map(item => 
                      item.id === cert.id ? { ...item, dateObtained: e.target.value } : item
                    ))}
                    icon={Calendar}
                    required
                    disabled={loading}
                  />

                  <FormField
                    label="Expiry Date"
                    name={`cert-${cert.id}-expiryDate`}
                    type="date"
                    value={cert.expiryDate}
                    onChange={(e) => setCertifications(prev => prev.map(item => 
                      item.id === cert.id ? { ...item, expiryDate: e.target.value } : item
                    ))}
                    icon={Calendar}
                    disabled={loading}
                  />

                  <FormField
                    label="Credential ID"
                    name={`cert-${cert.id}-credentialId`}
                    value={cert.credentialId}
                    onChange={(e) => setCertifications(prev => prev.map(item => 
                      item.id === cert.id ? { ...item, credentialId: e.target.value } : item
                    ))}
                    icon={Award}
                    disabled={loading}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {success && (
          <div className="bg-green-50 text-green-700 p-3 rounded-md">
            Education and certifications updated successfully
          </div>
        )}

        <div className="flex justify-end">
          <Button
            variant="primary"
            type="submit"
            disabled={loading}
          >
            {loading ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </form>
    </div>
  );
}