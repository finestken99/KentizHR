import React, { useState } from 'react';
import { User, Phone, Heart, Mail } from 'lucide-react';
import { Button } from '../../../ui/Button';
import { FormField } from '../../../ui/FormField';

interface EmergencyContact {
  id: number;
  name: string;
  relationship: string;
  phone: string;
  email: string;
}

export function EmergencyContacts() {
  const [contacts, setContacts] = useState<EmergencyContact[]>([
    {
      id: 1,
      name: '',
      relationship: '',
      phone: '',
      email: ''
    }
  ]);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleAddContact = () => {
    setContacts(prev => [
      ...prev,
      {
        id: Date.now(),
        name: '',
        relationship: '',
        phone: '',
        email: ''
      }
    ]);
  };

  const handleRemoveContact = (id: number) => {
    setContacts(prev => prev.filter(contact => contact.id !== id));
  };

  const handleContactChange = (id: number, field: keyof EmergencyContact, value: string) => {
    setContacts(prev => prev.map(contact => 
      contact.id === id ? { ...contact, [field]: value } : contact
    ));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSuccess(false);

    try {
      // API call to update emergency contacts would go here
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulated API call
      setSuccess(true);
    } catch (error) {
      console.error('Error updating emergency contacts:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">Emergency Contacts</h3>

      <form onSubmit={handleSubmit} className="space-y-6">
        {contacts.map((contact, index) => (
          <div key={contact.id} className="border-b border-gray-200 pb-6 last:border-0">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-sm font-medium text-gray-900">
                Contact #{index + 1}
              </h4>
              {contacts.length > 1 && (
                <button
                  type="button"
                  onClick={() => handleRemoveContact(contact.id)}
                  className="text-red-600 hover:text-red-700 text-sm"
                >
                  Remove
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                label="Full Name"
                name={`contact-${contact.id}-name`}
                value={contact.name}
                onChange={(e) => handleContactChange(contact.id, 'name', e.target.value)}
                icon={User}
                required
                disabled={loading}
              />

              <FormField
                label="Relationship"
                name={`contact-${contact.id}-relationship`}
                value={contact.relationship}
                onChange={(e) => handleContactChange(contact.id, 'relationship', e.target.value)}
                icon={Heart}
                required
                disabled={loading}
              />

              <FormField
                label="Phone Number"
                name={`contact-${contact.id}-phone`}
                type="tel"
                value={contact.phone}
                onChange={(e) => handleContactChange(contact.id, 'phone', e.target.value)}
                icon={Phone}
                required
                disabled={loading}
              />

              <FormField
                label="Email"
                name={`contact-${contact.id}-email`}
                type="email"
                value={contact.email}
                onChange={(e) => handleContactChange(contact.id, 'email', e.target.value)}
                icon={Mail}
                required
                disabled={loading}
              />
            </div>
          </div>
        ))}

        <div className="flex items-center justify-between">
          <Button
            variant="secondary"
            type="button"
            onClick={handleAddContact}
            disabled={loading}
          >
            Add Another Contact
          </Button>

          <Button
            variant="primary"
            type="submit"
            disabled={loading}
          >
            {loading ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>

        {success && (
          <div className="bg-green-50 text-green-700 p-3 rounded-md mt-4">
            Emergency contacts updated successfully
          </div>
        )}
      </form>
    </div>
  );
}