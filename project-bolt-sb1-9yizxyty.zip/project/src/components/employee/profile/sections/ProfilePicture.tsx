import React, { useState, useRef } from 'react';
import { Camera, Upload, X } from 'lucide-react';
import { Button } from '../../../ui/Button';

export function ProfilePicture() {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setLoading(true);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageUrl(reader.result as string);
        setLoading(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setImageUrl(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">Profile Picture</h3>

      <div className="flex items-center space-x-8">
        <div className="relative">
          <div className="w-32 h-32 rounded-full overflow-hidden bg-gray-100 flex items-center justify-center">
            {imageUrl ? (
              <img 
                src={imageUrl} 
                alt="Profile" 
                className="w-full h-full object-cover"
              />
            ) : (
              <Camera className="h-12 w-12 text-gray-400" />
            )}
          </div>
          {imageUrl && (
            <button
              onClick={handleRemoveImage}
              className="absolute -top-2 -right-2 p-1 bg-red-100 rounded-full text-red-600 hover:bg-red-200"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <div className="flex-1">
          <div className="mb-4">
            <h4 className="text-sm font-medium text-gray-900">Upload New Picture</h4>
            <p className="text-sm text-gray-500 mt-1">
              JPG or PNG, maximum 5MB
            </p>
          </div>

          <div className="flex items-center space-x-4">
            <input
              ref={fileInputRef}
              type="file"
              id="profile-picture"
              className="hidden"
              accept="image/jpeg,image/png"
              onChange={handleImageChange}
              disabled={loading}
            />
            <label htmlFor="profile-picture">
              <Button variant="secondary" as="span" disabled={loading}>
                <Upload className="h-4 w-4 mr-2" />
                {loading ? 'Uploading...' : 'Choose File'}
              </Button>
            </label>
            {imageUrl && (
              <Button
                variant="primary"
                disabled={loading}
              >
                Save Picture
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}