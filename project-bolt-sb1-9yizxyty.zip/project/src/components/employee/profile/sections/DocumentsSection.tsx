import React, { useState } from 'react';
import { FileText, Upload, Download, AlertTriangle, CheckCircle } from 'lucide-react';
import { Button } from '../../../ui/Button';

interface Document {
  id: number;
  name: string;
  type: string;
  status: 'pending' | 'approved' | 'rejected';
  uploadDate: string;
  message?: string;
}

export function DocumentsSection() {
  const [documents, setDocuments] = useState<Document[]>([
    {
      id: 1,
      name: 'ID Proof',
      type: 'Identity',
      status: 'approved',
      uploadDate: '2024-03-15'
    },
    {
      id: 2,
      name: 'Address Proof',
      type: 'Address',
      status: 'pending',
      uploadDate: '2024-03-16'
    },
    {
      id: 3,
      name: 'Education Certificate',
      type: 'Education',
      status: 'rejected',
      uploadDate: '2024-03-14',
      message: 'Please provide a certified copy'
    }
  ]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const newDocument: Document = {
        id: Date.now(),
        name: file.name,
        type: 'Other',
        status: 'pending',
        uploadDate: new Date().toISOString().split('T')[0]
      };
      setDocuments(prev => [...prev, newDocument]);
    }
  };

  const statusConfig = {
    pending: { icon: AlertTriangle, className: 'text-yellow-500' },
    approved: { icon: CheckCircle, className: 'text-green-500' },
    rejected: { icon: AlertTriangle, className: 'text-red-500' }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">Documents</h3>

      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-sm font-medium text-gray-900">Upload New Document</h4>
            <p className="text-sm text-gray-500">Supported formats: PDF, JPG, PNG</p>
          </div>
          <div>
            <input
              type="file"
              id="document-upload"
              className="hidden"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={handleFileUpload}
            />
            <label htmlFor="document-upload">
              <Button variant="secondary" as="span">
                <Upload className="h-4 w-4 mr-2" />
                Upload Document
              </Button>
            </label>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {documents.map(doc => {
          const StatusIcon = statusConfig[doc.status].icon;
          return (
            <div
              key={doc.id}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center space-x-4">
                <div className="p-2 bg-gray-100 rounded-lg">
                  <FileText className="h-5 w-5 text-gray-600" />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-900">{doc.name}</h4>
                  <div className="flex items-center mt-1">
                    <span className="text-xs text-gray-500">{doc.type}</span>
                    <span className="mx-2 text-gray-300">•</span>
                    <span className="text-xs text-gray-500">{doc.uploadDate}</span>
                  </div>
                  {doc.message && (
                    <p className="text-sm text-red-600 mt-1">{doc.message}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <StatusIcon className={`h-5 w-5 ${statusConfig[doc.status].className}`} />
                <button className="p-2 hover:bg-gray-100 rounded-lg">
                  <Download className="h-5 w-5 text-gray-400" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}