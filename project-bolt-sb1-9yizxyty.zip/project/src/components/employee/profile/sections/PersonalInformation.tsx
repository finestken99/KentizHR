import React, { useState } from 'react';
import { User, Mail, Phone, MapPin } from 'lucide-react';
import { Button } from '../../../ui/Button';
import { FormField } from '../../../ui/FormField';
import { useUser } from '../../../../contexts/UserContext';

export function PersonalInformation() {
  const { user } = useUser();
  const [formData, setFormData] = useState({
    firstName: user?.first_name || '',
    lastName: user?.last_name || '',
    email: user?.email || '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: ''
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSuccess(false);

    try {
      // API call to update personal information would go here
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulated API call
      setSuccess(true);
    } catch (error) {
      console.error('Error updating profile:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">Personal Information</h3>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            label="First Name"
            name="firstName"
            value={formData.firstName}
            onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
            icon={User}
            required
            disabled={loading}
          />

          <FormField
            label="Last Name"
            name="lastName"
            value={formData.lastName}
            onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
            icon={User}
            required
            disabled={loading}
          />

          <FormField
            label="Email Address"
            name="email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
            icon={Mail}
            required
            disabled={loading}
          />

          <FormField
            label="Phone Number"
            name="phone"
            type="tel"
            value={formData.phone}
            onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
            icon={Phone}
            required
            disabled={loading}
          />

          <FormField
            label="Address"
            name="address"
            value={formData.address}
            onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
            icon={MapPin}
            required
            disabled={loading}
          />

          <div className="grid grid-cols-3 gap-4">
            <FormField
              label="City"
              name="city"
              value={formData.city}
              onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
              required
              disabled={loading}
            />

            <FormField
              label="State"
              name="state"
              value={formData.state}
              onChange={(e) => setFormData(prev => ({ ...prev, state: e.target.value }))}
              required
              disabled={loading}
            />

            <FormField
              label="ZIP Code"
              name="zipCode"
              value={formData.zipCode}
              onChange={(e) => setFormData(prev => ({ ...prev, zipCode: e.target.value }))}
              required
              disabled={loading}
            />
          </div>
        </div>

        {success && (
          <div className="bg-green-50 text-green-700 p-3 rounded-md">
            Personal information updated successfully
          </div>
        )}

        <div className="flex justify-end">
          <Button
            variant="primary"
            type="submit"
            disabled={loading}
          >
            {loading ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </form>
    </div>
  );
}