import React, { useState } from 'react';
import { Building2, Users, Calendar, Briefcase } from 'lucide-react';
import { Button } from '../../../ui/Button';
import { FormField } from '../../../ui/FormField';

export function WorkInformation() {
  const [formData, setFormData] = useState({
    department: '',
    position: '',
    startDate: '',
    manager: '',
    employeeId: '',
    workLocation: '',
    workEmail: '',
    workPhone: ''
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSuccess(false);

    try {
      // API call to update work information would go here
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulated API call
      setSuccess(true);
    } catch (error) {
      console.error('Error updating work information:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-6">Work Information</h3>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            label="Department"
            name="department"
            value={formData.department}
            onChange={(e) => setFormData(prev => ({ ...prev, department: e.target.value }))}
            icon={Building2}
            required
            disabled={loading}
          />

          <FormField
            label="Position"
            name="position"
            value={formData.position}
            onChange={(e) => setFormData(prev => ({ ...prev, position: e.target.value }))}
            icon={Briefcase}
            required
            disabled={loading}
          />

          <FormField
            label="Start Date"
            name="startDate"
            type="date"
            value={formData.startDate}
            onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
            icon={Calendar}
            required
            disabled={loading}
          />

          <FormField
            label="Manager"
            name="manager"
            value={formData.manager}
            onChange={(e) => setFormData(prev => ({ ...prev, manager: e.target.value }))}
            icon={Users}
            required
            disabled={loading}
          />

          <FormField
            label="Employee ID"
            name="employeeId"
            value={formData.employeeId}
            onChange={(e) => setFormData(prev => ({ ...prev, employeeId: e.target.value }))}
            icon={Briefcase}
            required
            disabled={loading}
          />

          <FormField
            label="Work Location"
            name="workLocation"
            value={formData.workLocation}
            onChange={(e) => setFormData(prev => ({ ...prev, workLocation: e.target.value }))}
            icon={Building2}
            required
            disabled={loading}
          />

          <FormField
            label="Work Email"
            name="workEmail"
            type="email"
            value={formData.workEmail}
            onChange={(e) => setFormData(prev => ({ ...prev, workEmail: e.target.value }))}
            icon={Building2}
            required
            disabled={loading}
          />

          <FormField
            label="Work Phone"
            name="workPhone"
            type="tel"
            value={formData.workPhone}
            onChange={(e) => setFormData(prev => ({ ...prev, workPhone: e.target.value }))}
            icon={Building2}
            required
            disabled={loading}
          />
        </div>

        {success && (
          <div className="bg-green-50 text-green-700 p-3 rounded-md">
            Work information updated successfully
          </div>
        )}

        <div className="flex justify-end">
          <Button
            variant="primary"
            type="submit"
            disabled={loading}
          >
            {loading ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </form>
    </div>
  );
}