import React from 'react';
import { Container } from '../../ui/Container';
import { TaskOverview } from './sections/TaskOverview';
import { TaskList } from './sections/TaskList';
import { TaskCalendar } from './sections/TaskCalendar';
import { TaskAnalytics } from './sections/TaskAnalytics';
import { AIRecommendations } from './sections/AIRecommendations';

export function TaskManagement() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Task Management</h2>
          <p className="mt-2 text-gray-600">
            Track and manage your tasks and assignments
          </p>
        </div>

        <div className="space-y-8">
          <TaskOverview />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <TaskList />
              <TaskCalendar />
            </div>
            <div className="space-y-8">
              <TaskAnalytics />
              <AIRecommendations />
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}