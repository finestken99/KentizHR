import React, { useState } from 'react';
import { CheckCircle, Clock, AlertCircle, Calendar, Plus } from 'lucide-react';
import { Button } from '../../../ui/Button';

interface Task {
  id: number;
  title: string;
  description: string;
  dueDate: string;
  priority: 'high' | 'medium' | 'low';
  status: 'completed' | 'in_progress' | 'pending';
  assignedBy: string;
}

const tasks: Task[] = [
  {
    id: 1,
    title: 'Complete Onboarding Documentation',
    description: 'Submit all required onboarding forms and documents',
    dueDate: '2024-03-20',
    priority: 'high',
    status: 'in_progress',
    assignedBy: 'HR Manager'
  },
  {
    id: 2,
    title: 'Review Company Policies',
    description: 'Read and acknowledge company policies and procedures',
    dueDate: '2024-03-25',
    priority: 'medium',
    status: 'pending',
    assignedBy: 'HR Manager'
  },
  {
    id: 3,
    title: 'Set Up Workstation',
    description: 'Configure computer and required software',
    dueDate: '2024-03-18',
    priority: 'high',
    status: 'completed',
    assignedBy: 'IT Support'
  }
];

const statusConfig = {
  completed: { icon: CheckCircle, className: 'text-green-500' },
  in_progress: { icon: Clock, className: 'text-yellow-500' },
  pending: { icon: AlertCircle, className: 'text-red-500' }
};

const priorityStyles = {
  high: 'bg-red-100 text-red-800',
  medium: 'bg-yellow-100 text-yellow-800',
  low: 'bg-green-100 text-green-800'
};

export function TaskList() {
  const [showCompleted, setShowCompleted] = useState(false);

  const filteredTasks = tasks.filter(task => 
    showCompleted || task.status !== 'completed'
  );

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Tasks</h3>
          <p className="text-sm text-gray-500">Manage your assigned tasks</p>
        </div>
        <div className="flex items-center space-x-4">
          <label className="flex items-center">
            <input
              type="checkbox"
              checked={showCompleted}
              onChange={(e) => setShowCompleted(e.target.checked)}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="ml-2 text-sm text-gray-600">Show Completed</span>
          </label>
          <Button variant="primary">
            <Plus className="h-4 w-4 mr-2" />
            Add Task
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        {filteredTasks.map(task => {
          const StatusIcon = statusConfig[task.status].icon;
          return (
            <div
              key={task.id}
              className="border border-gray-200 rounded-lg p-4 hover:border-gray-300 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3">
                  <StatusIcon className={`h-5 w-5 mt-0.5 ${statusConfig[task.status].className}`} />
                  <div>
                    <h4 className="text-sm font-medium text-gray-900">{task.title}</h4>
                    <p className="text-sm text-gray-600 mt-1">{task.description}</p>
                    <div className="flex items-center mt-2 space-x-4">
                      <div className="flex items-center text-sm text-gray-500">
                        <Calendar className="h-4 w-4 mr-1" />
                        Due: {new Date(task.dueDate).toLocaleDateString()}
                      </div>
                      <div className="text-sm text-gray-500">
                        Assigned by: {task.assignedBy}
                      </div>
                    </div>
                  </div>
                </div>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  priorityStyles[task.priority]
                }`}>
                  {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}