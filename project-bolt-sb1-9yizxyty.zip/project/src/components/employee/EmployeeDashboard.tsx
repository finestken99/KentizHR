import React from 'react';
import { EmployeeHeader } from './EmployeeHeader';
import { EmployeeSidebar } from './EmployeeSidebar';
import { EmployeeOverview } from './overview/EmployeeOverview';
import { ProfileManagement } from './profile/ProfileManagement';
import { DocumentDashboard } from './documents/DocumentDashboard';
import { LeaveManagement } from './leave/LeaveManagement';
import { PerformanceDashboard } from './performance/PerformanceDashboard';
import { TrainingDashboard } from './training/TrainingDashboard';
import { PayrollDashboard } from './payroll/PayrollDashboard';
import { QueriesDashboard } from '../queries/QueriesDashboard';
import { CompanyDirectory } from './company/CompanyDirectory';
import { SettingsDashboard } from './settings/SettingsDashboard';
import { useHash } from '../../hooks/useHash';

export function EmployeeDashboard() {
  const hash = useHash();
  const section = hash.split('/')[1] || 'overview';

  const renderContent = () => {
    switch (section) {
      case 'profile':
        return <ProfileManagement />;
      case 'documents':
        return <DocumentDashboard />;
      case 'leave':
        return <LeaveManagement />;
      case 'performance':
        return <PerformanceDashboard />;
      case 'training':
        return <TrainingDashboard />;
      case 'payroll':
        return <PayrollDashboard />;
      case 'queries':
        return <QueriesDashboard />;
      case 'company':
        return <CompanyDirectory />;
      case 'settings':
        return <SettingsDashboard />;
      default:
        return <EmployeeOverview />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <EmployeeHeader />
      <div className="flex">
        <EmployeeSidebar />
        <main className="flex-1">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}