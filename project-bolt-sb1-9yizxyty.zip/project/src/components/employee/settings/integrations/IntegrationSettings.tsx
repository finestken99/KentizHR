import React, { useState } from 'react';
import { Link2, MessageSquare, Video, Mail, CreditCard, Linkedin, Phone } from 'lucide-react';

const integrations = [
  {
    id: 'slack',
    name: 'Slack',
    description: 'Team communication and notifications',
    icon: MessageSquare,
    connected: true
  },
  {
    id: 'zoom',
    name: 'Zoom',
    description: 'Video conferencing integration',
    icon: Video,
    connected: true
  },
  {
    id: 'gmail',
    name: 'Gmail',
    description: 'Email notifications and calendar sync',
    icon: Mail,
    connected: false
  },
  {
    id: 'quickbooks',
    name: 'QuickBooks',
    description: 'Payroll and accounting integration',
    icon: CreditCard,
    connected: true
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    description: 'Professional network integration',
    icon: Linkedin,
    connected: false
  },
  {
    id: 'teams',
    name: 'Microsoft Teams',
    description: 'Team collaboration platform',
    icon: Phone,
    connected: false
  }
];

export function IntegrationSettings() {
  const [connectedApps, setConnectedApps] = useState(
    integrations.reduce((acc, { id, connected }) => ({
      ...acc,
      [id]: connected
    }), {})
  );

  const toggleConnection = (id: string) => {
    setConnectedApps(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-gray-900">Connected Applications</h3>
        <Link2 className="h-6 w-6 text-blue-500" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {integrations.map(({ id, name, description, icon: Icon }) => (
          <div
            key={id}
            className="p-4 border border-gray-200 rounded-lg hover:border-gray-300 transition-colors"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3">
                <div className="p-2 bg-gray-100 rounded-lg">
                  <Icon className="h-6 w-6 text-gray-600" />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-900">{name}</h4>
                  <p className="text-sm text-gray-500">{description}</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  className="sr-only peer"
                  checked={connectedApps[id]}
                  onChange={() => toggleConnection(id)}
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}