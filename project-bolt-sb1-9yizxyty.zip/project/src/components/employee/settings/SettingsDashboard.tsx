import React from 'react';
import { Container } from '../../ui/Container';
import { PersonalSettings } from './personal/PersonalSettings';
import { SecuritySettings } from './security/SecuritySettings';
import { NotificationSettings } from './notifications/NotificationSettings';
import { IntegrationSettings } from './integrations/IntegrationSettings';
import { PrivacySettings } from './privacy/PrivacySettings';
import { AIPreferences } from './ai/AIPreferences';

export function SettingsDashboard() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Settings & Preferences</h2>
          <p className="mt-2 text-gray-600">
            Manage your account settings and AI-powered personalization
          </p>
        </div>

        <div className="space-y-8">
          <PersonalSettings />
          <SecuritySettings />
          <NotificationSettings />
          <IntegrationSettings />
          <PrivacySettings />
          <AIPreferences />
        </div>
      </Container>
    </div>
  );
}