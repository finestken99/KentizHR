import React, { useState } from 'react';
import { Eye, Lock, Shield, Users } from 'lucide-react';

const privacyOptions = [
  {
    id: 'profile_visibility',
    title: 'Profile Visibility',
    description: 'Control who can view your profile information',
    icon: Eye,
    options: [
      { value: 'public', label: 'Public' },
      { value: 'team', label: 'Team Only' },
      { value: 'private', label: 'Private' }
    ]
  },
  {
    id: 'data_sharing',
    title: 'Data Sharing',
    description: 'Manage how your data is shared within the organization',
    icon: Lock,
    options: [
      { value: 'all', label: 'Share All Data' },
      { value: 'limited', label: 'Limited Sharing' },
      { value: 'minimal', label: 'Minimal Sharing' }
    ]
  },
  {
    id: 'activity_tracking',
    title: 'Activity Tracking',
    description: 'Choose what activity data is collected',
    icon: Shield,
    options: [
      { value: 'full', label: 'Full Tracking' },
      { value: 'partial', label: 'Partial Tracking' },
      { value: 'essential', label: 'Essential Only' }
    ]
  }
];

export function PrivacySettings() {
  const [settings, setSettings] = useState({
    profile_visibility: 'team',
    data_sharing: 'limited',
    activity_tracking: 'partial'
  });

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-gray-900">Privacy Settings</h3>
        <Users className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-6">
        {privacyOptions.map(({ id, title, description, icon: Icon, options }) => (
          <div key={id} className="p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3 mb-4">
              <Icon className="h-6 w-6 text-blue-500" />
              <div>
                <h4 className="text-sm font-medium text-gray-900">{title}</h4>
                <p className="text-sm text-gray-500">{description}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-3">
              {options.map(({ value, label }) => (
                <button
                  key={value}
                  onClick={() => setSettings(prev => ({ ...prev, [id]: value }))}
                  className={`p-2 text-sm rounded-lg border transition-colors ${
                    settings[id] === value
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 hover:border-gray-300 text-gray-700'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}