import React from 'react';
import { Brain, Calendar, Users, TrendingUp } from 'lucide-react';

const recommendations = [
  {
    title: 'Optimal Leave Window',
    description: 'Consider taking leave between July 15-30 when team workload is lighter',
    icon: Calendar,
    priority: 'high'
  },
  {
    title: 'Team Coverage',
    description: '85% team availability expected during suggested dates',
    icon: Users,
    priority: 'medium'
  },
  {
    title: 'Work-Life Balance',
    description: 'Taking regular breaks helps maintain productivity',
    icon: TrendingUp,
    priority: 'low'
  }
];

const priorityStyles = {
  high: 'bg-blue-50 border-blue-200 text-blue-700',
  medium: 'bg-green-50 border-green-200 text-green-700',
  low: 'bg-purple-50 border-purple-200 text-purple-700'
};

export function LeaveRecommendations() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Smart Recommendations</h3>
          <p className="text-sm text-gray-500">AI-powered leave planning insights</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {recommendations.map((rec, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg border ${priorityStyles[rec.priority]}`}
          >
            <div className="flex items-start space-x-3">
              <rec.icon className="h-5 w-5 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium">{rec.title}</h4>
                <p className="text-sm mt-1">{rec.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <button className="mt-6 w-full flex items-center justify-center px-4 py-2 border border-blue-500 rounded-lg text-blue-600 hover:bg-blue-50 transition-colors">
        <Calendar className="h-4 w-4 mr-2" />
        Plan My Leave
      </button>
    </div>
  );
}