import React from 'react';
import { Calendar as CalendarIcon, Users } from 'lucide-react';

const events = [
  {
    date: '2024-03-20',
    events: [
      { name: 'John Smith', type: 'Annual Leave' },
      { name: 'Sarah Johnson', type: 'Sick Leave' }
    ]
  },
  {
    date: '2024-03-21',
    events: [
      { name: 'Mike Wilson', type: 'Personal Leave' }
    ]
  }
];

export function LeaveCalendar() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Team Calendar</h3>
          <p className="text-sm text-gray-500">View team availability and leave schedule</p>
        </div>
        <CalendarIcon className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {events.map((day) => (
          <div key={day.date} className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <CalendarIcon className="h-5 w-5 text-gray-400" />
                <span className="font-medium text-gray-900">
                  {new Date(day.date).toLocaleDateString('en-US', { 
                    weekday: 'long',
                    month: 'long',
                    day: 'numeric'
                  })}
                </span>
              </div>
              <div className="flex items-center space-x-1">
                <Users className="h-5 w-5 text-gray-400" />
                <span className="text-sm text-gray-600">{day.events.length} team members away</span>
              </div>
            </div>

            <div className="space-y-2">
              {day.events.map((event, index) => (
                <div key={index} className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
                  <span className="text-sm font-medium text-gray-900">{event.name}</span>
                  <span className="text-sm text-gray-600">{event.type}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}