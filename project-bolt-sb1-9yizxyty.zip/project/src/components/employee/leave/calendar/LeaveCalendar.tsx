```tsx
import React, { useState } from 'react';
import { Calendar as CalendarIcon, Users } from 'lucide-react';

interface LeaveEvent {
  date: string;
  events: Array<{
    name: string;
    type: string;
  }>;
}

const mockEvents: LeaveEvent[] = [
  {
    date: '2024-03-20',
    events: [
      { name: 'John Smith', type: 'Annual Leave' },
      { name: 'Sarah Johnson', type: 'Sick Leave' }
    ]
  },
  {
    date: '2024-03-21',
    events: [
      { name: 'Mike Wilson', type: 'Personal Leave' }
    ]
  }
];

export function LeaveCalendar() {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const handlePreviousMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();
    
    return { daysInMonth, startingDay };
  };

  const renderCalendarHeader = () => {
    return (
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900">
          {currentMonth.toLocaleString('default', { month: 'long', year: 'numeric' })}
        </h3>
        <div className="flex space-x-2">
          <button
            onClick={handlePreviousMonth}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <ChevronLeft className="h-5 w-5 text-gray-600" />
          </button>
          <button
            onClick={handleNextMonth}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <ChevronRight className="h-5 w-5 text-gray-600" />
          </button>
        </div>
      </div>
    );
  };

  const renderCalendarDays = () => {
    const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const { daysInMonth, startingDay } = getDaysInMonth(currentMonth);
    const days = [];

    // Add empty cells for days before the first of the month
    for (let i = 0; i < startingDay; i++) {
      days.push(<div key={`empty-${i}`} className="bg-gray-50" />);
    }

    // Add cells for each day of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
      const dateStr = date.toISOString().split('T')[0];
      const dayEvents = mockEvents.find(e => e.date === dateStr)?.events || [];
      const isToday = new Date().toDateString() === date.toDateString();

      days.push(
        <div
          key={dateStr}
          className={`min-h-[100px] p-2 border border-gray-200 ${
            isToday ? 'bg-blue-50' : 'bg-white'
          }`}
        >
          <div className="font-medium text-sm text-gray-900 mb-1">
            {day}
          </div>
          <div className="space-y-1">
            {dayEvents.map((event, index) => (
              <div
                key={index}
                className="flex items-center text-xs p-1 rounded-md bg-blue-50"
              >
                <Users className="h-3 w-3 text-blue-500 mr-1" />
                <span className="text-blue-700 truncate">{event.name}</span>
              </div>
            ))}
          </div>
        </div>
      );
    }

    return (
      <>
        <div className="grid grid-cols-7 gap-px border-b">
          {weekdays.map(day => (
            <div
              key={day}
              className="py-2 text-sm font-medium text-gray-900 text-center bg-gray-50"
            >
              {day}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-px">
          {days}
        </div>
      </>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      {renderCalendarHeader()}
      {renderCalendarDays()}
    </div>
  );
}
```