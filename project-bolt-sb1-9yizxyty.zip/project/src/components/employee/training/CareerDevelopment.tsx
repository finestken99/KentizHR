import React from 'react';
import { TrendingUp, Target, Award, Star } from 'lucide-react';

const careerPath = [
  {
    role: 'Senior Developer',
    status: 'current',
    progress: 75,
    timeframe: '6-12 months',
    requirements: [
      'Lead 2 major projects',
      'Mentor junior developers',
      'System design expertise'
    ]
  },
  {
    role: 'Tech Lead',
    status: 'next',
    progress: 45,
    timeframe: '1-2 years',
    requirements: [
      'Team management',
      'Architecture planning',
      'Cross-team collaboration'
    ]
  },
  {
    role: 'Engineering Manager',
    status: 'future',
    progress: 20,
    timeframe: '2-3 years',
    requirements: [
      'Department strategy',
      'Resource planning',
      'Stakeholder management'
    ]
  }
];

const statusStyles = {
  current: {
    border: 'border-blue-200',
    bg: 'bg-blue-50',
    progress: 'bg-blue-500',
    text: 'text-blue-700'
  },
  next: {
    border: 'border-green-200',
    bg: 'bg-green-50',
    progress: 'bg-green-500',
    text: 'text-green-700'
  },
  future: {
    border: 'border-purple-200',
    bg: 'bg-purple-50',
    progress: 'bg-purple-500',
    text: 'text-purple-700'
  }
};

export function CareerDevelopment() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Career Progression</h3>
          <p className="text-sm text-gray-500">AI-predicted career path</p>
        </div>
        <TrendingUp className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-6">
        {careerPath.map((path, index) => (
          <div
            key={path.role}
            className={`p-4 rounded-lg border ${statusStyles[path.status].border} ${statusStyles[path.status].bg}`}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                {path.status === 'current' ? (
                  <Star className="h-5 w-5 text-blue-500" />
                ) : path.status === 'next' ? (
                  <Target className="h-5 w-5 text-green-500" />
                ) : (
                  <Award className="h-5 w-5 text-purple-500" />
                )}
                <span className="text-sm font-medium text-gray-900">{path.role}</span>
              </div>
              <span className={`text-xs px-2 py-1 rounded-full ${statusStyles[path.status].text} ${statusStyles[path.status].bg}`}>
                {path.timeframe}
              </span>
            </div>

            <div className="mb-3">
              <div className="flex justify-between text-xs text-gray-500 mb-1">
                <span>Progress</span>
                <span>{path.progress}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full">
                <div
                  className={`h-2 rounded-full ${statusStyles[path.status].progress}`}
                  style={{ width: `${path.progress}%` }}
                />
              </div>
            </div>

            <div className="space-y-2">
              {path.requirements.map((req, reqIndex) => (
                <div key={reqIndex} className="flex items-center space-x-2">
                  <div className={`w-1.5 h-1.5 rounded-full ${statusStyles[path.status].progress}`} />
                  <span className="text-sm text-gray-600">{req}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <TrendingUp className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">Growth Trajectory</h4>
            <p className="text-sm text-gray-600 mt-1">
              You're on track for a Tech Lead role. Focus on system design and team leadership to accelerate your progression.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}