import React from 'react';
import { Brain, Book, Target, Award } from 'lucide-react';

const skillGaps = [
  {
    skill: 'Cloud Architecture',
    current: 75,
    required: 85,
    priority: 'high',
    recommendation: 'Focus on AWS certification'
  },
  {
    skill: 'System Design',
    current: 80,
    required: 90,
    priority: 'medium',
    recommendation: 'Practice scalable architectures'
  },
  {
    skill: 'DevOps',
    current: 70,
    required: 80,
    priority: 'low',
    recommendation: 'Learn CI/CD pipelines'
  }
];

const priorityStyles = {
  high: 'bg-red-50 text-red-700',
  medium: 'bg-yellow-50 text-yellow-700',
  low: 'bg-green-50 text-green-700'
};

export function SkillGapAnalysis() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Skill Gap Analysis</h3>
          <p className="text-sm text-gray-500">AI-identified areas for growth</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-6">
        {skillGaps.map((gap, index) => (
          <div key={index} className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Book className="h-5 w-5 text-gray-400" />
                <span className="text-sm font-medium text-gray-900">{gap.skill}</span>
              </div>
              <span className={`text-xs px-2 py-1 rounded-full ${priorityStyles[gap.priority]}`}>
                {gap.priority.charAt(0).toUpperCase() + gap.priority.slice(1)} Priority
              </span>
            </div>

            <div className="relative pt-1">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-gray-600">Current: {gap.current}%</span>
                <span className="text-gray-600">Required: {gap.required}%</span>
              </div>
              <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                <div
                  className="bg-blue-500"
                  style={{ width: `${gap.current}%` }}
                />
                <div
                  className="flex items-center justify-center absolute right-0 h-2 border-l-2 border-red-500"
                  style={{ left: `${gap.required}%` }}
                >
                  <Target className="h-3 w-3 text-red-500 absolute -right-1.5 -top-1.5" />
                </div>
              </div>
            </div>

            <div className="flex items-start space-x-2 mt-2">
              <Award className="h-4 w-4 text-blue-500 mt-0.5" />
              <p className="text-sm text-gray-600">{gap.recommendation}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <Brain className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">AI Learning Path</h4>
            <p className="text-sm text-gray-600 mt-1">
              Based on your current skills and career goals, focusing on Cloud Architecture will have the highest impact on your growth trajectory.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}