import React, { useState } from 'react';
import { BookOpen, Search, Filter, Brain, Star } from 'lucide-react';
import { Button } from '../../ui/Button';

interface Course {
  id: number;
  title: string;
  category: string;
  duration: string;
  level: string;
  rating: number;
  enrolled: number;
  aiRecommended: boolean;
  description: string;
}

const courses: Course[] = [
  {
    id: 1,
    title: 'Advanced Leadership Skills',
    category: 'Leadership',
    duration: '8 hours',
    level: 'Intermediate',
    rating: 4.8,
    enrolled: 245,
    aiRecommended: true,
    description: 'Develop essential leadership skills for modern workplace management.'
  },
  {
    id: 2,
    title: 'Project Management Fundamentals',
    category: 'Management',
    duration: '12 hours',
    level: 'Beginner',
    rating: 4.5,
    enrolled: 189,
    aiRecommended: false,
    description: 'Learn the basics of project management methodologies and best practices.'
  },
  {
    id: 3,
    title: 'Communication Excellence',
    category: 'Soft Skills',
    duration: '6 hours',
    level: 'All Levels',
    rating: 4.7,
    enrolled: 312,
    aiRecommended: true,
    description: 'Enhance your communication skills for better workplace collaboration.'
  }
];

export function TrainingCatalog() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filteredCourses = courses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         course.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || course.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Training Catalog</h3>
          <p className="text-sm text-gray-500">Explore available training opportunities</p>
        </div>
        <BookOpen className="h-6 w-6 text-blue-500" />
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex-1 relative">
          <input
            type="text"
            placeholder="Search courses..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          />
          <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>
        <div className="flex gap-4">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="pl-3 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="all">All Categories</option>
            <option value="Leadership">Leadership</option>
            <option value="Management">Management</option>
            <option value="Soft Skills">Soft Skills</option>
          </select>
          <button className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            <Filter className="h-5 w-5 text-gray-400" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map(course => (
          <div
            key={course.id}
            className="border border-gray-200 rounded-lg p-4 hover:border-blue-200 transition-colors"
          >
            <div className="flex items-start justify-between mb-4">
              <div>
                <h4 className="text-sm font-medium text-gray-900">{course.title}</h4>
                <p className="text-xs text-gray-500 mt-1">{course.category}</p>
              </div>
              {course.aiRecommended && (
                <div className="flex items-center text-blue-600 text-xs">
                  <Brain className="h-4 w-4 mr-1" />
                  Recommended
                </div>
              )}
            </div>

            <p className="text-sm text-gray-600 mb-4">{course.description}</p>

            <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                {course.duration}
              </div>
              <div className="flex items-center">
                <Users className="h-4 w-4 mr-1" />
                {course.enrolled} enrolled
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Star className="h-4 w-4 text-yellow-400 mr-1" />
                <span className="text-sm font-medium text-gray-900">{course.rating}</span>
              </div>
              <Button variant="primary">Enroll Now</Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}