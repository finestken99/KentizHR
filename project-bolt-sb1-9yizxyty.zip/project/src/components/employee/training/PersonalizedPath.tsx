import React from 'react';
import { Brain, BookOpen, Award, Star } from 'lucide-react';

const learningPath = [
  {
    title: 'Advanced React Patterns',
    type: 'Course',
    progress: 75,
    duration: '4 weeks',
    status: 'in_progress',
    aiRecommendation: 'High priority - aligns with current project needs'
  },
  {
    title: 'System Design Fundamentals',
    type: 'Certification',
    progress: 45,
    duration: '8 weeks',
    status: 'upcoming',
    aiRecommendation: 'Recommended for career progression'
  },
  {
    title: 'Cloud Architecture',
    type: 'Learning Path',
    progress: 20,
    duration: '12 weeks',
    status: 'planned',
    aiRecommendation: 'Future skill requirement'
  }
];

const statusStyles = {
  in_progress: 'bg-blue-500',
  upcoming: 'bg-yellow-500',
  planned: 'bg-purple-500'
};

export function PersonalizedPath() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Personalized Learning Path</h3>
          <p className="text-sm text-gray-500">AI-curated learning journey</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-6">
        {learningPath.map((item, index) => (
          <div key={index} className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                {item.type === 'Course' ? (
                  <BookOpen className="h-5 w-5 text-blue-500" />
                ) : item.type === 'Certification' ? (
                  <Award className="h-5 w-5 text-yellow-500" />
                ) : (
                  <Star className="h-5 w-5 text-purple-500" />
                )}
                <div>
                  <h4 className="text-sm font-medium text-gray-900">{item.title}</h4>
                  <span className="text-xs text-gray-500">{item.type} • {item.duration}</span>
                </div>
              </div>
            </div>

            <div className="mt-4">
              <div className="flex justify-between text-xs text-gray-500 mb-1">
                <span>Progress</span>
                <span>{item.progress}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full">
                <div
                  className={`h-2 rounded-full ${statusStyles[item.status]}`}
                  style={{ width: `${item.progress}%` }}
                />
              </div>
            </div>

            <div className="mt-4 flex items-start space-x-2 bg-blue-50 p-3 rounded-lg">
              <Brain className="h-4 w-4 text-blue-500 mt-0.5" />
              <p className="text-sm text-gray-600">{item.aiRecommendation}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}