import React from 'react';
import { Brain, Target, TrendingUp } from 'lucide-react';

const needs = [
  {
    skill: 'Cloud Architecture',
    priority: 'high',
    impact: 'Critical for upcoming projects',
    recommendation: 'Focus on AWS certification'
  },
  {
    skill: 'System Design',
    priority: 'medium',
    impact: 'Important for senior role',
    recommendation: 'Complete system design course'
  },
  {
    skill: 'Team Leadership',
    priority: 'low',
    impact: 'Future career growth',
    recommendation: 'Join mentorship program'
  }
];

const priorityStyles = {
  high: 'bg-red-50 border-red-200 text-red-700',
  medium: 'bg-yellow-50 border-yellow-200 text-yellow-700',
  low: 'bg-green-50 border-green-200 text-green-700'
};

export function TrainingNeeds() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Training Needs</h3>
          <p className="text-sm text-gray-500">AI-identified skill requirements</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {needs.map((need, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg border ${priorityStyles[need.priority]}`}
          >
            <div className="flex items-start space-x-3">
              <Target className="h-5 w-5 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium">{need.skill}</h4>
                <p className="text-xs mt-1">{need.impact}</p>
                <div className="mt-2 flex items-center space-x-2">
                  <TrendingUp className="h-4 w-4" />
                  <span className="text-sm">{need.recommendation}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}