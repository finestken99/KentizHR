import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, Brain } from 'lucide-react';

const data = [
  { month: 'Jan', current: 65, predicted: 70 },
  { month: 'Feb', current: 68, predicted: 73 },
  { month: 'Mar', current: 72, predicted: 76 },
  { month: 'Apr', current: 75, predicted: 80 },
  { month: 'May', current: 78, predicted: 83 },
  { month: 'Jun', current: 82, predicted: 88 }
];

export function SkillTrends() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Skill Growth Prediction</h3>
          <p className="text-sm text-gray-500">AI-powered skill trajectory analysis</p>
        </div>
        <TrendingUp className="h-6 w-6 text-blue-500" />
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Line
              type="monotone"
              dataKey="current"
              stroke="#3B82F6"
              strokeWidth={2}
              name="Current Skills"
            />
            <Line
              type="monotone"
              dataKey="predicted"
              stroke="#10B981"
              strokeWidth={2}
              strokeDasharray="5 5"
              name="Predicted Growth"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <Brain className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">AI Growth Insight</h4>
            <p className="text-sm text-gray-600 mt-1">
              Based on your learning patterns, you're projected to achieve advanced proficiency in cloud architecture by Q3 2024.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}