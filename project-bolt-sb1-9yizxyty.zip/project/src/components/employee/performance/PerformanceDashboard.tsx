import React from 'react';
import { Container } from '../../ui/Container';
import { PerformanceOverview } from './PerformanceOverview';
import { GoalTracking } from './GoalTracking';
import { FeedbackAnalysis } from './FeedbackAnalysis';
import { SkillGapAnalysis } from './SkillGapAnalysis';
import { CareerProgression } from './CareerProgression';
import { ReviewDrafts } from './ReviewDrafts';

export function PerformanceDashboard() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Performance Intelligence</h2>
          <p className="mt-2 text-gray-600">
            AI-powered insights and analytics for your professional growth
          </p>
        </div>

        <div className="space-y-8">
          <PerformanceOverview />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <GoalTracking />
            <FeedbackAnalysis />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <SkillGapAnalysis />
            <CareerProgression />
            <ReviewDrafts />
          </div>
        </div>
      </Container>
    </div>
  );
}