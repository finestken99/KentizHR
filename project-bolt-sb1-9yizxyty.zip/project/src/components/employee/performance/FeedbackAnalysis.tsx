import React from 'react';
import { MessageSquare, ThumbsUp, TrendingUp, Star } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const feedbackData = [
  { month: 'Jan', score: 4.2, engagement: 85 },
  { month: 'Feb', score: 4.4, engagement: 88 },
  { month: 'Mar', score: 4.6, engagement: 90 },
  { month: 'Apr', score: 4.5, engagement: 89 },
  { month: 'May', score: 4.8, engagement: 92 },
  { month: 'Jun', score: 4.7, engagement: 91 }
];

const feedbackCategories = [
  {
    category: 'Technical Skills',
    score: 4.8,
    trend: '+0.3',
    icon: Star,
    color: 'text-blue-500',
    bgColor: 'bg-blue-100'
  },
  {
    category: 'Communication',
    score: 4.6,
    trend: '+0.2',
    icon: MessageSquare,
    color: 'text-green-500',
    bgColor: 'bg-green-100'
  },
  {
    category: 'Collaboration',
    score: 4.7,
    trend: '+0.4',
    icon: ThumbsUp,
    color: 'text-purple-500',
    bgColor: 'bg-purple-100'
  },
  {
    category: 'Leadership',
    score: 4.5,
    trend: '+0.5',
    icon: TrendingUp,
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-100'
  }
];

export function FeedbackAnalysis() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Continuous Feedback Analysis</h3>
          <p className="text-sm text-gray-500">AI-powered feedback insights</p>
        </div>
        <MessageSquare className="h-6 w-6 text-blue-500" />
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        {feedbackCategories.map(({ category, score, trend, icon: Icon, color, bgColor }) => (
          <div key={category} className="p-4 rounded-lg border border-gray-100">
            <div className={`w-10 h-10 ${bgColor} rounded-lg flex items-center justify-center mb-3`}>
              <Icon className={`h-5 w-5 ${color}`} />
            </div>
            <div className="text-sm font-medium text-gray-900">{category}</div>
            <div className="mt-1 flex items-baseline">
              <span className="text-2xl font-semibold text-gray-900">{score}</span>
              <span className="ml-2 text-sm text-green-500">{trend}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={feedbackData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis yAxisId="left" domain={[0, 5]} />
            <YAxis yAxisId="right" orientation="right" domain={[0, 100]} />
            <Tooltip />
            <Line
              yAxisId="left"
              type="monotone"
              dataKey="score"
              stroke="#3B82F6"
              name="Feedback Score"
              strokeWidth={2}
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="engagement"
              stroke="#10B981"
              name="Engagement"
              strokeWidth={2}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <Star className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">AI Insight</h4>
            <p className="text-sm text-gray-600 mt-1">
              Your communication and collaboration scores show consistent improvement. Consider sharing your successful practices with team members.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}