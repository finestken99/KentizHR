import React from 'react';
import { Container } from '../../ui/Container';
import { ReviewOverview } from './sections/ReviewOverview';
import { GoalTracking } from './sections/GoalTracking';
import { FeedbackHistory } from './sections/FeedbackHistory';
import { SkillAssessment } from './sections/SkillAssessment';
import { DevelopmentPlan } from './sections/DevelopmentPlan';

export function PerformanceReview() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Performance Review</h2>
          <p className="mt-2 text-gray-600">
            Track your performance and development progress
          </p>
        </div>

        <div className="space-y-8">
          <ReviewOverview />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <GoalTracking />
            <FeedbackHistory />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <SkillAssessment />
            <DevelopmentPlan />
          </div>
        </div>
      </Container>
    </div>
  );
}