import React from 'react';
import { Target, CheckCircle, Clock, AlertCircle } from 'lucide-react';

const goals = [
  {
    title: 'Complete Advanced React Certification',
    progress: 75,
    status: 'on_track',
    dueDate: '2024-06-30',
    priority: 'high'
  },
  {
    title: 'Improve Code Review Response Time',
    progress: 60,
    status: 'at_risk',
    dueDate: '2024-04-15',
    priority: 'medium'
  },
  {
    title: 'Mentor Junior Developers',
    progress: 90,
    status: 'completed',
    dueDate: '2024-03-31',
    priority: 'low'
  }
];

const statusConfig = {
  on_track: { icon: Clock, className: 'text-blue-500' },
  at_risk: { icon: AlertCircle, className: 'text-yellow-500' },
  completed: { icon: CheckCircle, className: 'text-green-500' }
};

export function GoalTracking() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Goal Tracking</h3>
          <p className="text-sm text-gray-500">AI-driven performance goal monitoring</p>
        </div>
        <Target className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {goals.map((goal, index) => {
          const StatusIcon = statusConfig[goal.status].icon;
          return (
            <div
              key={index}
              className="border border-gray-200 rounded-lg p-4"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <StatusIcon className={`h-5 w-5 ${statusConfig[goal.status].className}`} />
                  <span className="text-sm font-medium text-gray-900">{goal.title}</span>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  goal.priority === 'high' 
                    ? 'bg-red-100 text-red-700'
                    : goal.priority === 'medium'
                    ? 'bg-yellow-100 text-yellow-700'
                    : 'bg-green-100 text-green-700'
                }`}>
                  {goal.priority.charAt(0).toUpperCase() + goal.priority.slice(1)}
                </span>
              </div>

              <div className="mt-4">
                <div className="flex justify-between text-sm text-gray-500 mb-1">
                  <span>Progress</span>
                  <span>{goal.progress}%</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full">
                  <div
                    className={`h-2 rounded-full ${
                      goal.status === 'completed'
                        ? 'bg-green-500'
                        : goal.status === 'at_risk'
                        ? 'bg-yellow-500'
                        : 'bg-blue-500'
                    }`}
                    style={{ width: `${goal.progress}%` }}
                  />
                </div>
              </div>

              <div className="mt-2 text-sm text-gray-500">
                Due: {goal.dueDate}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}