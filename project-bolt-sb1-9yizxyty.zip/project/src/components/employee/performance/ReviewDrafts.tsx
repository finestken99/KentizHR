import React from 'react';
import { FileText, Edit, Clock, Brain } from 'lucide-react';

interface ReviewDraft {
  id: number;
  type: string;
  dueDate: string;
  status: 'draft' | 'in_progress' | 'ready';
  completeness: number;
  aiSuggestions: string[];
}

const reviewDrafts: ReviewDraft[] = [
  {
    id: 1,
    type: 'Self Assessment',
    dueDate: '2024-03-31',
    status: 'ready',
    completeness: 100,
    aiSuggestions: [
      'Highlight the successful project delivery',
      'Include mentorship contributions'
    ]
  },
  {
    id: 2,
    type: 'Peer Review',
    dueDate: '2024-04-15',
    status: 'in_progress',
    completeness: 65,
    aiSuggestions: [
      'Add specific collaboration examples',
      'Mention technical leadership'
    ]
  },
  {
    id: 3,
    type: 'Goals Review',
    dueDate: '2024-04-30',
    status: 'draft',
    completeness: 30,
    aiSuggestions: [
      'Include quantifiable achievements',
      'Link goals to company objectives'
    ]
  }
];

const statusConfig = {
  draft: { color: 'text-gray-500', bg: 'bg-gray-100' },
  in_progress: { color: 'text-yellow-500', bg: 'bg-yellow-100' },
  ready: { color: 'text-green-500', bg: 'bg-green-100' }
};

export function ReviewDrafts() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Review Drafts</h3>
          <p className="text-sm text-gray-500">AI-assisted performance reviews</p>
        </div>
        <FileText className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {reviewDrafts.map((draft) => (
          <div
            key={draft.id}
            className="border border-gray-200 rounded-lg p-4 hover:border-gray-300 transition-colors"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-lg ${statusConfig[draft.status].bg}`}>
                  <Edit className={`h-4 w-4 ${statusConfig[draft.status].color}`} />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-900">{draft.type}</h4>
                  <div className="flex items-center mt-1">
                    <Clock className="h-4 w-4 text-gray-400 mr-1" />
                    <span className="text-xs text-gray-500">Due: {draft.dueDate}</span>
                  </div>
                </div>
              </div>
              <span className={`text-xs font-medium px-2 py-1 rounded-full capitalize
                ${statusConfig[draft.status].bg} ${statusConfig[draft.status].color}`}>
                {draft.status.replace('_', ' ')}
              </span>
            </div>

            <div className="mb-4">
              <div className="flex justify-between text-xs text-gray-500 mb-1">
                <span>Completeness</span>
                <span>{draft.completeness}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full">
                <div
                  className="h-2 bg-blue-500 rounded-full"
                  style={{ width: `${draft.completeness}%` }}
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-sm text-gray-900">
                <Brain className="h-4 w-4 text-blue-500" />
                <span className="font-medium">AI Suggestions:</span>
              </div>
              {draft.aiSuggestions.map((suggestion, index) => (
                <div key={index} className="flex items-center space-x-2 ml-6">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                  <span className="text-sm text-gray-600">{suggestion}</span>
                </div>
              ))}
            </div>

            <button className="mt-4 w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">
              <Edit className="h-4 w-4 mr-2" />
              {draft.status === 'ready' ? 'View Draft' : 'Continue Editing'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}