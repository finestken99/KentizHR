import React from 'react';
import { MessageSquare, Star, User } from 'lucide-react';

interface Feedback {
  id: number;
  type: 'manager' | 'peer' | 'self';
  from: string;
  date: string;
  rating: number;
  comment: string;
}

const feedbackHistory: Feedback[] = [
  {
    id: 1,
    type: 'manager',
    from: 'Jane Cooper',
    date: '2024-03-15',
    rating: 4,
    comment: 'Excellent work on the recent project. Shows great leadership potential.'
  },
  {
    id: 2,
    type: 'peer',
    from: 'Alex Thompson',
    date: '2024-03-10',
    rating: 5,
    comment: 'Great team player, always willing to help others.'
  },
  {
    id: 3,
    type: 'self',
    from: 'Self Assessment',
    date: '2024-03-01',
    rating: 4,
    comment: 'Made good progress on technical skills, need to improve presentation skills.'
  }
];

export function FeedbackHistory() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Feedback History</h3>
          <p className="text-sm text-gray-500">Recent performance feedback</p>
        </div>
        <MessageSquare className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {feedbackHistory.map(feedback => (
          <div
            key={feedback.id}
            className="border border-gray-200 rounded-lg p-4"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <User className="h-5 w-5 text-gray-400" />
                <span className="text-sm font-medium text-gray-900">{feedback.from}</span>
                <span className="text-sm text-gray-500">•</span>
                <span className="text-sm text-gray-500">{feedback.type}</span>
              </div>
              <div className="flex">
                {[...Array(5)].map((_, index) => (
                  <Star
                    key={index}
                    className={`h-4 w-4 ${
                      index < feedback.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
            </div>
            <p className="text-sm text-gray-600 mt-2">{feedback.comment}</p>
            <div className="text-xs text-gray-500 mt-2">
              {new Date(feedback.date).toLocaleDateString()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}