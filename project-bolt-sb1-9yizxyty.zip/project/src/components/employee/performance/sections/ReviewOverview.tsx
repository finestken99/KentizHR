import React from 'react';
import { Star, TrendingUp, Target, Award } from 'lucide-react';

const metrics = [
  {
    label: 'Overall Rating',
    value: '4.5/5',
    change: '+0.3',
    icon: Star,
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-100'
  },
  {
    label: 'Goals Achieved',
    value: '85%',
    change: '+12%',
    icon: Target,
    color: 'text-blue-500',
    bgColor: 'bg-blue-100'
  },
  {
    label: 'Skill Growth',
    value: '92%',
    change: '+8%',
    icon: TrendingUp,
    color: 'text-green-500',
    bgColor: 'bg-green-100'
  },
  {
    label: 'Achievements',
    value: '12',
    change: '+3',
    icon: Award,
    color: 'text-purple-500',
    bgColor: 'bg-purple-100'
  }
];

export function ReviewOverview() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metrics.map(({ label, value, change, icon: Icon, color, bgColor }) => (
        <div key={label} className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center space-x-4">
            <div className={`${bgColor} p-3 rounded-lg`}>
              <Icon className={`h-6 w-6 ${color}`} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">{label}</p>
              <div className="flex items-baseline">
                <p className="text-2xl font-semibold text-gray-900">{value}</p>
                <span className={`ml-2 text-sm ${
                  change.startsWith('+') ? 'text-green-500' : 'text-red-500'
                }`}>
                  {change}
                </span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}