```tsx
import React from 'react';
import { DollarSign, FileText, Download, Calendar } from 'lucide-react';
import { Button } from '../../ui/Button';

interface Paystub {
  id: number;
  date: string;
  amount: number;
  type: string;
  status: 'processed' | 'pending';
}

const recentPaystubs: Paystub[] = [
  {
    id: 1,
    date: '2024-03-15',
    amount: 3500,
    type: 'Regular',
    status: 'processed'
  },
  {
    id: 2,
    date: '2024-02-29',
    amount: 3500,
    type: 'Regular',
    status: 'processed'
  },
  {
    id: 3,
    date: '2024-02-15',
    amount: 3500,
    type: 'Regular',
    status: 'processed'
  }
];

export function PayrollInformation() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Payroll Information</h3>
          <p className="text-sm text-gray-500">View and download your pay information</p>
        </div>
        <DollarSign className="h-6 w-6 text-blue-500" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="p-4 bg-blue-50 rounded-lg">
          <div className="text-sm text-gray-600">Next Pay Date</div>
          <div className="mt-1 flex items-center">
            <Calendar className="h-4 w-4 text-blue-500 mr-2" />
            <span className="text-lg font-semibold text-gray-900">Mar 31, 2024</span>
          </div>
        </div>

        <div className="p-4 bg-green-50 rounded-lg">
          <div className="text-sm text-gray-600">YTD Earnings</div>
          <div className="mt-1 flex items-center">
            <DollarSign className="h-4 w-4 text-green-500 mr-2" />
            <span className="text-lg font-semibold text-gray-900">$10,500.00</span>
          </div>
        </div>

        <div className="p-4 bg-purple-50 rounded-lg">
          <div className="text-sm text-gray-600">Direct Deposit</div>
          <div className="mt-1 flex items-center">
            <FileText className="h-4 w-4 text-purple-500 mr-2" />
            <span className="text-lg font-semibold text-gray-900">Active</span>
          </div>
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-sm font-medium text-gray-900">Recent Paystubs</h4>
          <Button variant="secondary">
            <FileText className="h-4 w-4 mr-2" />
            Tax Documents
          </Button>
        </div>

        <div className="space-y-4">
          {recentPaystubs.map(paystub => (
            <div
              key={paystub.id}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div>
                <div className="text-sm font-medium text-gray-900">
                  {new Date(paystub.date).toLocaleDateString('en-US', {
                    month: 'long',
                    day: 'numeric',
                    year: 'numeric'
                  })}
                </div>
                <div className="text-sm text-gray-500 mt-1">
                  {paystub.type} Pay • ${paystub.amount.toLocaleString()}
                </div>
              </div>
              <Button variant="secondary">
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
```