import React from 'react';
import { Receipt, CheckCircle, Clock, AlertCircle } from 'lucide-react';

const expenses = [
  {
    id: 1,
    description: 'Conference Travel',
    amount: 850,
    status: 'approved',
    date: '2024-03-15'
  },
  {
    id: 2,
    description: 'Training Materials',
    amount: 250,
    status: 'pending',
    date: '2024-03-18'
  },
  {
    id: 3,
    description: 'Office Supplies',
    amount: 120,
    status: 'processing',
    date: '2024-03-20'
  }
];

const statusConfig = {
  approved: { icon: CheckCircle, className: 'text-green-500' },
  pending: { icon: Clock, className: 'text-yellow-500' },
  processing: { icon: AlertCircle, className: 'text-blue-500' }
};

export function ExpenseManagement() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Expense Tracking</h3>
          <p className="text-sm text-gray-500">Automated expense management</p>
        </div>
        <Receipt className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {expenses.map((expense) => {
          const StatusIcon = statusConfig[expense.status].icon;
          return (
            <div
              key={expense.id}
              className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
            >
              <div className="flex items-center space-x-4">
                <Receipt className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-900">
                    {expense.description}
                  </p>
                  <p className="text-sm text-gray-500">
                    {new Date(expense.date).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <span className="text-sm font-medium text-gray-900">
                  ${expense.amount}
                </span>
                <StatusIcon className={`h-5 w-5 ${statusConfig[expense.status].className}`} />
              </div>
            </div>
          );
        })}
      </div>

      <button className="mt-6 w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors">
        <Receipt className="h-4 w-4 mr-2" />
        Submit New Expense
      </button>
    </div>
  );
}