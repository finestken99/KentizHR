```tsx
import React, { useState } from 'react';
import { CreditCard, Building2, DollarSign, Percent } from 'lucide-react';
import { Button } from '../../ui/Button';
import { FormField } from '../../ui/FormField';

interface BankAccount {
  id: number;
  accountType: string;
  routingNumber: string;
  accountNumber: string;
  allocation: number;
  isPrimary: boolean;
}

export function DirectDepositSetup() {
  const [accounts, setAccounts] = useState<BankAccount[]>([{
    id: 1,
    accountType: '',
    routingNumber: '',
    accountNumber: '',
    allocation: 100,
    isPrimary: true
  }]);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleAddAccount = () => {
    setAccounts(prev => [...prev, {
      id: Date.now(),
      accountType: '',
      routingNumber: '',
      accountNumber: '',
      allocation: 0,
      isPrimary: false
    }]);
  };

  const handleRemoveAccount = (id: number) => {
    setAccounts(prev => prev.filter(account => account.id !== id));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSuccess(false);

    try {
      // API call to update direct deposit information would go here
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulated API call
      setSuccess(true);
    } catch (error) {
      console.error('Error updating direct deposit:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Direct Deposit Setup</h3>
          <p className="text-sm text-gray-500">Manage your payment preferences</p>
        </div>
        <CreditCard className="h-6 w-6 text-blue-500" />
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {accounts.map((account, index) => (
          <div key={account.id} className="border-b border-gray-200 pb-6 last:border-0">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-sm font-medium text-gray-900">
                {account.isPrimary ? 'Primary Account' : `Account ${index + 1}`}
              </h4>
              {!account.isPrimary && (
                <button
                  type="button"
                  onClick={() => handleRemoveAccount(account.id)}
                  className="text-red-600 hover:text-red-700 text-sm"
                >
                  Remove
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                label="Account Type"
                name={`account-${account.id}-type`}
                type="select"
                value={account.accountType}
                onChange={(e) => setAccounts(prev => prev.map(item => 
                  item.id === account.id ? { ...item, accountType: e.target.value } : item
                ))}
                icon={Building2}
                required
                disabled={loading}
                options={[
                  { value: '', label: 'Select account type' },
                  { value: 'checking', label: 'Checking' },
                  { value: 'savings', label: 'Savings' }
                ]}
              />

              <FormField
                label="Routing Number"
                name={`account-${account.id}-routing`}
                value={account.routingNumber}
                onChange={(e) => setAccounts(prev => prev.map(item => 
                  item.id === account.id ? { ...item, routingNumber: e.target.value } : item
                ))}
                icon={DollarSign}
                required
                disabled={loading}
              />

              <FormField
                label="Account Number"
                name={`account-${account.id}-number`}
                value={account.accountNumber}
                onChange={(e) => setAccounts(prev => prev.map(item => 
                  item.id === account.id ? { ...item, accountNumber: e.target.value } : item
                ))}
                icon={CreditCard}
                required
                disabled={loading}
              />

              <FormField
                label="Allocation Percentage"
                name={`account-${account.id}-allocation`}
                type="number"
                value={account.allocation.toString()}
                onChange={(e) => setAccounts(prev => prev.map(item => 
                  item.id === account.id ? { ...item, allocation: parseInt(e.target.value) } : item
                ))}
                icon={Percent}
                required
                disabled={loading || account.isPrimary}
                min="0"
                max="100"
              />
            </div>
          </div>
        ))}

        {accounts.length < 3 && (
          <Button
            variant="secondary"
            type="button"
            onClick={handleAddAccount}
            disabled={loading}
          >
            Add Another Account
          </Button>
        )}

        {success && (
          <div className="bg-green-50 text-green-700 p-3 rounded-md">
            Direct deposit information updated successfully
          </div>
        )}

        <div className="flex justify-end">
          <Button
            variant="primary"
            type="submit"
            disabled={loading}
          >
            {loading ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </form>
    </div>
  );
}
```