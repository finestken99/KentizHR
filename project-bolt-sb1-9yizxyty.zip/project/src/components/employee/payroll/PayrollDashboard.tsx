import React from 'react';
import { Container } from '../../ui/Container';
import { PayrollOverview } from './PayrollOverview';
import { CompensationBenchmark } from './CompensationBenchmark';
import { TaxOptimization } from './TaxOptimization';
import { PayrollAnalytics } from './PayrollAnalytics';
import { BenefitsRecommendation } from './BenefitsRecommendation';
import { ExpenseManagement } from './ExpenseManagement';

export function PayrollDashboard() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Smart Payroll Intelligence</h2>
          <p className="mt-2 text-gray-600">
            AI-powered compensation and benefits management
          </p>
        </div>

        <div className="space-y-8">
          <PayrollOverview />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <CompensationBenchmark />
            <PayrollAnalytics />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <TaxOptimization />
            <BenefitsRecommendation />
            <ExpenseManagement />
          </div>
        </div>
      </Container>
    </div>
  );
}