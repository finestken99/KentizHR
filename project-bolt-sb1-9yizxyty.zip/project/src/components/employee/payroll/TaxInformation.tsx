```tsx
import React, { useState } from 'react';
import { FileText, Download, AlertTriangle } from 'lucide-react';
import { Button } from '../../ui/Button';

interface TaxDocument {
  id: number;
  type: string;
  year: number;
  status: 'available' | 'processing';
  dateIssued?: string;
}

const taxDocuments: TaxDocument[] = [
  {
    id: 1,
    type: 'W-2',
    year: 2023,
    status: 'available',
    dateIssued: '2024-01-31'
  },
  {
    id: 2,
    type: 'W-2',
    year: 2022,
    status: 'available',
    dateIssued: '2023-01-31'
  },
  {
    id: 3,
    type: '1095-C',
    year: 2023,
    status: 'available',
    dateIssued: '2024-01-31'
  }
];

export function TaxInformation() {
  const [loading, setLoading] = useState(false);

  const handleDownload = async (documentId: number) => {
    setLoading(true);
    try {
      // API call to download tax document would go here
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulated API call
      console.log(`Downloading document ${documentId}`);
    } catch (error) {
      console.error('Error downloading document:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Tax Information</h3>
          <p className="text-sm text-gray-500">Access your tax documents</p>
        </div>
        <FileText className="h-6 w-6 text-blue-500" />
      </div>

      <div className="mb-8 p-4 bg-yellow-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">Tax Withholding Notice</h4>
            <p className="text-sm text-gray-600 mt-1">
              Please review your W-4 information to ensure your tax withholdings are correct.
            </p>
            <Button variant="secondary" className="mt-3">
              Review W-4
            </Button>
          </div>
        </div>
      </div>

      <div>
        <h4 className="text-sm font-medium text-gray-900 mb-4">Available Documents</h4>
        <div className="space-y-4">
          {taxDocuments.map(doc => (
            <div
              key={doc.id}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div>
                <div className="flex items-center space-x-2">
                  <FileText className="h-5 w-5 text-gray-400" />
                  <span className="text-sm font-medium text-gray-900">
                    {doc.type} - {doc.year}
                  </span>
                </div>
                {doc.dateIssued && (
                  <p className="text-sm text-gray-500 mt-1">
                    Issued: {new Date(doc.dateIssued).toLocaleDateString()}
                  </p>
                )}
              </div>
              <Button
                variant="secondary"
                onClick={() => handleDownload(doc.id)}
                disabled={loading || doc.status !== 'available'}
              >
                <Download className="h-4 w-4 mr-2" />
                {doc.status === 'available' ? 'Download' : 'Processing'}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
```