import React from 'react';
import { Brain, Heart, Shield, Umbrella } from 'lucide-react';

const benefits = [
  {
    type: 'Health Insurance',
    current: 'PPO Basic',
    recommendation: 'PPO Plus',
    savings: '$450/year',
    icon: Heart
  },
  {
    type: 'Life Insurance',
    current: '$100k Coverage',
    recommendation: '$250k Coverage',
    savings: 'Enhanced Protection',
    icon: Shield
  },
  {
    type: 'Disability',
    current: 'Not Enrolled',
    recommendation: 'Short-term Plan',
    savings: 'Risk Mitigation',
    icon: Umbrella
  }
];

export function BenefitsRecommendation() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Benefits Optimization</h3>
          <p className="text-sm text-gray-500">Personalized benefits recommendations</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="space-y-4">
        {benefits.map((benefit, index) => {
          const Icon = benefit.icon;
          return (
            <div
              key={index}
              className="p-4 border border-gray-200 rounded-lg hover:border-blue-200 transition-colors"
            >
              <div className="flex items-start space-x-3">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <Icon className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-900">{benefit.type}</h4>
                  <div className="mt-1 space-y-1">
                    <p className="text-sm text-gray-500">
                      Current: <span className="text-gray-700">{benefit.current}</span>
                    </p>
                    <p className="text-sm text-blue-600">
                      Recommended: {benefit.recommendation}
                    </p>
                    <p className="text-sm text-green-600">
                      Potential Impact: {benefit.savings}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}