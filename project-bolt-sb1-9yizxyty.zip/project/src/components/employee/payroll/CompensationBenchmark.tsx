import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Brain, DollarSign } from 'lucide-react';

const data = [
  { role: 'Your Position', salary: 85000, market: 82000 },
  { role: 'Industry Avg', salary: 82000, market: 82000 },
  { role: 'Top 25%', salary: 95000, market: 82000 },
  { role: 'Top 10%', salary: 105000, market: 82000 }
];

export function CompensationBenchmark() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Compensation Benchmark</h3>
          <p className="text-sm text-gray-500">AI-powered market comparison</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="role" />
            <YAxis />
            <Tooltip 
              formatter={(value) => `$${value.toLocaleString()}`}
              labelFormatter={(label) => `Role: ${label}`}
            />
            <Bar dataKey="salary" name="Salary" fill="#3B82F6" />
            <Bar dataKey="market" name="Market Rate" fill="#10B981" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <div className="flex items-start space-x-3">
          <DollarSign className="h-5 w-5 text-blue-500 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900">Market Position</h4>
            <p className="text-sm text-gray-600 mt-1">
              Your compensation is 3.7% above market rate for your role and experience level.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}