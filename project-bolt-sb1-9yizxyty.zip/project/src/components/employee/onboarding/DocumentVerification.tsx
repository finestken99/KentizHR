import React from 'react';
import { FileCheck, Upload, AlertCircle } from 'lucide-react';

interface Document {
  id: number;
  name: string;
  status: 'verified' | 'pending' | 'rejected';
  message?: string;
}

const documents: Document[] = [
  {
    id: 1,
    name: 'ID Proof',
    status: 'verified'
  },
  {
    id: 2,
    name: 'Employment Contract',
    status: 'pending'
  },
  {
    id: 3,
    name: 'Tax Declaration Form',
    status: 'rejected',
    message: 'Please provide a signed copy'
  }
];

const statusConfig = {
  verified: { icon: FileCheck, className: 'text-green-500', bg: 'bg-green-50' },
  pending: { icon: Clock, className: 'text-yellow-500', bg: 'bg-yellow-50' },
  rejected: { icon: AlertCircle, className: 'text-red-500', bg: 'bg-red-50' }
};

export function DocumentVerification() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900">Document Verification</h3>
        <p className="text-sm text-gray-500">Upload and track your document verification status</p>
      </div>

      <div className="p-4">
        <div className="grid gap-4">
          {documents.map((doc) => {
            const StatusIcon = statusConfig[doc.status].icon;
            return (
              <div
                key={doc.id}
                className={`p-4 rounded-lg ${statusConfig[doc.status].bg}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <StatusIcon className={`h-5 w-5 ${statusConfig[doc.status].className}`} />
                    <div>
                      <p className="text-sm font-medium text-gray-900">{doc.name}</p>
                      {doc.message && (
                        <p className="text-xs text-red-600 mt-1">{doc.message}</p>
                      )}
                    </div>
                  </div>
                  {doc.status !== 'verified' && (
                    <button className="flex items-center space-x-2 text-sm text-blue-600 hover:text-blue-700">
                      <Upload className="h-4 w-4" />
                      <span>Upload</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}