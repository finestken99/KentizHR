import React from 'react';
import { BookOpen, Play, Award } from 'lucide-react';

interface Course {
  id: number;
  title: string;
  duration: string;
  progress: number;
  type: 'required' | 'recommended';
}

const courses: Course[] = [
  {
    id: 1,
    title: 'Company Culture & Values',
    duration: '30 min',
    progress: 100,
    type: 'required'
  },
  {
    id: 2,
    title: 'Security Best Practices',
    duration: '45 min',
    progress: 60,
    type: 'required'
  },
  {
    id: 3,
    title: 'Role-specific Training',
    duration: '2 hours',
    progress: 0,
    type: 'recommended'
  }
];

export function LearningPath() {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900">Learning Path</h3>
        <p className="text-sm text-gray-500">Personalized training for your role</p>
      </div>

      <div className="p-4">
        <div className="space-y-4">
          {courses.map((course) => (
            <div key={course.id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-50 rounded-lg">
                    <BookOpen className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-900">{course.title}</h4>
                    <p className="text-xs text-gray-500">Duration: {course.duration}</p>
                  </div>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  course.type === 'required' 
                    ? 'bg-red-100 text-red-800' 
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {course.type}
                </span>
              </div>

              <div className="mt-4">
                <div className="flex justify-between text-xs text-gray-500 mb-1">
                  <span>Progress</span>
                  <span>{course.progress}%</span>
                </div>
                <div className="h-2 bg-gray-200 rounded-full">
                  <div
                    className="h-2 bg-blue-600 rounded-full"
                    style={{ width: `${course.progress}%` }}
                  />
                </div>
              </div>

              <div className="mt-4 flex justify-between items-center">
                {course.progress === 100 ? (
                  <div className="flex items-center text-green-600 text-sm">
                    <Award className="h-4 w-4 mr-1" />
                    Completed
                  </div>
                ) : (
                  <button className="flex items-center text-blue-600 hover:text-blue-700 text-sm">
                    <Play className="h-4 w-4 mr-1" />
                    {course.progress > 0 ? 'Continue' : 'Start'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}