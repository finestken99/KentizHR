import React from 'react';
import { 
  Home,
  FileText,
  Calendar,
  Award,
  BookOpen,
  DollarSign,
  MessageSquare,
  Settings,
  User,
  Briefcase,
  Building2
} from 'lucide-react';
import { useHash } from '../../hooks/useHash';

const menuItems = [
  { icon: Home, label: 'Overview', href: '#dashboard/overview' },
  { icon: User, label: 'Profile', href: '#dashboard/profile' },
  { icon: FileText, label: 'Documents', href: '#dashboard/documents' },
  { icon: Calendar, label: 'Leave Management', href: '#dashboard/leave' },
  { icon: Award, label: 'Performance', href: '#dashboard/performance' },
  { icon: BookOpen, label: 'Training', href: '#dashboard/training' },
  { icon: DollarSign, label: 'Payroll', href: '#dashboard/payroll' },
  { icon: MessageSquare, label: 'Queries', href: '#dashboard/queries' },
  { icon: Building2, label: 'Company', href: '#dashboard/company' },
  { icon: Settings, label: 'Settings', href: '#dashboard/settings' }
];

export function EmployeeSidebar() {
  const currentHash = useHash();

  return (
    <aside className="w-64 bg-gray-800 min-h-screen">
      <nav className="mt-5 px-2">
        <div className="space-y-1">
          {menuItems.map(({ icon: Icon, label, href }) => (
            <a
              key={label}
              href={href}
              className={`
                group flex items-center px-2 py-2 text-base font-medium rounded-md
                ${currentHash === href
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }
              `}
            >
              <Icon className="mr-4 h-6 w-6" />
              {label}
            </a>
          ))}
        </div>
      </nav>
    </aside>
  );
}