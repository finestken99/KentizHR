import React from 'react';
import { FileText, CheckCircle, Clock, AlertCircle } from 'lucide-react';

const documents = [
  {
    title: 'Tax Declaration Form',
    status: 'approved',
    date: '2024-03-10'
  },
  {
    title: 'Insurance Renewal',
    status: 'pending',
    date: '2024-03-12'
  },
  {
    title: 'Training Certificate',
    status: 'action_required',
    date: '2024-03-14'
  }
];

const statusIcons = {
  approved: { icon: CheckCircle, className: 'text-green-500' },
  pending: { icon: Clock, className: 'text-yellow-500' },
  action_required: { icon: AlertCircle, className: 'text-red-500' }
};

export function DocumentStatus() {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Document Status</h3>
      <div className="space-y-4">
        {documents.map((doc) => {
          const StatusIcon = statusIcons[doc.status].icon;
          return (
            <div
              key={doc.title}
              className="flex items-center justify-between p-3 rounded-lg bg-gray-50"
            >
              <div className="flex items-center space-x-3">
                <FileText className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="font-medium text-gray-900">{doc.title}</p>
                  <p className="text-sm text-gray-500">{doc.date}</p>
                </div>
              </div>
              <StatusIcon className={`h-5 w-5 ${statusIcons[doc.status].className}`} />
            </div>
          );
        })}
      </div>
    </div>
  );
}