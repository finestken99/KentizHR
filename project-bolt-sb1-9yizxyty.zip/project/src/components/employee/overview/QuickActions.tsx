import React from 'react';
import { 
  FileText, 
  Calendar, 
  Clock,
  MessageSquare 
} from 'lucide-react';

const actions = [
  {
    icon: Calendar,
    label: 'Request Leave',
    href: '#dashboard/leave/request',
    color: 'bg-blue-500'
  },
  {
    icon: FileText,
    label: 'Submit Document',
    href: '#dashboard/documents/upload',
    color: 'bg-green-500'
  },
  {
    icon: Clock,
    label: 'Log Time',
    href: '#dashboard/timesheet',
    color: 'bg-purple-500'
  },
  {
    icon: MessageSquare,
    label: 'Raise Query',
    href: '#dashboard/queries/new',
    color: 'bg-orange-500'
  }
];

export function QuickActions() {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
      <div className="grid grid-cols-2 gap-4">
        {actions.map(({ icon: Icon, label, href, color }) => (
          <a
            key={label}
            href={href}
            className="flex flex-col items-center p-4 rounded-lg border-2 border-gray-100 hover:border-gray-200 transition-colors"
          >
            <div className={`p-3 rounded-full ${color} text-white mb-3`}>
              <Icon className="h-6 w-6" />
            </div>
            <span className="text-sm font-medium text-gray-900">{label}</span>
          </a>
        ))}
      </div>
    </div>
  );
}