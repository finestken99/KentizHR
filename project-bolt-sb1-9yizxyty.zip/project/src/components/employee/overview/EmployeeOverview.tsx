import React from 'react';
import { AnalyticsOverview } from './insights/AnalyticsOverview';

export function EmployeeOverview() {
  return (
    <div className="py-8">
      <AnalyticsOverview />
    </div>
  );
}