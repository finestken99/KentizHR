import React from 'react';
import { Container } from '../../../ui/Container';
import { WorkforceAnalytics } from './WorkforceAnalytics';
import { EngagementHeatmap } from './EngagementHeatmap';
import { OrganizationalHealth } from './OrganizationalHealth';
import { ExecutiveSummary } from './ExecutiveSummary';
import { TrendAnalysis } from './TrendAnalysis';
import { WorkforcePlanning } from './WorkforcePlanning';
import { RiskDetection } from './RiskDetection';

export function AnalyticsOverview() {
  return (
    <div className="py-8">
      <Container>
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Organizational Insights</h2>
          <p className="mt-2 text-gray-600">
            AI-powered analytics and predictions for informed decision-making
          </p>
        </div>

        <div className="space-y-8">
          <ExecutiveSummary />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <WorkforceAnalytics />
            <EngagementHeatmap />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <OrganizationalHealth />
            <TrendAnalysis />
            <WorkforcePlanning />
          </div>

          <RiskDetection />
        </div>
      </Container>
    </div>
  );
}