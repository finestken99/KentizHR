import React from 'react';
import { Heart, TrendingUp, TrendingDown } from 'lucide-react';

const departments = ['Engineering', 'Sales', 'Marketing', 'HR', 'Finance'];
const metrics = ['Satisfaction', 'Productivity', 'Collaboration', 'Growth'];

const generateHeatmapData = () => {
  const data: Record<string, Record<string, { score: number; trend: 'up' | 'down' }>> = {};
  departments.forEach(dept => {
    data[dept] = {};
    metrics.forEach(metric => {
      data[dept][metric] = {
        score: Math.floor(Math.random() * 100),
        trend: Math.random() > 0.5 ? 'up' : 'down'
      };
    });
  });
  return data;
};

const heatmapData = generateHeatmapData();

export function EngagementHeatmap() {
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'bg-green-100 text-green-800';
    if (score >= 60) return 'bg-blue-100 text-blue-800';
    if (score >= 40) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Engagement Heatmap</h3>
          <p className="text-sm text-gray-500">Real-time employee engagement metrics</p>
        </div>
        <Heart className="h-6 w-6 text-red-500" />
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full">
          <thead>
            <tr>
              <th className="px-4 py-2 text-left text-sm font-medium text-gray-500">Department</th>
              {metrics.map(metric => (
                <th key={metric} className="px-4 py-2 text-left text-sm font-medium text-gray-500">
                  {metric}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {departments.map(dept => (
              <tr key={dept}>
                <td className="px-4 py-2 text-sm font-medium text-gray-900">{dept}</td>
                {metrics.map(metric => {
                  const { score, trend } = heatmapData[dept][metric];
                  return (
                    <td key={metric} className="px-4 py-2">
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getScoreColor(score)}`}>
                          {score}%
                        </span>
                        {trend === 'up' ? (
                          <TrendingUp className="h-4 w-4 text-green-500" />
                        ) : (
                          <TrendingDown className="h-4 w-4 text-red-500" />
                        )}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}