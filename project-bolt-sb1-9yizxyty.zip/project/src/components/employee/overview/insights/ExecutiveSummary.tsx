import React from 'react';
import { Brain, AlertCircle, TrendingUp, Award } from 'lucide-react';

const insights = [
  {
    type: 'highlight',
    content: 'Employee engagement has increased by 15% across all departments',
    icon: TrendingUp,
    color: 'text-green-500',
    bgColor: 'bg-green-50'
  },
  {
    type: 'action',
    content: 'Consider implementing flexible work arrangements based on productivity patterns',
    icon: Brain,
    color: 'text-blue-500',
    bgColor: 'bg-blue-50'
  },
  {
    type: 'alert',
    content: 'IT department showing signs of increased turnover risk',
    icon: AlertCircle,
    color: 'text-red-500',
    bgColor: 'bg-red-50'
  },
  {
    type: 'achievement',
    content: 'Company-wide training completion rate exceeds industry average by 23%',
    icon: Award,
    color: 'text-purple-500',
    bgColor: 'bg-purple-50'
  }
];

export function ExecutiveSummary() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">AI-Generated Executive Summary</h3>
          <p className="text-sm text-gray-500">Key insights and recommendations</p>
        </div>
        <Brain className="h-6 w-6 text-blue-500" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {insights.map((insight, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg ${insight.bgColor} border border-${insight.color}`}
          >
            <div className="flex items-start space-x-3">
              <div className={`mt-1 ${insight.color}`}>
                <insight.icon className="h-5 w-5" />
              </div>
              <div>
                <div className="text-sm font-medium text-gray-900">{insight.content}</div>
                <div className={`text-xs mt-1 capitalize ${insight.color}`}>{insight.type}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}