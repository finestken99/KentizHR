import React from 'react';
import { AlertTriangle, TrendingDown, Users, DollarSign } from 'lucide-react';

const risks = [
  {
    category: 'Turnover Risk',
    level: 'high',
    description: 'IT department showing elevated attrition indicators',
    impact: 'High impact on project delivery',
    icon: Users
  },
  {
    category: 'Engagement Risk',
    level: 'medium',
    description: 'Declining participation in team activities',
    impact: 'Moderate impact on collaboration',
    icon: TrendingDown
  },
  {
    category: 'Budget Risk',
    level: 'low',
    description: 'Training budget utilization below target',
    impact: 'Low impact on operations',
    icon: DollarSign
  }
];

const riskStyles = {
  high: 'bg-red-50 border-red-200',
  medium: 'bg-yellow-50 border-yellow-200',
  low: 'bg-green-50 border-green-200'
};

export function RiskDetection() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Risk Detection</h3>
          <p className="text-sm text-gray-500">Automated anomaly and risk detection</p>
        </div>
        <AlertTriangle className="h-6 w-6 text-yellow-500" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {risks.map((risk, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg border ${riskStyles[risk.level]}`}
          >
            <div className="flex items-start space-x-3">
              <risk.icon className="h-5 w-5 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium">{risk.category}</h4>
                <p className="text-sm mt-1">{risk.description}</p>
                <p className="text-xs mt-2 text-gray-500">{risk.impact}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}