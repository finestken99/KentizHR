import React from 'react';
import { Calendar } from 'lucide-react';

const events = [
  {
    title: 'Team Meeting',
    date: '2024-03-15',
    time: '10:00 AM',
    type: 'meeting'
  },
  {
    title: 'Performance Review',
    date: '2024-03-20',
    time: '2:00 PM',
    type: 'review'
  },
  {
    title: 'Training Session',
    date: '2024-03-22',
    time: '11:00 AM',
    type: 'training'
  }
];

export function UpcomingEvents() {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Upcoming Events</h3>
      <div className="space-y-4">
        {events.map((event) => (
          <div
            key={event.title}
            className="flex items-start space-x-4 p-3 rounded-lg bg-gray-50"
          >
            <div className="flex-shrink-0">
              <Calendar className="h-6 w-6 text-blue-500" />
            </div>
            <div>
              <p className="font-medium text-gray-900">{event.title}</p>
              <p className="text-sm text-gray-500">
                {event.date} at {event.time}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}