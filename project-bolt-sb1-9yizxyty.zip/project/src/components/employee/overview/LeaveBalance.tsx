import React from 'react';
import { Calendar } from 'lucide-react';

const leaveTypes = [
  {
    type: 'Annual Leave',
    used: 5,
    total: 20,
    color: 'bg-blue-500'
  },
  {
    type: 'Sick Leave',
    used: 2,
    total: 10,
    color: 'bg-green-500'
  },
  {
    type: 'Personal Leave',
    used: 1,
    total: 5,
    color: 'bg-purple-500'
  }
];

export function LeaveBalance() {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Leave Balance</h3>
      <div className="space-y-4">
        {leaveTypes.map((leave) => {
          const percentage = (leave.used / leave.total) * 100;
          return (
            <div key={leave.type} className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-900">
                  {leave.type}
                </span>
                <span className="text-sm text-gray-500">
                  {leave.used} / {leave.total} days
                </span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full">
                <div
                  className={`h-2 rounded-full ${leave.color}`}
                  style={{ width: `${percentage}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
      <button
        className="mt-6 w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
        onClick={() => window.location.hash = '#dashboard/leave/request'}
      >
        <Calendar className="h-5 w-5 mr-2" />
        Request Leave
      </button>
    </div>
  );
}