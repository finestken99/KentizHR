import React from 'react';
import { FileText, Lock, Share2, MoreVertical, Eye } from 'lucide-react';

interface Document {
  id: number;
  name: string;
  type: string;
  size: string;
  modified: string;
  status: 'confidential' | 'shared' | 'public';
  tags: string[];
}

const documents: Document[] = [
  {
    id: 1,
    name: 'Employee Handbook 2024',
    type: 'PDF',
    size: '2.4 MB',
    modified: '2024-03-15',
    status: 'public',
    tags: ['HR', 'Policy']
  },
  {
    id: 2,
    name: 'Performance Review Q1',
    type: 'DOCX',
    size: '1.8 MB',
    modified: '2024-03-14',
    status: 'confidential',
    tags: ['Review', 'Personal']
  },
  {
    id: 3,
    name: 'Project Proposal',
    type: 'PPTX',
    size: '4.2 MB',
    modified: '2024-03-13',
    status: 'shared',
    tags: ['Project', 'Team']
  }
];

const statusConfig = {
  confidential: { icon: Lock, className: 'text-red-500' },
  shared: { icon: Share2, className: 'text-blue-500' },
  public: { icon: Eye, className: 'text-green-500' }
};

export function DocumentGrid() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {documents.map(doc => {
        const StatusIcon = statusConfig[doc.status].icon;
        return (
          <div
            key={doc.id}
            className="bg-white rounded-lg shadow-sm p-4 border border-gray-200 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <FileText className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-900">{doc.name}</h3>
                  <p className="text-xs text-gray-500">
                    {doc.type} • {doc.size}
                  </p>
                </div>
              </div>
              <button className="p-1 hover:bg-gray-100 rounded">
                <MoreVertical className="h-4 w-4 text-gray-400" />
              </button>
            </div>

            <div className="mt-4 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <StatusIcon className={`h-4 w-4 ${statusConfig[doc.status].className}`} />
                <span className="text-xs text-gray-500 capitalize">{doc.status}</span>
              </div>
              <span className="text-xs text-gray-500">
                Modified {new Date(doc.modified).toLocaleDateString()}
              </span>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {doc.tags.map(tag => (
                <span
                  key={tag}
                  className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}