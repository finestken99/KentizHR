import React from 'react';
import { FileText, Upload, Download, Share2, Clock } from 'lucide-react';

const activities = [
  {
    id: 1,
    type: 'upload',
    user: 'John Smith',
    document: 'Project Report.pdf',
    timestamp: '2 hours ago',
    icon: Upload,
    color: 'text-green-500',
    bgColor: 'bg-green-100'
  },
  {
    id: 2,
    type: 'download',
    user: 'Sarah Johnson',
    document: 'Meeting Notes.docx',
    timestamp: '4 hours ago',
    icon: Download,
    color: 'text-blue-500',
    bgColor: 'bg-blue-100'
  },
  {
    id: 3,
    type: 'share',
    user: 'Mike Wilson',
    document: 'Budget Plan.xlsx',
    timestamp: '1 day ago',
    icon: Share2,
    color: 'text-purple-500',
    bgColor: 'bg-purple-100'
  }
];

export function DocumentActivity() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-medium text-gray-900">Recent Activity</h3>
        <Clock className="h-5 w-5 text-gray-400" />
      </div>

      <div className="space-y-4">
        {activities.map(activity => (
          <div key={activity.id} className="flex items-start space-x-3">
            <div className={`p-2 rounded-lg ${activity.bgColor}`}>
              <activity.icon className={`h-4 w-4 ${activity.color}`} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm text-gray-900">
                <span className="font-medium">{activity.user}</span>
                {' '}
                {activity.type === 'upload' && 'uploaded'}
                {activity.type === 'download' && 'downloaded'}
                {activity.type === 'share' && 'shared'}
                {' '}
                <span className="font-medium">{activity.document}</span>
              </p>
              <p className="text-xs text-gray-500 mt-1">{activity.timestamp}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}