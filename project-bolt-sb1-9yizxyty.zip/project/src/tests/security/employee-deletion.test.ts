import { describe, it, expect } from 'vitest';
import { employeeService } from '../../lib/services/employeeService';
import { authMiddleware } from '../../lib/api/middleware/auth';
import { UserRole } from '../../lib/auth/types';

describe('Employee Deletion Security', () => {
  it('prevents unauthorized deletion', async () => {
    const req = {
      user: { role: UserRole.EMPLOYEE },
      params: { id: '1' }
    };
    const res = {
      status: (code: number) => ({
        json: (data: any) => ({ code, data })
      })
    };
    const next = () => {};

    const result = await authMiddleware([UserRole.ADMIN])(req as any, res as any, next);
    expect(result.code).toBe(403);
    expect(result.data.error).toBe('Unauthorized access');
  });

  it('logs deletion attempts', async () => {
    const logSpy = vi.spyOn(console, 'log');
    
    try {
      await employeeService.deleteEmployee(1);
    } catch (error) {
      // Expected error for non-existent employee
    }

    expect(logSpy).toHaveBeenCalled();
    expect(logSpy.mock.calls[0][0]).toContain('[INFO]');
  });
});