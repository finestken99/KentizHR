import { describe, it, expect } from 'vitest';
import { validateLoginForm } from '../../lib/validation/auth';
import { sanitize } from '../../lib/security/utils/sanitize';
import { cryptoUtils } from '../../lib/security/utils/crypto';

describe('Security Tests', () => {
  it('prevents XSS attacks', () => {
    const maliciousInput = '<script>alert("xss")</script>';
    const sanitized = sanitize.html(maliciousInput);
    expect(sanitized).not.toContain('<script>');
  });

  it('validates password strength', () => {
    const weakPassword = '123456';
    const strongPassword = 'StrongP@ss123';

    const weakResult = validateLoginForm({ 
      email: 'test@example.com', 
      password: weakPassword 
    });
    const strongResult = validateLoginForm({ 
      email: 'test@example.com', 
      password: strongPassword 
    });

    expect(weakResult.success).toBe(false);
    expect(strongResult.success).toBe(true);
  });

  it('generates secure tokens', async () => {
    const token = cryptoUtils.generateSecureToken();
    expect(token).toHaveLength(64); // 32 bytes = 64 hex chars
    expect(/^[a-f0-9]+$/i.test(token)).toBe(true);
  });
});