import { describe, it, expect } from 'vitest';
import { employeeService } from '../../lib/services/employeeService';
import { browserDb } from '../../lib/db/browserDb';

describe('Employee Management', () => {
  it('deletes employee successfully', async () => {
    // Create test employee
    const employee = await browserDb.register({
      email: 'test.employee@example.com',
      password: 'TestPass123!',
      first_name: 'Test',
      last_name: 'Employee',
      company: 'Test Company',
      role: 'employee'
    });

    expect(employee).toBeDefined();
    expect(employee?.id).toBeDefined();

    // Delete employee
    const result = await employeeService.deleteEmployee(employee!.id!);
    expect(result).toBe(true);

    // Verify employee is deleted
    const deletedEmployee = await browserDb.users
      .where('email')
      .equals('test.employee@example.com')
      .first();
    expect(deletedEmployee).toBeUndefined();
  });

  it('handles deletion of non-existent employee', async () => {
    try {
      await employeeService.deleteEmployee(999999);
      fail('Should have thrown an error');
    } catch (error: any) {
      expect(error.message).toBe('Employee not found');
    }
  });
});