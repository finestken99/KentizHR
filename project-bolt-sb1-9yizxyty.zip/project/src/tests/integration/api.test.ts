import { describe, it, expect } from 'vitest';
import { apiClient } from '../../lib/api/client';
import { aiApi } from '../../lib/api/services/ai';

describe('API Integration', () => {
  it('handles API errors correctly', async () => {
    const invalidEndpoint = 'invalid/endpoint';
    
    try {
      await apiClient.get(invalidEndpoint);
      fail('Should have thrown an error');
    } catch (error: any) {
      expect(error.message).toBeDefined();
    }
  });

  it('makes AI predictions successfully', async () => {
    const employeeData = {
      id: 1,
      age: 35,
      yearsOfService: 5,
      salary: 85000,
      performanceScore: 4.2,
      trainingHours: 45,
      projectsCompleted: 12,
      overtimeHours: 180,
      absenceDays: 5
    };

    const prediction = await aiApi.predictAttrition(employeeData);
    expect(prediction).toBeDefined();
    expect(prediction.risk).toBeDefined();
    expect(prediction.factors).toBeInstanceOf(Array);
  });
});