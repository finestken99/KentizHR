import { describe, it } from 'vitest';
import autocannon from 'autocannon';

describe('Load Testing', () => {
  it('handles multiple concurrent users', async () => {
    const result = await autocannon({
      url: 'http://localhost:3000',
      connections: 100,
      duration: 10,
      pipelining: 1,
      workers: 4
    });

    console.log(result.latency);
    expect(result.errors).toBe(0);
    expect(result.timeouts).toBe(0);
    expect(result.latency.p99).toBeLessThan(1000); // 99th percentile under 1s
  });
});