import { describe, it, expect } from 'vitest';
import { validateLoginForm } from '../../lib/validation/auth';
import { browserDb } from '../../lib/db/browserDb';

describe('Authentication', () => {
  it('validates login form correctly', () => {
    const validData = {
      email: 'test@example.com',
      password: 'Password123!'
    };

    const invalidData = {
      email: 'invalid-email',
      password: '123'
    };

    const validResult = validateLoginForm(validData);
    const invalidResult = validateLoginForm(invalidData);

    expect(validResult.success).toBe(true);
    expect(invalidResult.success).toBe(false);
    expect(invalidResult.errors).toBeDefined();
  });

  it('handles user registration', async () => {
    const userData = {
      email: 'test@example.com',
      password: 'Password123!',
      first_name: 'Test',
      last_name: 'User',
      company: 'Test Company'
    };

    const result = await browserDb.register(userData);
    expect(result).toBeDefined();
    expect(result?.email).toBe(userData.email);
  });
});