import '@testing-library/jest-dom';
import { beforeAll, afterAll, afterEach } from 'vitest';
import { cleanup } from '@testing-library/react';
import { db } from '../lib/db/models/database';

beforeAll(async () => {
  // Initialize test database
  await db.initialize();
});

afterEach(() => {
  cleanup();
});

afterAll(async () => {
  // Clean up database
  await db.delete();
});