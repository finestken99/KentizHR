import React from 'react';
import { Hero } from '../components/sections/hero/Hero';
import { Features } from '../components/sections/features/Features';
import { Solutions } from '../components/sections/solutions/Solutions';
import { Integrations } from '../components/sections/integrations/Integrations';
import { Differentiators } from '../components/sections/differentiators/Differentiators';
import { Interactive } from '../components/sections/interactive/Interactive';
import { Technical } from '../components/sections/technical/Technical';
import { Testimonials } from '../components/sections/testimonials/Testimonials';
import { Pricing } from '../components/sections/pricing/Pricing';
import { Resources } from '../components/sections/resources/Resources';
import { Trust } from '../components/sections/trust/Trust';

export function HomePage() {
  return (
    <>
      <Hero />
      <Features />
      <Solutions />
      <Integrations />
      <Differentiators />
      <Interactive />
      <Technical />
      <Testimonials />
      <Pricing />
      <Resources />
      <Trust />
    </>
  );
}