import React from 'react';
import { Container } from '../components/ui/Container';
import { Features } from '../components/sections/features/Features';
import { Integrations } from '../components/sections/integrations/Integrations';
import { Technical } from '../components/sections/technical/Technical';

export function ProductsPage() {
  return (
    <div className="py-12">
      <Container>
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Our Products
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover our comprehensive suite of HR management solutions designed to streamline your operations
          </p>
        </div>
      </Container>
      <Features />
      <Integrations />
      <Technical />
    </div>
  );
}