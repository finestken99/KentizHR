import React from 'react';
import { motion } from 'framer-motion';
import { 
    Users, Brain, Timer, BarChart2, BookOpen, 
    DollarSign, Heart, ArrowRight, Search, Cpu
} from 'lucide-react';

const solutions = [
    {
        title: "AI-Powered Recruitment",
        icon: <Search className="w-6 h-6" />,
        description: "Smart candidate screening, automated interview scheduling, and predictive hiring analytics",
        features: ["Resume parsing", "Candidate matching", "Interview automation", "Hiring analytics"]
    },
    {
        title: "Intelligent Performance Management",
        icon: <BarChart2 className="w-6 h-6" />,
        description: "Real-time performance tracking with AI-driven insights and recommendations",
        features: ["360° feedback", "Goal tracking", "Performance prediction", "Development planning"]
    },
    {
        title: "Smart Workforce Analytics",
        icon: <Brain className="w-6 h-6" />,
        description: "Advanced analytics for workforce optimization and strategic planning",
        features: ["Attendance tracking", "Productivity analysis", "Retention prediction", "Resource planning"]
    },
    {
        title: "Automated Learning & Development",
        icon: <BookOpen className="w-6 h-6" />,
        description: "Personalized learning paths and skill development programs",
        features: ["Skill assessments", "Custom learning paths", "Progress tracking", "Course recommendations"]
    }
];

const container = {
    hidden: { opacity: 0 },
    show: {
        opacity: 1,
        transition: {
            staggerChildren: 0.2
        }
    }
};

const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
};

export function SolutionsPage() {
    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-8">
            {/* Hero Section */}
            <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center mb-16"
            >
                <div className="flex items-center justify-center mb-4">
                    <Cpu className="w-12 h-12 text-indigo-600 mr-3" />
                    <h1 className="text-4xl font-bold text-gray-800">AI-Powered HR Solutions</h1>
                </div>
                <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                    Transform your HR operations with cutting-edge artificial intelligence and machine learning
                </p>
            </motion.div>

            {/* Solutions Grid */}
            <motion.div 
                variants={container}
                initial="hidden"
                animate="show"
                className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto"
            >
                {solutions.map((solution, index) => (
                    <motion.div
                        key={index}
                        variants={item}
                        className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300"
                    >
                        <div className="flex items-center mb-4">
                            <div className="p-3 bg-indigo-100 rounded-lg text-indigo-600">
                                {solution.icon}
                            </div>
                            <h2 className="text-xl font-semibold ml-4 text-gray-800">
                                {solution.title}
                            </h2>
                        </div>
                        
                        <p className="text-gray-600 mb-6">
                            {solution.description}
                        </p>

                        <div className="space-y-3">
                            {solution.features.map((feature, idx) => (
                                <div key={idx} className="flex items-center text-gray-700">
                                    <ArrowRight className="w-4 h-4 text-indigo-500 mr-2" />
                                    <span>{feature}</span>
                                </div>
                            ))}
                        </div>
                    </motion.div>
                ))}
            </motion.div>

            {/* CTA Section */}
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
                className="text-center mt-16"
            >
                <button className="bg-indigo-600 text-white px-8 py-3 rounded-lg hover:bg-indigo-700 transition-colors duration-300 flex items-center mx-auto">
                    Request Demo
                    <ArrowRight className="w-4 h-4 ml-2" />
                </button>
            </motion.div>
        </div>
    );
}