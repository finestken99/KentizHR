import React from 'react';
import { Container } from '../components/ui/Container';
import { SubscriptionManager } from '../components/subscription/SubscriptionManager';
import { Trust } from '../components/sections/trust/Trust';
import { useUser } from '../contexts/UserContext';

export function SubscriptionPage() {
  const { user } = useUser();

  if (!user) {
    window.location.hash = '#login';
    return null;
  }

  return (
    <div className="py-12">
      <Container>
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Manage Your Subscription
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choose the plan that best fits your business needs
          </p>
        </div>

        <SubscriptionManager />
      </Container>
      <Trust />
    </div>
  );
}