import React, { useState } from 'react';
import { Container } from '../components/ui/Container';
import { SignupSteps } from '../components/signup/SignupSteps';
import { AccountSetup } from '../components/signup/steps/AccountSetup';
import { SystemConfiguration } from '../components/signup/steps/SystemConfiguration';
import { browserDb } from '../lib/db/browserDb';
import { useUser } from '../contexts/UserContext';
import type { AccountSetupData } from '../lib/validation/forms';

const steps = [
  { id: 'account', title: 'Account Setup' },
  { id: 'config', title: 'System Setup' }
];

export function SignupPage() {
  const [currentStep, setCurrentStep] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const { setUser } = useUser();
  const [formData, setFormData] = useState({
    companyName: '',
    adminEmail: '',
    password: '',
    firstName: '',
    lastName: '',
    industry: '',
    size: '',
    departments: [] as string[],
    workingHours: { start: '', end: '' },
    leaveDays: 0
  });

  const handleAccountSetup = async (accountData: AccountSetupData) => {
    try {
      setError(null);

      // Map form data to registration format
      const registrationData = {
        email: accountData.adminEmail,
        password: accountData.password,
        first_name: accountData.firstName,
        last_name: accountData.lastName,
        company: accountData.companyName,
        role: 'admin'
      };

      // Register user
      const result = await browserDb.register(registrationData);
      if (!result) {
        throw new Error('Failed to create account');
      }

      // Auto-login after registration
      const loginResult = await browserDb.login(accountData.adminEmail, accountData.password);
      if (!loginResult) {
        throw new Error('Failed to log in');
      }

      localStorage.setItem('auth_token', loginResult.token);
      setUser(loginResult.user);

      // Update form data and proceed to next step
      setFormData(prev => ({ ...prev, ...accountData }));
      setCurrentStep(prev => prev + 1);
    } catch (err: any) {
      const errorMessage = err.message || 'Failed to create account';
      setError(errorMessage);
      console.error('Registration error:', errorMessage);
    }
  };

  const handleSystemConfig = async (configData: any) => {
    try {
      setError(null);
      setFormData(prev => ({ ...prev, ...configData }));
      window.location.hash = '#dashboard';
    } catch (err: any) {
      const errorMessage = err.message || 'Failed to save configuration';
      setError(errorMessage);
      console.error('Configuration error:', errorMessage);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <Container>
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900">
              Set up your HR system
            </h1>
            <p className="mt-2 text-gray-600">
              Complete the following steps to get started with KENTIZ
            </p>
          </div>

          {error && (
            <div className="mb-6 bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
              {error}
            </div>
          )}

          <SignupSteps steps={steps} currentStep={currentStep} />
          
          <div className="mt-8 bg-white rounded-lg shadow-sm p-6">
            {currentStep === 0 ? (
              <AccountSetup
                data={formData}
                onComplete={handleAccountSetup}
              />
            ) : (
              <SystemConfiguration
                data={formData}
                onComplete={handleSystemConfig}
                onBack={() => setCurrentStep(0)}
              />
            )}
          </div>
        </div>
      </Container>
    </div>
  );
}