import React from 'react';
import { Container } from '../components/ui/Container';
import { Resources } from '../components/sections/resources/Resources';

export function ResourcesPage() {
  return (
    <div className="py-12">
      <Container>
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Resource Center
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Access guides, tutorials, and best practices to maximize your HR management
          </p>
        </div>
      </Container>
      <Resources />
    </div>
  );
}