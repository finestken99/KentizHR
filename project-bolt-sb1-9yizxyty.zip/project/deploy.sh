#!/bin/bash

# Build the React application
npm run build

# Install Apache if not already installed
if ! command -v apache2 &> /dev/null; then
    sudo apt update
    sudo apt install -y apache2
fi

# Enable required Apache modules
sudo a2enmod rewrite
sudo a2enmod headers
sudo a2enmod ssl
sudo a2enmod http2

# Copy build files to Apache directory
sudo rm -rf /var/www/html/*
sudo cp -r dist/* /var/www/html/

# Copy configuration files
sudo cp .htaccess /var/www/html/
sudo cp apache.conf /etc/apache2/sites-available/000-default.conf

# Set proper permissions
sudo chown -R www-data:www-data /var/www/html
sudo chmod -R 755 /var/www/html

# Restart Apache
sudo systemctl restart apache2

echo "Deployment complete! Your application is now running on Apache."